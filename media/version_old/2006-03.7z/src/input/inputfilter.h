#ifndef INPUTFILTER_H
#define INPUTFILTER_H



#include "inpututils.h"
#include "handlers/inputhandler.h"



#include <vector>

class InputHandler;

enum InputEventType
{
    // The device was just pressed.
    IET_FIRST_PRESS,

    // The device is no longer pressed.  Exactly one IET_RELEASE event will be sent
    // for each IET_FIRST_PRESS.
    IET_RELEASE,
};



struct InputEvent
{
    InputEvent(): button(KEY_INVALID), type(IET_FIRST_PRESS) {};
    InputEvent(Button b, InputEventType t): button(b), type(t) {};

    InputEventType type;
    Button button;
};

typedef std::vector<InputEvent> InputEventArray;



class InputFilter
{
    private:
        struct ButtonState
        {
            ButtonState();
            bool mBeingHeld;        // actual current state
            bool mLastReportedHeld; // last state reported by Update()
        };



    public:
              InputFilter();
             ~InputFilter();

        void  ButtonPressed(Button b, bool Down);
        void  Reset();
        void  Update();

        bool  IsBeingPressed(Button b);

        void  GetInputEvents(InputEventArray &array);



    private:
        void  CheckButtonChange(ButtonState &bs, Button b);



    private:
        ButtonState   mButtonState[MAX_BUTTONS];
        InputHandler *mInputHandler;

        InputEventArray queue;

};



extern InputFilter* INPUTFILTER;    // global and accessable from anywhere in our program



#endif // INPUTFILTER_H
