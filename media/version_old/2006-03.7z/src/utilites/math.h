#ifndef MATH_H
#define MATH_H



float
square_triangle(const float &x1, const float &y1,
                const float &x2, const float &y2,
                const float &x3, const float &y3);



bool
point_in_triangle(const float &point_x, const float &point_y,
                  const float &x1, const float &y1,
                  const float &x2, const float &y2,
                  const float &x3, const float &y3);



float
point_elevation(const float &point_x, const float &point_y,
                  const float &x1, const float &y1, const float &z1,
                  const float &x2, const float &y2, const float &z2,
                  const float &x3, const float &y3, const float &z3);



#endif // MATH_H
