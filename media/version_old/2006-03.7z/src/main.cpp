#include "main.h"

#include "config.h"
#include "define.h"
#include "log.h"
#include "display/display.h"
#include "input/inputfilter.h"
#include "resource/filesystem/realfilesystem.h"
#include "resource/screen/screenfield.h"
#include "resource/screen/screenmanager.h"
#include "utilites/utilites.h"

#include <string>
#include <iostream>



// game state
unsigned char state;



void
HandleInputEvents()
{
    INPUTFILTER->Update();

    static InputEventArray input_event_attay;
    input_event_attay.clear(); // empty the array
    INPUTFILTER->GetInputEvents(input_event_attay);

    for (int i = 0; i < input_event_attay.size(); i++)
    {
        SCREENMAN->Input(input_event_attay[i]);
    }
}



int
main(int argc, char *argv[])
{
    // we need real file system for  CONFIG and GAMEFILESYSTEM
    // so init it early
    REALFILESYSTEM = new RealFileSystem();
    LOGGER         = new Logger(DEFAULT_LOG);
    // REALFILESYSTEM are need for this
    CONFIG         = new Config();
    // create render
    DISPLAY        = MakeDisplay();
    SCREENMAN      = new ScreenManager();
    INPUTFILTER    = new InputFilter();

    ScreenField *screen = new ScreenField(std::string("field"), std::string("MDS7.DAT_U"));

    SCREENMAN->PushScreen(screen);

    state = GAME;
    while (state != EXIT)
    {
        SCREENMAN->Draw();

        HandleInputEvents();
    }



    SAFE_DELETE(INPUTFILTER)
    SAFE_DELETE(SCREENMAN)
    SAFE_DELETE(DISPLAY)
    SAFE_DELETE(CONFIG)
    SAFE_DELETE(REALFILESYSTEM)
    return 0;
}
