#ifndef SURFACELOADBMP_H
#define SURFACELOADBMP_H



#include "surfaceload.h"

#include <string>



namespace SurfaceUtils
{
    OpenResult
    LoadBMP(const std::string &file, Surface *&img);
};



#endif
