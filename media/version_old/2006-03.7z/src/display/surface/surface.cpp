#include "surface.h"
#include <stdio.h>
#include <string.h>


Surface::Surface():
    pixels(NULL),
    width(0),
    height(0)
{
}



Surface::Surface(const Surface &cpy):
    pixels(NULL),
    width(cpy.width),
    height(cpy.height)
{
    if (width && height)
    {
        pixels = new unsigned char[width * height * 4];
        memcpy(pixels, cpy.pixels, width * height * 4);
    }
}



Surface::~Surface()
{
    if (width && height)
    {
        delete [] pixels;
    }
}



Surface *
CreateSurface(int width, int height)
{
    Surface *image = new Surface();

    image->width  = width;
    image->height = height;
    image->pixels = new unsigned char[width * height * 4];

    return image;
}



Surface *
CreateSurfaceFrom(int width, int height, unsigned char *pixels)
{
    Surface *image = new Surface();

    image->width  = width;
    image->height = height;
    image->pixels = new unsigned char[width * height * 4];
    memcpy(image->pixels, pixels, width * height * 4);

    return image;
}



void
SetSurfaceSize(Surface *&surface, int width, int height)
{
    unsigned char *pixels = new unsigned char[width * height * 4];

    for (int y = 0; y < height; y++)
    {
        if (y < surface->height)
        {
            int size_to_copy = (surface->width < width) ? surface->width * 4 : width * 4 ;
            memcpy(pixels + y * width * 4, surface->pixels + y * surface->width * 4, size_to_copy);
        }
    }

    delete surface;
    surface = CreateSurfaceFrom(width, height, pixels);

    delete [] pixels;
}
