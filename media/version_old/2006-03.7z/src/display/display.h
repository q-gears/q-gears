#ifndef DISPLAY_H
#define DISPLAY_H



#include "3dtypes.h"
#include "matrixstack.h"
#include "math/vector.h"
#include "math/vectormath.h"
#include "math/matrix.h"
#include "math/matrixmath.h"
#include "surface/surface.h"

#include <vector>



class Display
{
    public:
        // This is needed or the overridden classes' destructors will not be called.
        virtual              ~Display() {}

        virtual bool          BeginFrame() = 0;
        virtual void          EndFrame();

        void                  DrawPoints(const std::vector<Vertex> &v);
        void                  DrawLines(const std::vector<Vertex> &v);
        void                  DrawTriangles(const std::vector<Vertex> &v);
        void                  DrawQuads(const std::vector<Vertex> &v);
        void                  DrawGeometry(const Geometry &g);
        void                  DrawTotalGeometry(const TotalGeometry &g);

        virtual unsigned int  CreateTexture(Surface *image) = 0;
        virtual void          UpdateTexture(unsigned int tex_handle, Surface *image, int xoffset, int yoffset, int width, int height) = 0;
        virtual void          DeleteTexture(unsigned int tex_handle) = 0;
        virtual void          SetTexture(unsigned int tex_handle) = 0;
        virtual void          UnsetTexture() = 0;

        virtual void          SetAlphaTest(bool b) = 0;
        virtual void          SetZTestMode(ZTestMode mode) = 0;
        virtual void          SetBlendMode(BlendMode mode) = 0;
        virtual void          SetCullMode(CullMode mode) = 0;
        virtual void          SetPolygonMode(PolygonMode pm) = 0;
        virtual void          SetLineWidth(float width) = 0;
        virtual void          SetPointSize(float size) = 0;



    protected:
        virtual void          DrawPointsInternal(const std::vector<Vertex> &v) = 0;
        virtual void          DrawLinesInternal(const std::vector<Vertex> &v) = 0;
        virtual void          DrawTrianglesInternal(const std::vector<Vertex> &v) = 0;
        virtual void          DrawQuadsInternal(const std::vector<Vertex> &v) = 0;



    public:
        // World matrix stack functions.
        void                  PushMatrix();
        void                  PopMatrix();
        void                  Translate(float x, float y, float z);
        void                  TranslateWorld(float x, float y, float z);
        void                  Scale(float x, float y, float z);
        void                  RotateX(float deg);
        void                  RotateY(float deg);
        void                  RotateZ(float deg);
        void                  PostMultMatrix(const Matrix &m);
        void                  PreMultMatrix(const Matrix &m);
        void                  LoadIdentity();

        // Texture matrix functions 
        void                  TexturePushMatrix();
        void                  TexturePopMatrix();
        void                  TextureTranslate(float x, float y);
        void                  TextureScale(float x, float y, float z);

        // Projection and View matrix stack functions.
        void                  CameraPushMatrix();
        void                  CameraPopMatrix();
        void                  LoadLookAt(float angley, const Vector3 &eye, const Vector3 &at, const Vector3 &up);



    protected:
        Matrix                GetPerspectiveMatrix(float angley, float aspect, float zNear, float zFar);
        // Different for D3D and OpenGL.
        Matrix                GetOrthoMatrix(float l, float r, float b, float t, float zn, float zf);
        Matrix                GetFrustumMatrix(float l, float r, float b, float t, float zn, float zf);

        // Called by the RageDisplay derivitives
        const Matrix *        GetProjectionTop();
        const Matrix *        GetViewTop();
        const Matrix *        GetWorldTop();
        const Matrix *        GetTextureTop();



    protected:
        MatrixStack ProjectionStack;
        MatrixStack ViewStack;
        MatrixStack WorldStack;
        MatrixStack TextureStack;
};



extern Display *DISPLAY; // global and accessable from anywhere in our program



Display *
MakeDisplay();



#endif
