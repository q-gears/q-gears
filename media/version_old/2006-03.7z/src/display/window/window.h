#ifndef WINDOW_H
#define WINDOW_H




class Window
{
    public:
        virtual     ~Window() {};

        virtual void SwapBuffers() = 0;

        virtual void Update() {}
};



Window *
MakeWindow();



#endif // WINDOW_H
