#include "matrixmath.h"
#include "vector.h"
#include "vectormath.h"

#include <math.h>
#include <memory.h>



void
MatrixIdentity(Matrix *Out)
{
    static float identity[16] = {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1};
    memcpy(&Out->m[0][0], identity, sizeof(identity));
}



void
MatrixTranslation(Matrix *Out, float x, float y, float z)
{
    MatrixIdentity(Out);
    Out->m[3][0] = x;
    Out->m[3][1] = y;
    Out->m[3][2] = z;
}



void
MatrixScaling(Matrix *Out, float x, float y, float z)
{
    MatrixIdentity(Out);
    Out->m[0][0] = x;
    Out->m[1][1] = y;
    Out->m[2][2] = z;
}



void
MatrixRotationX(Matrix *Out, float theta)
{
    theta *= PI / 180;

    MatrixIdentity(Out);
    Out->m[1][1] = (float)cos(theta);
    Out->m[2][2] = Out->m[1][1];

    Out->m[2][1] = (float)sin(theta);
    Out->m[1][2] = -Out->m[2][1];
}



void
MatrixRotationY(Matrix *Out, float theta)
{
    theta *= PI / 180;

    MatrixIdentity(Out);
    Out->m[0][0] = (float)cos(theta);
    Out->m[2][2] = Out->m[0][0];

    Out->m[0][2] = (float)sin(theta);
    Out->m[2][0] = -Out->m[0][2];
}



void
MatrixRotationZ(Matrix *Out, float theta)
{
    theta *= PI / 180;

    MatrixIdentity(Out);
    Out->m[0][0] = (float)cos(theta);
    Out->m[1][1] = Out->m[0][0];

    Out->m[0][1] = (float)sin(theta);
    Out->m[1][0] = -Out->m[0][1];
}



// Return MatrixRotationX(rX) * MatrixRotationY(rY) * MatrixRotationZ(rZ)
// quickly (without actually doing two complete matrix multiplies), by removing the
// parts of the matrix multiplies that we know will be 0.
void
MatrixRotationXYZ(Matrix *Out, float rX, float rY, float rZ)
{
    rX *= PI / 180;
    rY *= PI / 180;
    rZ *= PI / 180;

    const float cX = (float)cos(rX);
    const float sX = (float)sin(rX);
    const float cY = (float)cos(rY);
    const float sY = (float)sin(rY);
    const float cZ = (float)cos(rZ);
    const float sZ = (float)sin(rZ);

    Out->m[0][0] = cZ * cY;
    Out->m[0][1] = cZ * sY * sX + sZ * cX;
    Out->m[0][2] = cZ * sY * cX + sZ * (-sX);
    Out->m[0][3] = 0;
    Out->m[1][0] = (-sZ) * cY;
    Out->m[1][1] = (-sZ) * sY * sX + cZ * cX;
    Out->m[1][2] = (-sZ) * sY * cX + cZ * (-sX);
    Out->m[1][3] = 0;
    Out->m[2][0] = -sY;
    Out->m[2][1] = cY * sX;
    Out->m[2][2] = cY * cX;
    Out->m[2][3] = 0;
    Out->m[3][0] = 0;
    Out->m[3][1] = 0;
    Out->m[3][2] = 0;
    Out->m[3][3] = 1;
}



Matrix
LookAt(float eyex, float eyey, float eyez, float centerx, float centery, float centerz, float upx, float upy, float upz)
{
    Vector3 Z(eyex - centerx, eyey - centery, eyez - centerz);
    Vec3Normalize(&Z, &Z);

    Vector3 Y(upx, upy, upz);

    Vector3 X(
         Y[1] * Z[2] - Y[2] * Z[1],
        -Y[0] * Z[2] + Y[2] * Z[0],
         Y[0] * Z[1] - Y[1] * Z[0]);

    Y = Vector3(
         Z[1] * X[2] - Z[2] * X[1],
        -Z[0] * X[2] + Z[2] * X[0],
         Z[0] * X[1] - Z[1] * X[0]);

    Vec3Normalize(&X, &X);
    Vec3Normalize(&Y, &Y);

    Matrix mat(
        X[0], Y[0], Z[0], 0,
        X[1], Y[1], Z[1], 0,
        X[2], Y[2], Z[2], 0,
        0,    0,    0,    1);

    Matrix mat2;
    MatrixTranslation(&mat2, -eyex, -eyey, -eyez);

    Matrix ret;
    MatrixMultiply(&ret, &mat, &mat2);

    return ret;
}



void
MatrixMultiply(Matrix *Out, const Matrix *A, const Matrix *B)
{
    const Matrix &a = *A;
    const Matrix &b = *B;

    *Out = Matrix(
        b.m[0][0] * a.m[0][0] + b.m[0][1] * a.m[1][0] + b.m[0][2] * a.m[2][0] + b.m[0][3] * a.m[3][0],
        b.m[0][0] * a.m[0][1] + b.m[0][1] * a.m[1][1] + b.m[0][2] * a.m[2][1] + b.m[0][3] * a.m[3][1],
        b.m[0][0] * a.m[0][2] + b.m[0][1] * a.m[1][2] + b.m[0][2] * a.m[2][2] + b.m[0][3] * a.m[3][2],
        b.m[0][0] * a.m[0][3] + b.m[0][1] * a.m[1][3] + b.m[0][2] * a.m[2][3] + b.m[0][3] * a.m[3][3],
        b.m[1][0] * a.m[0][0] + b.m[1][1] * a.m[1][0] + b.m[1][2] * a.m[2][0] + b.m[1][3] * a.m[3][0],
        b.m[1][0] * a.m[0][1] + b.m[1][1] * a.m[1][1] + b.m[1][2] * a.m[2][1] + b.m[1][3] * a.m[3][1],
        b.m[1][0] * a.m[0][2] + b.m[1][1] * a.m[1][2] + b.m[1][2] * a.m[2][2] + b.m[1][3] * a.m[3][2],
        b.m[1][0] * a.m[0][3] + b.m[1][1] * a.m[1][3] + b.m[1][2] * a.m[2][3] + b.m[1][3] * a.m[3][3],
        b.m[2][0] * a.m[0][0] + b.m[2][1] * a.m[1][0] + b.m[2][2] * a.m[2][0] + b.m[2][3] * a.m[3][0],
        b.m[2][0] * a.m[0][1] + b.m[2][1] * a.m[1][1] + b.m[2][2] * a.m[2][1] + b.m[2][3] * a.m[3][1],
        b.m[2][0] * a.m[0][2] + b.m[2][1] * a.m[1][2] + b.m[2][2] * a.m[2][2] + b.m[2][3] * a.m[3][2],
        b.m[2][0] * a.m[0][3] + b.m[2][1] * a.m[1][3] + b.m[2][2] * a.m[2][3] + b.m[2][3] * a.m[3][3],
        b.m[3][0] * a.m[0][0] + b.m[3][1] * a.m[1][0] + b.m[3][2] * a.m[2][0] + b.m[3][3] * a.m[3][0],
        b.m[3][0] * a.m[0][1] + b.m[3][1] * a.m[1][1] + b.m[3][2] * a.m[2][1] + b.m[3][3] * a.m[3][1],
        b.m[3][0] * a.m[0][2] + b.m[3][1] * a.m[1][2] + b.m[3][2] * a.m[2][2] + b.m[3][3] * a.m[3][2],
        b.m[3][0] * a.m[0][3] + b.m[3][1] * a.m[1][3] + b.m[3][2] * a.m[2][3] + b.m[3][3] * a.m[3][3]
    );
}
