#ifndef VECTORMATH_H
#define VECTORMATH_H



#include "vector.h"
#include "matrix.h"



void Vec2Normalize(Vector2 *Out, const Vector2 *V);
void Vec3Normalize(Vector3 *Out, const Vector3 *V);

void Vec4Transform(Vector4 *Out, const Vector4 *V, const Matrix *M);



#endif // VECTORMATH_H
