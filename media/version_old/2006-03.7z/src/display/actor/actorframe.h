#ifndef ACTORFRAME_H
#define ACTORFRAME_H



#include "actor.h"

#include <string>
#include <vector>



class ActorFrame : public Actor
{
    public:
                        ActorFrame();
                        ActorFrame(const ActorFrame &cpy);
        virtual        ~ActorFrame();

        virtual void    AddChild(Actor *actor);
        virtual void    RemoveChild(Actor *actor);
                Actor * GetChild(const std::string &name);
                void    RemoveAllChildren();

        virtual void    DrawPrimitives();



    protected:
        std::vector<Actor *> mSubActors;
};



#endif
