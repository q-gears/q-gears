#include "actorframe.h"

#include <algorithm>
#include <string>
#include <vector>



ActorFrame::ActorFrame()
{
}



ActorFrame::~ActorFrame()
{
}



ActorFrame::ActorFrame( const ActorFrame &cpy ):
    Actor( cpy )
{
}



void
ActorFrame::AddChild(Actor *actor)
{
    // check that this Actor isn't already added.
	std::vector<Actor *>::iterator iter = std::find(mSubActors.begin(), mSubActors.end(), actor);
    if (iter != mSubActors.end())
    {
        return;
    }

    mSubActors.push_back(actor);
}



void
ActorFrame::RemoveChild(Actor *actor)
{
	std::vector<Actor *>::iterator iter = std::find(mSubActors.begin(), mSubActors.end(), actor);
    if (iter != mSubActors.end())
    {
        mSubActors.erase(iter);
    }
}



Actor *
ActorFrame::GetChild(const std::string &name)
{
    for (int i = 0; i < mSubActors.size(); i++)
    {
        if (mSubActors[i]->GetName() == name)
        {
            return mSubActors[i];
        }
    }

    return NULL;
}



void
ActorFrame::RemoveAllChildren()
{
    mSubActors.clear();
}



void
ActorFrame::DrawPrimitives()
{
    // Don't set Actor-defined render states because we won't be drawing 
    // any geometry that belongs to this object.
    // Actor::DrawPrimitives();

    // draw all sub-ActorFrames while we're in the ActorFrame's local coordinate space
    for (int i = 0; i < mSubActors.size(); i++)
    {
        mSubActors[i]->Draw();
    }
}
