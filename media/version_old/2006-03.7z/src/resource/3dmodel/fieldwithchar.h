#ifndef FIELDWITHCHAR_H
#define FIELDWITHCHAR_H



#include "model.h"
#include "charactermodel.h"
#include "../../input/inputfilter.h"



class FieldWithChar : public Model
{
    public:
                     FieldWithChar();
        virtual     ~FieldWithChar();

        virtual void Load(const File *file);
        virtual void DrawPrimitives();

                void Input(const InputEvent &input);
                void Update();



    private:
                void SetToFirst();
                bool CheckAvailability();



    private:
        CharacterModel mCharacter;
        float mX, mY, mZ;
        bool mEnableXP;
        bool mEnableXM;
        bool mEnableZP;
        bool mEnableZM;
};



#endif
