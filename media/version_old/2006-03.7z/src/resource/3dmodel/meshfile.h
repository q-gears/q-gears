#ifndef MESHFILE_H
#define MESHFILE_H



#include "../file.h"
#include "../../display/3dtypes.h"

#include <string>
#include <vector>



class MeshFile : public File
{
    public:
                 MeshFile(const std::string &file);
                 MeshFile(File *file);
        virtual ~MeshFile();

        void     GetGeometry(TotalGeometry &result_geometry);
};



#endif // MESHFILE_H
