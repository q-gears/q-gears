#ifndef CHARACTERMODEL_H
#define CHARACTERMODEL_H



#include "../../display/3dtypes.h"
#include "model.h"



class CharacterModel : public Model
{
    public:
                     CharacterModel();
        virtual     ~CharacterModel();

        virtual void DrawPrimitives();
};



#endif
