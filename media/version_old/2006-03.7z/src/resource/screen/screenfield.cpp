#include "screenfield.h"
#include "../file.h"
#include "../../display/display.h"

#include <string>
#include <math.h>



ScreenField::ScreenField(std::string name, std::string file):
    Screen(name),
    mFile(file),
    mRotX(0),
    mRotY(0),
    mRotZ(0),
    mScale(0.030f)
{
    Init();

    DISPLAY->SetZTestMode(ZTEST_WRITE_ON_PASS);
//    DISPLAY->SetAlphaTest(true);
//    DISPLAY->SetBlendMode(BLEND_NORMAL);
    DISPLAY->SetCullMode(CULL_BACK);
//    DISPLAY->LoadLookAt(50, Vector3(-150, 200, 30), Vector3(-50, 0, 90), Vector3(0, 1, 0));
    DISPLAY->LoadLookAt(50, Vector3(100, 100, 0), Vector3(0, 0, 0), Vector3(0, 1, 0));
}



ScreenField::~ScreenField()
{
}



void
ScreenField::Init()
{
    File *file = new File(mFile);
    mField.Load(file);
    mField.SetPolygonMode(POLYGON_LINE);
    mField.SetBlendMode(BLEND_DISABLED);
    mField.SetCullMode(CULL_NONE);
    mField.SetZTestMode(ZTEST_WRITE_ON_PASS);
    mField.SetName(std::string("field"));
    AddChild(&mField);
    delete file;
}



void
ScreenField::Input(const InputEvent &input)
{
    static_cast<FieldWithChar *>(GetChild("field"))->Input(input);
}



void
ScreenField::Draw()
{
    DISPLAY->PushMatrix();
    DISPLAY->Translate(0, 0, 0);
    DISPLAY->Scale(mScale, mScale, mScale);
    DISPLAY->RotateX(mRotX);
    DISPLAY->RotateY(mRotY);
    DISPLAY->RotateZ(mRotZ);

    DrawPrimitives();

    DISPLAY->PopMatrix();
}
