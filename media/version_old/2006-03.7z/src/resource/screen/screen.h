#ifndef SCREEN_H
#define SCREEN_H

#include "../../display/actor/actorframe.h"
#include "../../input/inputfilter.h"

#include <string>



class Screen : public ActorFrame
{
    public:
                      // enforce that all screens have mName filled in
                      Screen(std::string name);
        virtual      ~Screen();

        virtual void  Init();

        virtual void  Input(const InputEvent &input);

        virtual void  Draw();
};



#endif
