#ifndef SCREENFIELD_H
#define SCREENFIELD_H

#include "screen.h"
#include "../3dmodel/fieldwithchar.h"
#include <string>
#include <vector>



class ScreenField : public Screen
{
    public:
                      ScreenField(std::string name, std::string file);
        virtual      ~ScreenField();

        virtual void  Init();
        virtual void  Input(const InputEvent &input);
        virtual void  Draw();



    private:
        FieldWithChar  mField;
        std::string    mFile;

        int            mRotX;
        int            mRotY;
        int            mRotZ;
        float          mScale;
};



#endif // SCREENFIELD_H
