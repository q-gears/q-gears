#ifndef DEFINE_H
#define DEFINE_H



#define APPLICATION_NAME "Xenogears"

#define DEFAULT_LOG      "game.log"
#define DEFAULT_CONFIG   "config.ini"



#endif // DEFINE_H