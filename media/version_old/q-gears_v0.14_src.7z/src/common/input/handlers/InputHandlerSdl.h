// $Id: InputHandlerSdl.h 93 2006-11-12 13:49:02Z einherjar $

#ifndef INPUTHANDLERSDL_H
#define INPUTHANDLERSDL_H



#include "InputHandler.h"



class InputHandlerSDL: public InputHandler
{
public:
     InputHandlerSDL();
    ~InputHandlerSDL();

    void  Update();
};



#endif // INPUTHANDLERSDL_H
