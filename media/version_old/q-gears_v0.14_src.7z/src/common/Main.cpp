// $Id: Main.cpp 147 2007-02-24 06:13:17Z super_gb $

#include <libxml/parser.h>
#include <SDL/SDL_main.h>
#include <stdio.h>
#include <iostream>

#include "Define.h"
#include "Main.h"
#include "display/DisplayOgl.h"
#include "filesystem/RealFileSystem.h"
#include "input/InputFilter.h"
#include "module/ModuleManager.h"
#include "movie/Movie.h"
#include "utilites/Config.h"
#include "utilites/Logger.h"
#include "utilites/Utilites.h"


using namespace std;


int
main(int argc, char* argv[])
{

	// parse command line parameters
	bool log_to_console = false;
	bool log_to_file = true; // if we are making release maybe set this to false
	bool display_usage = false;
	for(int i = 1; i < argc; i++)
	{
		if(!strcmp(argv[i],"-h") || !strcmp(argv[i], "--help"))
		{
			cout << "-h" << endl;
			display_usage = true;
			break;
		}
		else if(!strcmp(argv[i], "-v") || !strcmp(argv[i], "--verbose"))
		{
			cout << "-v" << endl;
			log_to_console = true;
		}
		else if(!strcmp(argv[i], "-d") || !strcmp(argv[i], "--debug"))
		{
			cout << "-d" << endl;
			log_to_file = true;
		}
		else
		{
			cout << "Unrecognized option: " << argv[i] << endl;
			display_usage = true;
			break;
		}
	}

	if(display_usage)
	{
		cout << "Usage: " << argv[0] << " [options]" << endl
			<< endl << "Basic options:" << endl;
		cout.width(5);
		cout << ' ' << "-h, --help" << endl;
		cout.width(10);
		cout << ' ' << "display this help and exit" << endl << endl;

		cout.width(5);
		cout << ' ' << "-v, --verbose" << endl;
		cout.width(10);
		cout << ' ' << "set logging to console" << endl << endl;

		cout.width(5);
		cout << ' ' << "-d, --debug" << endl;
		cout.width(10);
		cout << ' ' << "set logging to file" << endl;


		exit(EXIT_SUCCESS);
	}


    REALFILESYSTEM = new RealFileSystem();
    LOGGER         = new Logger(DEFAULT_LOG, log_to_console, log_to_file);
    CONFIG         = new Config();
    DISPLAY        = DisplayOGL::MakeDisplay();
    MODULEMAN      = new ModuleManager();
    INPUTFILTER    = new InputFilter();
    MOVIEMAN       = new Movie();



    // Initialize libxml2 and check for potential ABI mismatches between
    // compiled version and the shared library actually used.
    xmlInitParser();
    LIBXML_TEST_VERSION;

    // Redirect libxml errors to /dev/null
    FILE* nullFile = fopen("/dev/null", "w");
    xmlSetGenericErrorFunc(nullFile, NULL);



    game_main();



    // Shutdown libxml
    xmlCleanupParser();



    SAFE_DELETE(MOVIEMAN)
    SAFE_DELETE(INPUTFILTER)
    SAFE_DELETE(MODULEMAN)
    SAFE_DELETE(DISPLAY)
    SAFE_DELETE(CONFIG)
    SAFE_DELETE(LOGGER)
    SAFE_DELETE(REALFILESYSTEM)

    return 0;
}
