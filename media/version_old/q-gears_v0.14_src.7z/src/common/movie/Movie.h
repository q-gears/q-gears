#ifndef MOVIE_H__
#define MOVIE_H__



// TODO:
// 1. Use GAMEFILESYSTEM [modify GameFileSystem?]
// 2. Create Audio Manager
// 3. Rewrite refresh frames and finish criteria for interleaved files based on
// calculating sound time from file size
#include <SDL/SDL.h>
#include <fstream>


#include <vector>
#include <queue>

#include "common/TypeDefine.h"
#include "common/display/3dTypes.h"
#include "common/display/Display.h"
#include "common/utilites/Logger.h"
#include "common/utilites/StdString.h"

// REMOVE THIS
#include "ffvii/filesystem/GameFileSystem.h"

#include "decoders/PSXMDECDecoder.h"
#include "decoders/PSXADPCMDecoder.h"



struct AudioPlayData
{
	int8_t *start_pointer;
	int8_t *end_pointer;
};



void fill_audio(void *data, Uint8 *audio_stream, int play_length);



class Movie
{
public:
	Movie();
	virtual ~Movie();

	void AddMovie(const RString& file_name, const Uint32 id);
	void Update(const Uint32 delta_time);
	void SetMovieToPlay(const Uint32 movie_id);
	void Play();
	void Pause();
	void Stop();
	const bool IsPlaying() const;
	const Uint32 GetFrame() const; 
	const Uint32 GetFrameTextureId() const;
	Uint8* GetAdditionalBuffer() const;


private:
	struct CDXASector
	{
		uint8_t sync[12];
		uint8_t header[4];

		struct CDXASubHeader
		{
			uint8_t file_number;
			uint8_t channel;
			uint8_t submode;
			uint8_t coding_info;
			uint8_t file_number_copy;
			uint8_t channel_number_copy;
			uint8_t submode_copy;
			uint8_t coding_info_copy;
		} subheader;
		uint8_t data[2328];
	};

	struct CDXAVideoData
	{
		uint16_t magic;
		uint16_t data_type;
		uint16_t sector_number;
		uint16_t sector_count;
		uint32_t frame_number;
		uint32_t frame_size;
		uint16_t frame_width;
		uint16_t frame_height;
		uint32_t frame_data_begin1;
		uint32_t frame_data_begin2;
		uint32_t padding;
		uint8_t frame[2016];
	};

	struct MovieWithId
	{
		RString file_name;
		Uint32 id;
		uint8_t type;
	};

	struct VideoFrameContext
	{
		Surface *frame;
		uint8_t *data;
	};

	static const uint8_t m_CDXA_VIDEO = 10;
	static const uint8_t m_CDXA_AUDIO = 4;
	static const uint8_t m_CDXA_BPS = 48;
	static const uint8_t m_CDXA_SAMPLERATE = 12;
	static const uint8_t m_CDXA_STEREO = 3;
	static const uint16_t m_AUDIO_FRAME_SIZE = 8064;

	bool m_AudioSystemReady;
	bool m_IsPlaying;
	int8_t *m_AudioBuffer;
	int8_t m_AudioChannel;
	int8_t m_VideoChannel;
	uint8_t *m_GameData;
	uint8_t m_BufferModifier;
	uint8_t m_PlayingMovie;
	uint32_t m_CurrentFrame;
	int m_CurrentTextureId;
	float m_VideoTimeDelta;

	std::queue<VideoFrameContext> m_VideoFrameBuffer;
	std::vector<MovieWithId> m_Movies;

	RString m_MovieDirectoryPath;
	PSXMDECDecoder m_VideoDecoder;
	PSXADPCMDecoder m_AudioDecoder;
	AudioPlayData m_AudioPlayData;

	RString m_FstreamDataPath; // CLEANUP
	std::fstream m_InputFile; // CLEANUP

	int InitAudioSystem();
	void FillBuffersFile();
	void FillBuffersInterleaved();
};



extern Movie* MOVIEMAN; /**< @brief global Movie instance. Visible from anywhere as the header are included. */



#endif // MOVIE_H__

