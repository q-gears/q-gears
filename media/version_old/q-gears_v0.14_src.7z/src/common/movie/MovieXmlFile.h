// $Id$

#ifndef MOVIE_XML_FILE_h
#define MOVIE_XML_FILE_h

#include "common/filesystem/XmlFile.h"



class MovieXmlFile : public XmlFile
{
public:
    explicit MovieXmlFile(const RString& file);
    virtual ~MovieXmlFile(void);
};



#endif // MOVIE_XML_FILE_h
