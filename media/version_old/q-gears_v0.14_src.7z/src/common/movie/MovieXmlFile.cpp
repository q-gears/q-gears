// $Id$

#include "common/utilites/Logger.h"

#include "Movie.h"
#include "MovieXmlFile.h"



MovieXmlFile::MovieXmlFile(const RString& file):
    XmlFile(file)
{
    if (mFile != NULL)
    {
        xmlNodePtr node = xmlDocGetRootElement(mFile);

        if (node && xmlStrEqual(node->name, BAD_CAST "movies"))
        {
            for (node = node->xmlChildrenNode; node != NULL; node = node->next)
            {
                // load dialogs from xml
                if (xmlStrEqual(node->name, BAD_CAST "movie"))
                {
                    RString file_name = GetString(node, "file_name");
                    Uint32  id        = GetInt(node, "id");

                    LOGGER->Log(LOGGER_INFO, "Add movie %s with id %d.", file_name.c_str(), id);
                    MOVIEMAN->AddMovie(file_name, id);
                }
            }
        }
        else
        {
            LOGGER->Log(LOGGER_WARNING, "Movie XML: %s is not a valid movie file! No <movie> in root.", file.c_str());
        }
    }
}



MovieXmlFile::~MovieXmlFile(void)
{
}
