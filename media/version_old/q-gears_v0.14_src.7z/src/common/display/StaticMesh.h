// $Id$

#ifndef STATIC_MESH_H
#define STATIC_MESH_H

class StaticMesh
{
public:
  StaticMesh(unsigned int nb_vertices, float *coords, float *normals, float *colors, float *tex_coords,
	     unsigned int nb_triangles, unsigned int *triangles):
    mNbVertices(nb_vertices), mCoords(coords), mNormals(normals), mColors(colors), mTexCoords(tex_coords),
    mNbTriangles(nb_triangles), mTriangles(triangles)
  {}
  
  ~StaticMesh()
  {
    delete [] mCoords;
    mCoords = 0;

    delete [] mNormals;
    mNormals = 0;

    delete [] mColors;
    mColors = 0;

    delete [] mTexCoords;
    mTexCoords = 0;
  }

  // Accessors
public:
  inline unsigned int GetNbVertices() const { return mNbVertices; }

  inline const float *GetCoords() const { return mCoords; }
  inline const float *GetNormals() const { return mNormals; }
  inline const float *GetColors() const { return mColors; }
  inline const float *GetTexCoords() const { return mTexCoords; }

public:
  inline unsigned int GetNbTriangles() const { return mNbTriangles; }
  inline const unsigned int *GetTriangles() const { return mTriangles; }

  // Vertices
protected:
  const unsigned int mNbVertices;

  float *mCoords;
  float *mNormals;
  float *mColors;
  float *mTexCoords;

  // Triangles
protected:
  const unsigned int mNbTriangles;
  unsigned int *mTriangles;

//   // Material
// protected:
};

#endif // !GL_MESH_H
