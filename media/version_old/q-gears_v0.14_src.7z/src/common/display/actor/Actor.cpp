// $Id$

#include "Actor.h"
#include "common/display/Display.h"



Actor::Actor(void)
{
}



Actor::~Actor(void)
{
}
