#ifndef LINUXCDXAFILEDRIVER_HH
#define LINUXCDXAFILEDRIVER_HH

#include <set>
#include <vector>
#include <iosfwd>

#include <linux/cdrom.h>
#include <linux/iso_fs.h>

#include "FileDriver.h"

class LinuxCDXAFileDriver : public FileDriver
{
public:
  LinuxCDXAFileDriver(const RString &device);
  virtual ~LinuxCDXAFileDriver();

public:
  virtual unsigned int GetFileSize(const RString &filename);

  virtual bool ReadFile(const RString &filename, void* buffer, const unsigned int start, const unsigned int length);

protected:
  typedef struct cdrom_tochdr cdrom_tochdr_t;
  typedef struct cdrom_tocentry cdrom_tocentry_t;

  typedef struct iso_primary_descriptor iso_primary_descriptor_t;
  typedef struct iso_directory_record iso_directory_record_t;

protected:
  class FileEntry
  {
  public:
    FileEntry(const RString &path, iso_directory_record_t &dir_record);
    FileEntry(const RString &path, const RString &name); // very restricted use only

  public:
    struct filename_lt
    {
      inline bool operator()(const FileEntry* e1, const FileEntry* e2) const;
    };

  public:
    inline const RString &Path() const;
    inline const RString &Name() const;
    inline RString Filename() const;

    inline unsigned int Length() const;
    inline unsigned long Extent() const;
    inline unsigned long Size() const;

    inline bool IsFile() const;
    inline bool IsDirectory() const;

  protected:
    const RString path_;

    iso_directory_record_t dir_record_;
    const RString name_;
  };
  typedef std::set<FileEntry *, FileEntry::filename_lt> FileEntrySet;

protected:
  bool Mount(const RString &device);

  bool ReadTOC(int fd, cdrom_tochdr_t &toc_header,
	       std::vector<cdrom_tocentry_t *> &toc_entries) const;

  bool ReadPrimaryVolumeDescriptor(int fd, int first_track_lba,
				   iso_primary_descriptor_t &primary_descriptor) const;

  bool ReadDirectory(int fd, int lba, unsigned int size, const RString &path,
		     FileEntrySet &file_entries) const;

  bool ReadFileTree(int fd, int first_track_lba,
		    iso_primary_descriptor_t &primary_descriptor,
		    FileEntrySet &file_entries) const;

  void Unmount();

protected:
  FileEntry *Find(const RString &path, const RString &name);
  FileEntry *Find(const RString &filename);

public:
  std::ostream &print(std::ostream &os);

protected:
  //
  int fd_;

  //
  cdrom_tochdr_t toc_header_;
  std::vector<cdrom_tocentry_t *> toc_entries_;

  unsigned long first_track_lba_;
  iso_primary_descriptor_t primary_descriptor_;

  //
  FileEntrySet file_entries_;
};


// ----------------------------------------------------------------------------
// Inline methods

inline const RString &
LinuxCDXAFileDriver::FileEntry::Path() const
{
  return path_;
}

inline const RString &
LinuxCDXAFileDriver::FileEntry::Name() const
{
  return name_;
}

inline RString
LinuxCDXAFileDriver::FileEntry::Filename() const
{
  return path_ + "/" + name_;
}

inline unsigned int
LinuxCDXAFileDriver::FileEntry::Length() const
{
  return (unsigned int) * (char *) &dir_record_.length;
}

inline unsigned long
LinuxCDXAFileDriver::FileEntry::Extent() const
{
  return (*(long *) dir_record_.extent);
}

inline unsigned long
LinuxCDXAFileDriver::FileEntry::Size() const
{
  return (*(long *) dir_record_.size);
}

inline bool
LinuxCDXAFileDriver::FileEntry::IsFile() const
{
  static const int is_a_file_flag = 0x00;
  return *dir_record_.flags & is_a_file_flag;
}

inline bool
LinuxCDXAFileDriver::FileEntry::IsDirectory() const
{
  static const int is_a_dir_flag = 0x02;
  return *dir_record_.flags & is_a_dir_flag;
}

inline bool
LinuxCDXAFileDriver::FileEntry::filename_lt::operator() (const FileEntry *e1,
							 const FileEntry *e2) const
{
  return e1->Filename() < e2->Filename();
}

#endif // !LINUXCDXAFILEDRIVER_HH
