// $Id$

#include <iomanip>
#include <iostream>
#include <sstream>
#include <fstream>

#include "WorldMap.h"

WorldMap::~WorldMap()
{
  for (WorldCellVector::iterator c = mCells.begin(); c != mCells.end(); ++c)
    delete *c;
  mCells.clear();

  for (WorldCellVector::iterator c = mSupplementaryCells.begin(); c != mSupplementaryCells.end(); ++c)
    delete *c;
  mSupplementaryCells.clear();
}

// ----------------------------------------------------------------------------
#if 0
// <<
std::ostream &
operator<<(std::ostream &os, const WorldMap &map)
{
  //
  int i = 0;
  const WorldCellVector &cells = map.GetCells();
  for (WorldCellVector::const_iterator c = cells.begin(); c != cells.end(); ++c, ++i)
    {
      const WorldCell &cell = *(*c);

      const Vector3 cell_translation(cell.GetTranslation());

      // if cell is in frustum:
      {
	int j = 0;
	const WorldMeshVector &meshes = cell.GetMeshes();
	for (WorldMeshVector::const_iterator m = meshes.begin(); m != meshes.end(); ++m, ++j)
	  {
	    const WorldMesh &mesh = *(*m);

	    const Vector3 translation(cell_translation + mesh.GetTranslation());

	    std::ostringstream oss;
	    oss << "/tmp/wm-" << i << "-" << j << ".obj";
	    std::ofstream ofs(oss.str().c_str());
      
	    // if mesh is in frustum:
	    {
	      const Geometry &geometry = * mesh.GetGeometry().triangles.begin();

	      for (std::vector<Vertex>::const_iterator v = geometry.vertexes.begin(); v != geometry.vertexes.end(); ++v)
		ofs << "v "
		   << (translation.x + v->p.x) / 10240.0 << " "
		   << (translation.y + v->p.y) / 10240.0 << " "
		   << (translation.z + v->p.z) / 10240.0 << std::endl;

	      const unsigned int nb_triangles = geometry.vertexes.size() / 3;
	      for (unsigned int t = 0; t < nb_triangles; ++t)
		{
		  const unsigned int t3 = t * 3;
		  ofs << "f "
		      << t3 + 1 << " " << t3 + 2 << " " << t3 + 3 << " "
		      << std::endl;
		}
	    }
	  }
      }
    }
  return os;
}
#endif
