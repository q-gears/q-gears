// $Id$

#ifndef WORLD_MESH_H
#define WORLD_MESH_H

#include <vector>

#include "common/display/math/Vector.h"
#include "common/display/math/Box.h"
#include "common/display/StaticMesh.h"
#include "common/display/3dTypes.h"


class WorldMesh
{
  //
public:
  WorldMesh(const Vector3 &translation, const Box3 &box,
	    StaticMesh *mesh):
    mTranslation(translation),
    mBox(box),
    mMesh(mesh)
  {}

  ~WorldMesh()
  {
    delete mMesh;
    mMesh = 0;
  }

public:
  inline const Vector3 &GetTranslation() const { return mTranslation; }

  inline StaticMesh &GetMesh() { return *mMesh; }
  inline const StaticMesh &GetMesh() const { return *mMesh; }

protected:
  const Vector3 mTranslation;
  const Box3 mBox;

  StaticMesh *mMesh;
};

typedef std::vector<WorldMesh*> WorldMeshVector;

#endif // !WORLD_MESH_H
