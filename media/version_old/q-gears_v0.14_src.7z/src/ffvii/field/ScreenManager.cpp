// $Id: Trigger.cpp 96 2006-11-13 03:34:17Z crazy_otaku $

#include <math.h>

#include "common/display/Display.h"
#include "common/utilites/Config.h"
#include "common/utilites/Logger.h"

#include "ScreenManager.h"
#include "FieldModule.h"



ScreenManager::ScreenManager(FieldModule* pFieldModule):
    m_pFieldModule(pFieldModule),

    m_usScreenWidth(320),
    m_usScreenHeight(224),

    m_ssXMax(0),
    m_ssXMin(0),
    m_ssYMax(0),
    m_ssYMin(0),
    m_ssCameraPositionX(0),
    m_ssCameraPositionY(0),

    m_UseMovieCamera(true),
    m_MoviePlay(false),

    m_bSmooth(false),
    m_ssStartScrollPositionX(0),
    m_ssStartScrollPositionY(0),
    m_ssRequestPositionX(0),
    m_ssRequestPositionY(0),
    m_FramesToScrollTotal(0),
    m_FrameScrollNumber(0),

    m_ScrollToPlayerCharacter(true)
{
    Vertex point;
    point.p.x = -1.0f; point.p.y = -1.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    m_vScreenBorder.push_back(point);
    point.p.x = -1.0f; point.p.y =  1.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    m_vScreenBorder.push_back(point);
    point.p.x =  1.0f; point.p.y = -1.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    m_vScreenBorder.push_back(point);
    point.p.x =  1.0f; point.p.y =  1.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    m_vScreenBorder.push_back(point);
    point.p.x = -1.0f; point.p.y = -1.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    m_vScreenBorder.push_back(point);
    point.p.x =  1.0f; point.p.y = -1.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    m_vScreenBorder.push_back(point);
    point.p.x = -1.0f; point.p.y =  1.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    m_vScreenBorder.push_back(point);
    point.p.x =  1.0f; point.p.y =  1.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    m_vScreenBorder.push_back(point);
}



ScreenManager::~ScreenManager(void)
{
    Clear();
}



void
ScreenManager::Clear(void)
{
    m_vWaitingForScroll.clear();

    m_UseMovieCamera          = true;
    m_MoviePlay               = false;

    m_ScrollToPlayerCharacter = true;
}



void
ScreenManager::Update(const u32& ulDeltaTime)
{
    bool scrolled = false;

    if (m_ssCameraPositionX != m_ssRequestPositionX)
    {
        if (m_FrameScrollNumber == m_FramesToScrollTotal)
        {
            m_ssCameraPositionX = m_ssRequestPositionX;
        }
        else
        {
            float x = (float)m_FrameScrollNumber / (float)m_FramesToScrollTotal;
            float smooth_modifier = (m_bSmooth == true) ? -2 * x * x * x + 3 * x * x : 1;
            m_ssCameraPositionX = m_ssStartScrollPositionX + (m_ssRequestPositionX - m_ssStartScrollPositionX) * smooth_modifier * x;
            scrolled = true;
        }
    }

    if (m_ssCameraPositionY != m_ssRequestPositionY)
    {
        if (m_FrameScrollNumber == m_FramesToScrollTotal)
        {
            m_ssCameraPositionY = m_ssRequestPositionY;
        }
        else
        {
            float x = (float)m_FrameScrollNumber / (float)m_FramesToScrollTotal;
            float smooth_modifier = (m_bSmooth == true) ? -2 * x * x * x + 3 * x * x : 1;
            m_ssCameraPositionY = m_ssStartScrollPositionY + (m_ssRequestPositionY - m_ssStartScrollPositionY) * smooth_modifier * x;
            scrolled = true;
        }
    }



    if (scrolled == true)
    {
        ++m_FrameScrollNumber;
    }



    if (m_ssCameraPositionX == m_ssRequestPositionX && m_ssCameraPositionY == m_ssRequestPositionY)
    {
        for (u8 i = 0; i < m_vWaitingForScroll.size(); ++i)
        {
            m_pFieldModule->m_ObjectManager.SetWait(m_vWaitingForScroll[i], false);
        }

        m_vWaitingForScroll.clear();
    }
}



void
ScreenManager::Draw(void) const
{
    DISPLAY->PushMatrix();
    DISPLAY->LoadIdentity();
    DISPLAY->Scale(2.0f / CONFIG->GAME_WIDTH, 2.0f / CONFIG->GAME_HEIGHT, 1.0f);
    DISPLAY->Translate(-1.0f, 0.0f, 0.0f);
    DISPLAY->Scale((m_usScreenWidth + 2) / 2, (m_usScreenHeight + 2) / 2, 1.0f);
    DISPLAY->CameraPushMatrix();
    DISPLAY->CameraLoadIdentity();
    DISPLAY->SetLineWidth(1);
    DISPLAY->DrawLines(m_vScreenBorder);
    DISPLAY->CameraPopMatrix();
    DISPLAY->PopMatrix();
}



void
ScreenManager::SetFieldCamera(const Matrix& matrix)
{
    m_FieldCamera = matrix;
}



void
ScreenManager::SetFieldOrigin(const Vector3& origin)
{
    m_FieldOrigin = origin;
}



void
ScreenManager::SetFieldProjection(const float x_max, const float x_min, const float y_max, const float y_min)
{
    m_FieldXMax = x_max;
    m_FieldXMin = x_min;
    m_FieldYMax = y_max;
    m_FieldYMin = y_min;
}



void
ScreenManager::SetScreenRange(const Sint16 x_max, const Sint16 x_min, const Sint16 y_max, const Sint16 y_min)
{
    // if screen range lesser than screen size - expand screen range to screen size
    Sint16 x = m_usScreenWidth / 2;
    m_ssXMax = (x_max <  x) ?  x : x_max;
    m_ssXMin = (x_min > -x) ? -x : x_min;
    Sint16 y = m_usScreenHeight / 2;
    m_ssYMax = (y_max <  y) ?  y : y_max;
    m_ssYMin = (y_min > -y) ? -y : y_min;
}



void
ScreenManager::SetMovieCamera(const Matrix& matrix)
{
    m_MovieCamera = matrix;
}



void
ScreenManager::SetMovieOrigin(const Vector3& origin)
{
    m_MovieOrigin = origin;
}



void
ScreenManager::SetMovieProjection(const float x_max, const float x_min, const float y_max, const float y_min)
{
    m_MovieXMax = x_max;
    m_MovieXMin = x_min;
    m_MovieYMax = y_max;
    m_MovieYMin = y_min;
}



void
ScreenManager::SetPlayerCharacterPosition(const Vector3& position)
{
    if (m_ScrollToPlayerCharacter == false)
    {
        return;
    }

    Vector4 view;

    Vector4Transform(view, Vector4(position.x, position.y, position.z, 1), GetCameraMatrix());

    float x_max = (IsMovieCameraUsed() != true) ? m_FieldXMax : m_MovieXMax;
    float x_min = (IsMovieCameraUsed() != true) ? m_FieldXMin : m_MovieXMin;
    float y_max = (IsMovieCameraUsed() != true) ? m_FieldYMax : m_MovieYMax;
    float y_min = (IsMovieCameraUsed() != true) ? m_FieldYMin : m_MovieYMin;

    Matrix projection = DISPLAY->GetFrustumMatrix(x_min, x_max, y_min, y_max, 1, 100000);
    view.x = (view.x * projection.m[0][0] * CONFIG->GAME_WIDTH) / (2 * view.z);
    view.y = (view.y * projection.m[1][1] * CONFIG->GAME_HEIGHT) / (2 * view.z);

    //LOGGER->Log("view.x = %f, view.y = %f", view.x, view.y);

    m_ssRequestPositionX = m_ssStartScrollPositionX  = view.x;
    m_ssRequestPositionY = m_ssStartScrollPositionY  = -view.y;
}



void
ScreenManager::SetMovieCameraUse(const bool use_movie_camera)
{
    m_UseMovieCamera = use_movie_camera;
}



void
ScreenManager::SetMoviePlay(const bool play)
{
    m_MoviePlay = play;
}



const bool
ScreenManager::IsMovieCameraUsed(void) const
{
    return (m_UseMovieCamera == true) && (m_MoviePlay == true);
}



void
ScreenManager::EnableCamera(void) const
{
    DISPLAY->CameraPushMatrix();
    DISPLAY->LoadCameraMatrix(GetCameraMatrix());
    DISPLAY->LoadProjectionMatrix(GetProjectionMatrix());
}



void
ScreenManager::DisableCamera(void) const
{
    DISPLAY->CameraPopMatrix();
}



s16
ScreenManager::GetCameraPositionX(void) const
{
    // crop screen position ro range
    s16 x = m_ssCameraPositionX;
    u16 x_add = m_usScreenWidth / 2;
    x = (x + x_add > m_ssXMax) ? m_ssXMax - x_add : x;
    x = (x - x_add < m_ssXMin) ? m_ssXMin + x_add : x;

    return x;
}



s16
ScreenManager::GetCameraPositionY(void) const
{
    s16 y = m_ssCameraPositionY;
    u16 y_add = m_usScreenHeight / 2;
    y = (y + y_add > m_ssYMax) ? m_ssYMax - y_add : y;
    y = (y - y_add < m_ssYMin) ? m_ssYMin + y_add : y;

    return y;
}



Vector3
ScreenManager::CoordsWorldToScreen(const Vector3& position) const
{
    Vector4 view;
    Vector4Transform(view, Vector4(position.x, position.y, position.z, 1), GetCameraMatrix());

    float x_max = (IsMovieCameraUsed() != true) ? m_FieldXMax : m_MovieXMax;
    float x_min = (IsMovieCameraUsed() != true) ? m_FieldXMin : m_MovieXMin;
    float y_max = (IsMovieCameraUsed() != true) ? m_FieldYMax : m_MovieYMax;
    float y_min = (IsMovieCameraUsed() != true) ? m_FieldYMin : m_MovieYMin;

    Matrix projection = DISPLAY->GetFrustumMatrix(x_min, x_max, y_min, y_max, 1, 100000);

    Vector3 ret;
    ret.x = 160.0f - (view.x * projection.m[0][0] * CONFIG->GAME_WIDTH)  / (2 * view.z);
    ret.y = 112.0f + (view.y * projection.m[1][1] * CONFIG->GAME_HEIGHT) / (2 * view.z);

    if (IsMovieCameraUsed() != true)
    {
        ret.x += GetCameraPositionX();
        ret.y += GetCameraPositionY();
    }

    return ret;
}



void
ScreenManager::ScrollToCoordsInstant(const s16& ssX, const s16& ssY)
{
    m_ssCameraPositionX = m_ssRequestPositionX = ssX;
    m_ssCameraPositionY = m_ssRequestPositionY = ssY;

    m_ScrollToPlayerCharacter = false;
}



void
ScreenManager::ScrollToPlayerCharacter(void)
{
    m_ScrollToPlayerCharacter = true;
}



void
ScreenManager::ScrollToCoordsSmooth(const s16& ssX, const s16& ssY, const u16& usSpeed)
{
    m_bSmooth                 = true;
    m_ssStartScrollPositionX  = m_ssCameraPositionX;
    m_ssStartScrollPositionY  = m_ssCameraPositionY;
    m_ssRequestPositionX      = ssX;
    m_ssRequestPositionY      = ssY;
    m_FramesToScrollTotal     = usSpeed;
    m_FrameScrollNumber       = 0;

    m_ScrollToPlayerCharacter = false;
}



void
ScreenManager::AddWaitForScroll(const s8& sbEntityId)
{
    m_vWaitingForScroll.push_back(sbEntityId);
}



void
ScreenManager::ScrollToCoordsLinear(const s16& ssX, const s16& ssY, const u16& usSpeed)
{
    m_bSmooth                = false;
    m_ssStartScrollPositionX = m_ssCameraPositionX;
    m_ssStartScrollPositionY = m_ssCameraPositionY;
    m_ssRequestPositionX     = ssX;
    m_ssRequestPositionY     = ssY;
    m_FramesToScrollTotal    = usSpeed;
    m_FrameScrollNumber      = 0;
}



Matrix
ScreenManager::GetCameraMatrix(void) const
{
    Matrix  ret;
    Matrix  camera = (IsMovieCameraUsed() != true) ? m_FieldCamera : m_MovieCamera;
    Vector3 origin = (IsMovieCameraUsed() != true) ? m_FieldOrigin : m_MovieOrigin;

    // camera position in world space
    float tx = origin.x * -camera.m[0][0] + origin.y * camera.m[0][1] + origin.z * camera.m[0][2];
    float ty = origin.x * -camera.m[1][0] + origin.y * camera.m[1][1] + origin.z * camera.m[1][2];
    float tz = origin.x * -camera.m[2][0] + origin.y * camera.m[2][1] + origin.z * camera.m[2][2];

    MatrixTranslation(ret, tx, ty, tz);

    // set camera
    MatrixMultiply(ret, camera, ret);
    return ret;
}



Matrix
ScreenManager::GetProjectionMatrix(void) const
{
    float x_max = (IsMovieCameraUsed() != true) ? m_FieldXMax : m_MovieXMax;
    float x_min = (IsMovieCameraUsed() != true) ? m_FieldXMin : m_MovieXMin;
    float y_max = (IsMovieCameraUsed() != true) ? m_FieldYMax : m_MovieYMax;
    float y_min = (IsMovieCameraUsed() != true) ? m_FieldYMin : m_MovieYMin;

    float fMoveX = 0.0f;
    float fMoveY = 0.0f;

    if (IsMovieCameraUsed() != true)
    {
        // crop screen position ro range
        s16 x = m_ssCameraPositionX;
        u16 x_add = m_usScreenWidth / 2;
        x = (x + x_add > m_ssXMax) ? m_ssXMax - x_add : x;
        x = (x - x_add < m_ssXMin) ? m_ssXMin + x_add : x;
        s16 y = m_ssCameraPositionY;
        u16 y_add = m_usScreenHeight / 2;
        y = (y + y_add > m_ssYMax) ? m_ssYMax - y_add : y;
        y = (y - y_add < m_ssYMin) ? m_ssYMin + y_add : y;
        fMoveX = ((x_max - x_min) / CONFIG->GAME_WIDTH) * x;
        fMoveY = ((y_max - y_min) / CONFIG->GAME_HEIGHT) * y;
    }

    return DISPLAY->GetFrustumMatrix(x_min - fMoveX, x_max - fMoveX, y_min + fMoveY, y_max + fMoveY, 1, 100000);
}
