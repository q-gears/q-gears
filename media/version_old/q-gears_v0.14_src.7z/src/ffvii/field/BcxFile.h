// $Id$

#ifndef BCX_FILE_h
#define BCX_FILE_h

#include "common/utilites/StdString.h"

#include "Model.h"
#include "ObjectManager.h"
#include "ffvii/filetypes/LzsFile.h"



class BcxFile : public LzsFile
{
public:
    explicit BcxFile(const RString &file);
    explicit BcxFile(File* file);
             BcxFile(File* file, const u32 &offset, const u32 &length);
             BcxFile(u8* buffer, const u32 &offset, const u32 &length);
    virtual ~BcxFile(void);

    void GetModel(Model& model);
};



#endif // BCX_FILE_h
