// $Id$

#ifndef WALK_MESH_TRIANGLE_h
#define WALK_MESH_TRIANGLE_h

#include "common/TypeDefine.h"
#include "common/display/actor/Actor.h"
#include "common/display/3dTypes.h"



class WalkMeshTriangle : public Actor
{
public:
                   WalkMeshTriangle(const Vector3& a, const Vector3& b, const Vector3& c);
    virtual       ~WalkMeshTriangle(void);

    virtual void   Input(const InputEvent &input);
    virtual void   Update(const Uint32 delta_time);
    virtual void   Draw(void) const;

    const Vector3& GetA(void) const;
    const Vector3& GetB(void) const;
    const Vector3& GetC(void) const;

    void           SetAccessSide(const Uint8 side, const Sint16 triangle_id);
    Sint16         GetAccessSide(const Uint8 side) const;

    void           SetAccessible(const bool access);
    bool           IsAccessible(void) const;

private:
    Vector3 m_A;
    Vector3 m_B;
    Vector3 m_C;

    Sint16  m_Access[3];
    bool    m_Accessible;

    // display related
    Color   m_ColorGrant;
    Color   m_ColorDeny;
    Color   m_ColorPoint;
};



#endif // WALK_MESH_TRIANGLE_h
