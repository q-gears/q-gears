// $Id: Trigger.cpp 96 2006-11-13 03:34:17Z crazy_otaku $

#include <math.h>

#include "../../common/display/Display.h"
#include "../../common/utilites/Logger.h"

#include "CameraManager.h"
#include "FieldModule.h"



CameraManager::CameraManager(FieldModule* pFieldModule):
    m_pFieldModule(pFieldModule),

    m_usScreenWidth(320),
    m_usScreenHeight(240),

    m_ssXMax(0),
    m_ssXMin(0),
    m_ssYMax(0),
    m_ssYMin(0),
    m_ssCameraPositionX(0),
    m_ssCameraPositionY(0),

    m_bSmooth(false),
    m_ssStartScrollPositionX(0),
    m_ssStartScrollPositionY(0),
    m_ssRequestPositionX(0),
    m_ssRequestPositionY(0),
    m_FramesToScrollTotal(0),
    m_FrameScrollNumber(0)
{
    Vertex point;
    point.p.x = -1.0f; point.p.y = -1.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    m_vScreenBorder.push_back(point);
    point.p.x = -1.0f; point.p.y =  1.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    m_vScreenBorder.push_back(point);
    point.p.x =  1.0f; point.p.y = -1.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    m_vScreenBorder.push_back(point);
    point.p.x =  1.0f; point.p.y =  1.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    m_vScreenBorder.push_back(point);
    point.p.x = -1.0f; point.p.y = -1.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    m_vScreenBorder.push_back(point);
    point.p.x =  1.0f; point.p.y = -1.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    m_vScreenBorder.push_back(point);
    point.p.x = -1.0f; point.p.y =  1.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    m_vScreenBorder.push_back(point);
    point.p.x =  1.0f; point.p.y =  1.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    m_vScreenBorder.push_back(point);
}



CameraManager::~CameraManager(void)
{
    Clear();
}



void
CameraManager::Clear(void)
{
    m_vWaitingForScroll.clear();
}



void
CameraManager::Update(const u32& ulDeltaTime)
{
    bool scrolled = false;

    if (m_ssCameraPositionX != m_ssRequestPositionX)
    {
        if (m_FrameScrollNumber == m_FramesToScrollTotal)
        {
            m_ssCameraPositionX = m_ssRequestPositionX;
        }
        else
        {
            float x = (float)m_FrameScrollNumber / (float)m_FramesToScrollTotal;
            float smooth_modifier = (m_bSmooth == true) ? -2 * x * x * x + 3 * x * x : 1;
            m_ssCameraPositionX = m_ssStartScrollPositionX + (m_ssRequestPositionX - m_ssStartScrollPositionX) * smooth_modifier * x;
            scrolled = true;
        }
    }

    if (m_ssCameraPositionY != m_ssRequestPositionY)
    {
        if (m_FrameScrollNumber == m_FramesToScrollTotal)
        {
            m_ssCameraPositionY = m_ssRequestPositionY;
        }
        else
        {
            float x = (float)m_FrameScrollNumber / (float)m_FramesToScrollTotal;
            float smooth_modifier = (m_bSmooth == true) ? -2 * x * x * x + 3 * x * x : 1;
            m_ssCameraPositionY = m_ssStartScrollPositionY + (m_ssRequestPositionY - m_ssStartScrollPositionY) * smooth_modifier * x;
            scrolled = true;
        }
    }



    if (scrolled == true)
    {
        ++m_FrameScrollNumber;
    }



    if (m_ssCameraPositionX == m_ssRequestPositionX && m_ssCameraPositionY == m_ssRequestPositionY)
    {
        for (u8 i = 0; i < m_vWaitingForScroll.size(); ++i)
        {
            m_pFieldModule->m_ObjectManager.SetWait(m_vWaitingForScroll[i], false);
        }

        m_vWaitingForScroll.clear();
    }
}



void
CameraManager::Draw(void) const
{
    DISPLAY->PushMatrix();
    DISPLAY->LoadIdentity();
    DISPLAY->Scale(2.0f/640.0f, 2.0f/480.0f, 1.0f);
    DISPLAY->Scale(m_usScreenWidth / 2, m_usScreenHeight / 2, 1.0f);
    DISPLAY->CameraPushMatrix();
    DISPLAY->CameraLoadIdentity();
    DISPLAY->SetLineWidth(1);
    DISPLAY->DrawLines(m_vScreenBorder);
    DISPLAY->CameraPopMatrix();
    DISPLAY->PopMatrix();
}



void
CameraManager::SetCameraMatrix(const Matrix& matrix)
{
    m_Matrix = matrix;
}



void
CameraManager::SetOrigin(const Vector3& origin)
{
    m_Origin = origin;
}



void
CameraManager::SetProjection(const float& fXMax, const float& fXMin, const float& fYMax, const float& fYMin)
{
    m_fXMax = fXMax;
    m_fXMin = fXMin;
    m_fYMax = fYMax;
    m_fYMin = fYMin;
}



void
CameraManager::EnableCamera(void)
{
    DISPLAY->CameraPushMatrix();
    DISPLAY->LoadCameraMatrix(GetCameraMatrix());
    DISPLAY->LoadProjectionMatrix(GetProjectionMatrix());
}



void
CameraManager::DisableCamera(void)
{
    DISPLAY->CameraPopMatrix();
}



void
CameraManager::SetScreenRange(const s16& ssXMax, const s16& ssXMin, const s16& ssYMax, const s16& ssYMin)
{
    s16 x = m_usScreenWidth / 2;
    m_ssXMax = (ssXMax <  x) ?  x : ssXMax;
    m_ssXMin = (ssXMin > -x) ? -x : ssXMin;
    s16 y = m_usScreenHeight / 2;
    m_ssYMax = (ssYMax <  y) ?  y : ssYMax;
    m_ssYMin = (ssYMin > -y) ? -y : ssYMin;
}



s16
CameraManager::GetCameraPositionX(void) const
{
    // crop screen position ro range
    s16 x = m_ssCameraPositionX;
    u16 x_add = m_usScreenWidth / 2;
    x = (x + x_add > m_ssXMax) ? m_ssXMax - x_add : x;
    x = (x - x_add < m_ssXMin) ? m_ssXMin + x_add : x;

    return x;
}



s16
CameraManager::GetCameraPositionY(void) const
{
    s16 y = m_ssCameraPositionY;
    u16 y_add = m_usScreenHeight / 2;
    y = (y + y_add > m_ssYMax) ? m_ssYMax - y_add : y;
    y = (y - y_add < m_ssYMin) ? m_ssYMin + y_add : y;

    return y;
}



void
CameraManager::ScrollToCoordsInstant(const s16& ssX, const s16& ssY)
{
    m_ssStartScrollPositionX = m_ssCameraPositionX;
    m_ssStartScrollPositionY = m_ssCameraPositionY;
    m_ssRequestPositionX     = ssX;
    m_ssRequestPositionY     = ssY;
    m_FramesToScrollTotal    = 0;
    m_FrameScrollNumber      = 0;
}



void
CameraManager::ScrollToCoordsSmooth(const s16& ssX, const s16& ssY, const u16& usSpeed)
{
    m_bSmooth                = true;
    m_ssStartScrollPositionX = m_ssCameraPositionX;
    m_ssStartScrollPositionY = m_ssCameraPositionY;
    m_ssRequestPositionX     = ssX;
    m_ssRequestPositionY     = ssY;
    m_FramesToScrollTotal    = usSpeed;
    m_FrameScrollNumber      = 0;
}



void
CameraManager::AddWaitForScroll(const s8& sbEntityId)
{
    m_vWaitingForScroll.push_back(sbEntityId);
}



void
CameraManager::ScrollToCoordsLinear(const s16& ssX, const s16& ssY, const u16& usSpeed)
{
    m_bSmooth                = false;
    m_ssStartScrollPositionX = m_ssCameraPositionX;
    m_ssStartScrollPositionY = m_ssCameraPositionY;
    m_ssRequestPositionX     = ssX;
    m_ssRequestPositionY     = ssY;
    m_FramesToScrollTotal    = usSpeed;
    m_FrameScrollNumber      = 0;
}



Matrix
CameraManager::GetCameraMatrix(void) const
{
    Matrix ret;

    // camera position in world space
    float tx = m_Origin.x * -m_Matrix.m[0][0] + m_Origin.y *  m_Matrix.m[0][1] + m_Origin.z *  m_Matrix.m[0][2];
    float ty = m_Origin.x * -m_Matrix.m[1][0] + m_Origin.y *  m_Matrix.m[1][1] + m_Origin.z *  m_Matrix.m[1][2];
    float tz = m_Origin.x * -m_Matrix.m[2][0] + m_Origin.y *  m_Matrix.m[2][1] + m_Origin.z *  m_Matrix.m[2][2];

    MatrixTranslation(ret, tx, ty, tz);

    // set camera
    MatrixMultiply(ret, m_Matrix, ret);
    return ret;
}



Matrix
CameraManager::GetProjectionMatrix(void) const
{
    // crop screen position ro range
    s16 x = m_ssCameraPositionX;
    u16 x_add = m_usScreenWidth / 2;
    x = (x + x_add > m_ssXMax) ? m_ssXMax - x_add : x;
    x = (x - x_add < m_ssXMin) ? m_ssXMin + x_add : x;
    s16 y = m_ssCameraPositionY;
    u16 y_add = m_usScreenHeight / 2;
    y = (y + y_add > m_ssYMax) ? m_ssYMax - y_add : y;
    y = (y - y_add < m_ssYMin) ? m_ssYMin + y_add : y;

    float fMoveX = ((m_fXMax - m_fXMin) / 640.0f) * x;
    float fMoveY = ((m_fYMax - m_fYMin) / 480.0f) * y;

    return DISPLAY->GetFrustumMatrix(m_fXMin - fMoveX, m_fXMax - fMoveX, m_fYMin + fMoveY, m_fYMax + fMoveY, 1, 100000);
}
