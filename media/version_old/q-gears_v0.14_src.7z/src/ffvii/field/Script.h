// $Id: Script.h 94 2006-11-12 19:44:43Z crazy_otaku $

/**
 * @brief Script holder.
 */

#ifndef SCRIPT_h
#define SCRIPT_h

#include "common/TypeDefine.h"
#include "common/utilites/NoCopy.h"

class Entity;
class FieldModule;
class WindowManager;



u8* OpcodesToRawScript(u8* pBuffer, const u32& bufferSize, u32& rawScriptSize);



class Script : public NoCopy<Script>
{
friend class WindowManager;

public:
                 Script(u8* pBuffer, const u32& ulLength);
    virtual     ~Script(void);

    bool         Run(FieldModule* pFieldModule, const s8& sbEntityId, u32& script_position);

    const Uint8  GetU8(const Uint32 offset) const;
    const Uint16 GetU16LE(const Uint32 offset) const;

private:
    Uint8*            m_pBuffer;
    Uint32            m_ulLength;
};



#endif // SCRIPT_h
