// $Id$

#ifndef CAMERA_MANAGER_h
#define CAMERA_MANAGER_h

#include "../../common/display/3dTypes.h"
#include "../../common/utilites/NoCopy.h"

class FieldModule;



class CameraManager : public NoCopy<CameraManager>
{
public:
    explicit   CameraManager(FieldModule* pFieldModule);
    virtual   ~CameraManager(void);

    void       Clear(void);
    void       Update(const u32& ulDeltaTime);
    void       Draw(void) const;

    void       SetCameraMatrix(const Matrix& matrix);
    void       SetOrigin(const Vector3& origin);
    void       SetProjection(const float& fXMax, const float& fXMin, const float& fYMax, const float& fYMin);

    void       EnableCamera(void);
    void       DisableCamera(void);

    void       SetScreenRange(const s16& ssXMax, const s16& ssXMin, const s16& ssYMax, const s16& ssYMin);
    s16        GetCameraPositionX(void) const;
    s16        GetCameraPositionY(void) const;

    // script
    // 0x64 SCR2D
    void       ScrollToCoordsInstant(const s16& ssX, const s16& ssY);
    // 0x66 SCR2DC
    void       ScrollToCoordsSmooth(const s16& ssX, const s16& ssY, const u16& usSpeed);
    // 0x67 SCRLW
    void       AddWaitForScroll(const s8& sbEntityId);
    // 0x68 SCR2DL
    void       ScrollToCoordsLinear(const s16& ssX, const s16& ssY, const u16& usSpeed);

private:
    Matrix     GetCameraMatrix(void) const;
    Matrix     GetProjectionMatrix(void) const;

private:
    // feed back to field module
    FieldModule*        m_pFieldModule;

    u16                 m_usScreenWidth;
    u16                 m_usScreenHeight;
    std::vector<Vertex> m_vScreenBorder;

    // camera
    Matrix              m_Matrix;
    Vector3             m_Origin; // in camera space

    // projection
    float               m_fXMax;
    float               m_fXMin;
    float               m_fYMax;
    float               m_fYMin;

    // current position
    s16                 m_ssXMax;
    s16                 m_ssXMin;
    s16                 m_ssYMax;
    s16                 m_ssYMin;
    s16                 m_ssCameraPositionX;
    s16                 m_ssCameraPositionY;

    // scrolling
    // requested position
    bool                m_bSmooth;
    s16                 m_ssStartScrollPositionX;
    s16                 m_ssStartScrollPositionY;
    s16                 m_ssRequestPositionX;
    s16                 m_ssRequestPositionY;
    u16                 m_FramesToScrollTotal;
    u16                 m_FrameScrollNumber;
    std::vector<s8>     m_vWaitingForScroll;
};



#endif // CAMERA_h
