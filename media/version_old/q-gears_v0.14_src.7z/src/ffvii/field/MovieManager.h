// $Id$

#ifndef MOVIE_MANAGER_h
#define MOVIE_MANAGER_h

#include "common/display/3dTypes.h"
#include "common/display/actor/Actor.h"
#include "common/input/InputFilter.h"

class FieldModule;



class MovieManager : public Actor
{
public:
    explicit     MovieManager(FieldModule* field_module);
    virtual     ~MovieManager(void);

    void         Clear(void);

    void         Draw(void) const;
    void         Input(const InputEvent& input);
    void         Update(const Uint32 delta_time);

    void         SetMovieToPlay(const Uint32 movie_id);
    void         Play(const Sint8 entity_id);
    bool         IsPlay(void) const;
    const Uint32 GetFrame(void) const;

private:
    void         SetMovieCameraToScreenManager(void);

private:
    FieldModule* m_FieldModule;

    bool         m_Play;
    Sint8        m_WaitForPlay;

    Geometry     m_Poly;
};



#endif // MOVIE_MANAGER_h
