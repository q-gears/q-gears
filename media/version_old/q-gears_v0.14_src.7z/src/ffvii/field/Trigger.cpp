// $Id: Trigger.cpp 96 2006-11-13 03:34:17Z crazy_otaku $

#include "common/display/Display.h"
#include "common/utilites/Logger.h"

#include "Entity.h"
#include "FieldModule.h"
#include "Math.h"
#include "Trigger.h"



Trigger::Trigger(FieldModule* pFieldModule, const Vector3& point1, const Vector3& point2):
    m_pFieldModule(pFieldModule),

    m_bEntered(false),

    m_Point1(point1),
    m_Point2(point2)
{
}



Trigger::~Trigger(void)
{
}



void
Trigger::Draw(void) const
{
    Color color(0.0f, 128.0f / 255.0f, 242.0f / 255.0f, 1.0f);

    std::vector<Vertex> line;
    line.resize(2);

    DISPLAY->SetPolygonMode(POLYGON_LINE);
    DISPLAY->SetLineWidth(3);

    line[0].c = color;
    line[1].c = color;
    line[0].p = m_Point1;
    line[1].p = m_Point2;

    DISPLAY->DrawLines(line);

    DISPLAY->SetPolygonMode(POLYGON_FILL);
}



void
Trigger::CheckCollision(Entity* entity)
{
    float distance = 0.0f;

    Vector3 A = entity->GetPosition();
    Vector3 B = m_Point1;
    Vector3 C = m_Point2;

    float ab = sqrtf((A.x - B.x) * (A.x - B.x) + (A.y - B.y) * (A.y - B.y) + (A.z - B.z) * (A.z - B.z));
    float bc = sqrtf((B.x - C.x) * (B.x - C.x) + (B.y - C.y) * (B.y - C.y) + (B.z - C.z) * (B.z - C.z));
    float ac = sqrtf((A.x - C.x) * (A.x - C.x) + (A.y - C.y) * (A.y - C.y) + (A.z - C.z) * (A.z - C.z));

    if (ab * ab + bc * bc < ac * ac)
    {
        distance = ab;
    }
    else if (ac * ac + bc * bc < ab * ab)
    {
        distance = ac;
    }
    else
    {
        float p = (ab + bc + ac) / 2;
        float s = sqrtf(p * (p - ab) * (p - bc) * (p - ac));

        distance = 2 * s / bc;
    }



    // dont know if this is good, but else some gateway
    // will be activated automaticly when we start map.
    Uint16 range = entity->GetSolidRange() / 2;

    if (m_bEntered == false && distance <= range)
    {
        OnEnter();
        m_bEntered = true;
    }
    else if (m_bEntered == true && distance > range)
    {
        OnLeave();
        m_bEntered = false;
    }
    else if (distance <= range && m_PcPreviousPosition != A)
    {
        OnMove();
    }
    else if (distance <= range)
    {
        OnInside();
    }


    // set new value for OnMove()
    m_PcPreviousPosition = A;
}



void
Trigger::SetPoint1(const Vector3& point)
{
    m_Point1 = point;
}



const Vector3&
Trigger::GetPoint1(void) const
{
    return m_Point1;
}



void
Trigger::SetPoint2(const Vector3& point)
{
    m_Point2 = point;
}



const Vector3&
Trigger::GetPoint2(void) const
{
    return m_Point2;
}
