// $Id: Entity.cpp 94 2006-11-12 19:44:43Z crazy_otaku $

#include <math.h>

#include "common/display/Display.h"
#include "common/utilites/Config.h"
#include "common/utilites/Logger.h"

#include "BcxFile.h"
#include "FieldModule.h"
#include "Entity.h"
#include "ObjectManager.h"



Entity::Entity(void):
    m_Name(""),

    m_Inited(false),
    m_Wait(false),
    m_FramesToWait(0),

    m_State(STATE_UNDEFINED),

    m_Position(0.0f, 0.0f, 0.0f),
    m_Direction(0.0f),

    m_Triangle(0),

    m_LadderStart(0.0f, 0.0f, 0.0f),
    m_LadderTriangleStart(0),
    m_LadderEnd(0.0f, 0.0f, 0.0f),
    m_LadderTriangleEnd(0),

    m_JumpStart(0.0f, 0.0f, 0.0f),
    m_JumpEnd(0.0f, 0.0f, 0.0f),

    m_WalkMeshMovePosition(0.0f, 0.0f, 0.0f),

    m_SolidRange(30),
    m_Solid(true),

    m_TalkRange(70),
    m_Talk(true),




    m_ModelId(-1),
    m_Visible(true),

    m_PlayerCharacter(-1)
{
    // init and base scripts are always in priority 8
    m_ScriptQueue[7].id       = 0;



    Vertex v;
    Color color(0.0f, 1.0f, 1.0f, 1.0f);
    v.c = color;

    v.p.x = -1.0f; v.p.y =  0.0f; v.p.z =  0.0f; m_Collision.vertexes.push_back(v);
    v.p.x = -0.9f; v.p.y =  0.0f; v.p.z =  0.5f; m_Collision.vertexes.push_back(v);
    v.p.x = -0.9f; v.p.y =  1.0f; v.p.z =  0.5f; m_Collision.vertexes.push_back(v);
    v.p.x = -1.0f; v.p.y =  1.0f; v.p.z =  0.0f; m_Collision.vertexes.push_back(v);

    v.p.x = -0.9f; v.p.y =  0.0f; v.p.z =  0.5f; m_Collision.vertexes.push_back(v);
    v.p.x = -0.5f; v.p.y =  0.0f; v.p.z =  0.9f; m_Collision.vertexes.push_back(v);
    v.p.x = -0.5f; v.p.y =  1.0f; v.p.z =  0.9f; m_Collision.vertexes.push_back(v);
    v.p.x = -0.9f; v.p.y =  1.0f; v.p.z =  0.5f; m_Collision.vertexes.push_back(v);

    v.p.x = -0.5f; v.p.y =  0.0f; v.p.z =  0.9f; m_Collision.vertexes.push_back(v);
    v.p.x =  0.0f; v.p.y =  0.0f; v.p.z =  1.0f; m_Collision.vertexes.push_back(v);
    v.p.x =  0.0f; v.p.y =  1.0f; v.p.z =  1.0f; m_Collision.vertexes.push_back(v);
    v.p.x = -0.5f; v.p.y =  1.0f; v.p.z =  0.9f; m_Collision.vertexes.push_back(v);

    v.p.x =  0.0f; v.p.y =  0.0f; v.p.z =  1.0f; m_Collision.vertexes.push_back(v);
    v.p.x =  0.5f; v.p.y =  0.0f; v.p.z =  0.9f; m_Collision.vertexes.push_back(v);
    v.p.x =  0.5f; v.p.y =  1.0f; v.p.z =  0.9f; m_Collision.vertexes.push_back(v);
    v.p.x =  0.0f; v.p.y =  1.0f; v.p.z =  1.0f; m_Collision.vertexes.push_back(v);

    v.p.x =  0.5f; v.p.y =  0.0f; v.p.z =  0.9f; m_Collision.vertexes.push_back(v);
    v.p.x =  0.9f; v.p.y =  0.0f; v.p.z =  0.5f; m_Collision.vertexes.push_back(v);
    v.p.x =  0.9f; v.p.y =  1.0f; v.p.z =  0.5f; m_Collision.vertexes.push_back(v);
    v.p.x =  0.5f; v.p.y =  1.0f; v.p.z =  0.9f; m_Collision.vertexes.push_back(v);

    v.p.x =  0.9f; v.p.y =  0.0f; v.p.z =  0.5f; m_Collision.vertexes.push_back(v);
    v.p.x =  1.0f; v.p.y =  0.0f; v.p.z =  0.0f; m_Collision.vertexes.push_back(v);
    v.p.x =  1.0f; v.p.y =  1.0f; v.p.z =  0.0f; m_Collision.vertexes.push_back(v);
    v.p.x =  0.9f; v.p.y =  1.0f; v.p.z =  0.5f; m_Collision.vertexes.push_back(v);


    v.p.x = -1.0f; v.p.y =  0.0f; v.p.z =  0.0f; m_Collision.vertexes.push_back(v);
    v.p.x = -0.9f; v.p.y =  0.0f; v.p.z = -0.5f; m_Collision.vertexes.push_back(v);
    v.p.x = -0.9f; v.p.y =  1.0f; v.p.z = -0.5f; m_Collision.vertexes.push_back(v);
    v.p.x = -1.0f; v.p.y =  1.0f; v.p.z =  0.0f; m_Collision.vertexes.push_back(v);

    v.p.x = -0.9f; v.p.y =  0.0f; v.p.z = -0.5f; m_Collision.vertexes.push_back(v);
    v.p.x = -0.5f; v.p.y =  0.0f; v.p.z = -0.9f; m_Collision.vertexes.push_back(v);
    v.p.x = -0.5f; v.p.y =  1.0f; v.p.z = -0.9f; m_Collision.vertexes.push_back(v);
    v.p.x = -0.9f; v.p.y =  1.0f; v.p.z = -0.5f; m_Collision.vertexes.push_back(v);

    v.p.x = -0.5f; v.p.y =  0.0f; v.p.z = -0.9f; m_Collision.vertexes.push_back(v);
    v.p.x =  0.0f; v.p.y =  0.0f; v.p.z = -1.0f; m_Collision.vertexes.push_back(v);
    v.p.x =  0.0f; v.p.y =  1.0f; v.p.z = -1.0f; m_Collision.vertexes.push_back(v);
    v.p.x = -0.5f; v.p.y =  1.0f; v.p.z = -0.9f; m_Collision.vertexes.push_back(v);

    v.p.x =  0.0f; v.p.y =  0.0f; v.p.z = -1.0f; m_Collision.vertexes.push_back(v);
    v.p.x =  0.5f; v.p.y =  0.0f; v.p.z = -0.9f; m_Collision.vertexes.push_back(v);
    v.p.x =  0.5f; v.p.y =  1.0f; v.p.z = -0.9f; m_Collision.vertexes.push_back(v);
    v.p.x =  0.0f; v.p.y =  1.0f; v.p.z = -1.0f; m_Collision.vertexes.push_back(v);

    v.p.x =  0.5f; v.p.y =  0.0f; v.p.z = -0.9f; m_Collision.vertexes.push_back(v);
    v.p.x =  0.9f; v.p.y =  0.0f; v.p.z = -0.5f; m_Collision.vertexes.push_back(v);
    v.p.x =  0.9f; v.p.y =  1.0f; v.p.z = -0.5f; m_Collision.vertexes.push_back(v);
    v.p.x =  0.5f; v.p.y =  1.0f; v.p.z = -0.9f; m_Collision.vertexes.push_back(v);

    v.p.x =  0.9f; v.p.y =  0.0f; v.p.z = -0.5f; m_Collision.vertexes.push_back(v);
    v.p.x =  1.0f; v.p.y =  0.0f; v.p.z =  0.0f; m_Collision.vertexes.push_back(v);
    v.p.x =  1.0f; v.p.y =  1.0f; v.p.z =  0.0f; m_Collision.vertexes.push_back(v);
    v.p.x =  0.9f; v.p.y =  1.0f; v.p.z = -0.5f; m_Collision.vertexes.push_back(v);



    // temp
    BcxFile model("FIELD/CLOUD.BCX");
    model.GetModel(m_Model);
}



Entity::~Entity(void)
{
}



void
Entity::Input(const InputEvent &input)
{
}



void
Entity::Update(const Uint32 delta_time)
{
}



void
Entity::Draw(void) const
{
    if (m_Visible == true && m_State != STATE_UNDEFINED)
    {
        DISPLAY->PushMatrix();
        DISPLAY->Translate(m_Position.x, m_Position.y + 40, m_Position.z);
        DISPLAY->RotateY(m_Direction);
        DISPLAY->Scale(0.1f, 0.1f, 0.1f);
        m_Model.Draw();
        DISPLAY->PopMatrix();
    }
}



void
Entity::DrawCollision(void) const
{
    DISPLAY->SetPolygonMode(POLYGON_LINE);
    DISPLAY->SetLineWidth(1);

    DISPLAY->PushMatrix();
    DISPLAY->Translate(m_Position.x, m_Position.y, m_Position.z);
    DISPLAY->RotateY(m_Direction);

    DISPLAY->PushMatrix();
    DISPLAY->Scale(m_SolidRange, 100.0f, m_SolidRange);
    DISPLAY->DrawQuads(m_Collision);
    DISPLAY->PopMatrix();

    DISPLAY->PushMatrix();
    DISPLAY->Scale(m_TalkRange, 100.0f, m_TalkRange);
    DISPLAY->DrawQuads(m_Collision);
    DISPLAY->PopMatrix();

    DISPLAY->PopMatrix();

    DISPLAY->SetPolygonMode(POLYGON_FILL);
}



const bool
Entity::CheckCollision(Entity* entity)
{
    Vector3 point = entity->GetPosition();

    float distance = sqrtf((point.x - m_Position.x) * (point.x - m_Position.x) + (point.y - m_Position.y) * (point.y - m_Position.y) + (point.z - m_Position.z) * (point.z - m_Position.z));

    return (distance < m_SolidRange + entity->GetSolidRange()) ? true : false;
}



const bool
Entity::CheckCollisionTalk(Entity* entity)
{
    Vector3 point = entity->GetPosition();

    float distance = sqrtf((point.x - m_Position.x) * (point.x - m_Position.x) + (point.y - m_Position.y) * (point.y - m_Position.y) + (point.z - m_Position.z) * (point.z - m_Position.z));

    return (distance < m_TalkRange) ? true : false;
}



void
Entity::SetName(const RString& name)
{
    m_Name = name;
}



const RString&
Entity::GetName(void) const
{
    return m_Name;
}



void
Entity::AddEntryPoint(const Uint32 entry_point)
{
    m_EntryPoints.push_back(entry_point);
}



void
Entity::Run(FieldModule* field_module, Script* script, const Sint32 entity_id)
{
    // if we syncronize with something
    if (m_Wait == true || m_FramesToWait > 0)
    {
        if (m_FramesToWait > 0)
        {
            --m_FramesToWait;
        }

        return;
    }



    // if we not inited
    if (m_Inited == false)
    {
        Init(field_module, script, entity_id);
    }
    else
    {
        for (int i = 0; i < 8; ++i)
        {
            if (m_ScriptQueue[i].id != -1)
            {
                if (CONFIG->m_DumpScript == true)
                {
                    LOGGER->Log(LOGGER_INFO, "Script %02x from entity %s with priority %d started.", m_ScriptQueue[i].id, m_Name.c_str(), i);
                }



                // if we attach script that wait till this script starts working
                if (m_ScriptQueue[i].start_entity_id != -1)
                {
                    field_module->m_ObjectManager.SetWait(m_ScriptQueue[i].start_entity_id, false);
                    m_ScriptQueue[i].start_entity_id = -1;
                }



                bool finish = script->Run(field_module, entity_id, m_ScriptQueue[i].position);



                // if script finished it work
                if (finish)
                {
                    if (CONFIG->m_DumpScript == true)
                    {
                        LOGGER->Log(LOGGER_INFO, "Script %02x from entity %s with priority %d finished.", m_ScriptQueue[i].id, m_Name.c_str(), i);
                    }



                    // if we attach script that wait till this script ends working
                    if (m_ScriptQueue[i].end_entity_id != -1)
                    {
                        field_module->m_ObjectManager.SetWait(m_ScriptQueue[i].end_entity_id, false);
                        m_ScriptQueue[i].end_entity_id = -1;
                    }



                    if (i == 7 && m_EntryPoints.size() > 0)
                    {
                        // if we run base script
                        m_ScriptQueue[i].position = m_EntryPoints[0];
                    }
                    else
                    {
                        m_ScriptQueue[i].id       = -1;
                        m_ScriptQueue[i].position = 0;
                    }
                }
                else
                {
                    if (CONFIG->m_DumpScript == true)
                    {
                        LOGGER->Log(LOGGER_INFO, "Script %02x from entity %s with priority %d waiting.", m_ScriptQueue[i].id, m_Name.c_str(), i);
                    }
                }

                break;
            }
        }
    }
}



void
Entity::Init(FieldModule* field_module, Script* script, const Sint32 entity_id)
{
    if (CONFIG->m_DumpScript == true)
    {
        LOGGER->Log(LOGGER_INFO, "Entity::Init: Run Init script from entity %s.", m_Name.c_str());
    }

    if (m_EntryPoints.size() == 0)
    {
        LOGGER->Log(LOGGER_WARNING, "Entity::Init: There is no init script set.");
        return;
    }

    if (script->Run(field_module, entity_id, m_EntryPoints[0]) == true)
    {
        m_Inited = true;
        m_ScriptQueue[7].position = m_EntryPoints[0];
    }
}



void
Entity::RequestRun(const Uint8 priority, const Uint32 script_id, const Sint32 start_entity_id, const Sint32 end_entity_id)
{
    if (m_EntryPoints.size() < script_id)
    {
        LOGGER->Log(LOGGER_WARNING, "Entity::RequestRun: Try to run unexisted script.");
        return;
    }

    if (m_ScriptQueue[priority].id == -1)
    {
        m_ScriptQueue[priority].id              = script_id;
        m_ScriptQueue[priority].position        = m_EntryPoints[script_id];
        m_ScriptQueue[priority].start_entity_id = start_entity_id;
        m_ScriptQueue[priority].end_entity_id   = end_entity_id;
    }
}



void
Entity::SetWait(const bool wait)
{
    m_Wait = wait;
}



void
Entity::SetFramesToWait(const Uint32 wait)
{
    m_FramesToWait = wait;
}



void
Entity::SetState(const EntityState state)
{
    m_State = state;
}



const EntityState
Entity::GetState(void) const
{
    return m_State;
}



void
Entity::SetPosition(const Vector3& position)
{
    m_Position = position;
}



const Vector3&
Entity::GetPosition(void) const
{
    return m_Position;
}



void
Entity::SetDirection(const float direction)
{
    m_Direction = direction;
}



const float
Entity::GetDirection(void) const
{
    return m_Direction;
}



void
Entity::SetTriangle(const Sint16 triangle)
{
    m_Triangle = triangle;
}



const Sint16
Entity::GetTriangle(void) const
{
    return m_Triangle;
}



void
Entity::SetLadder(const Vector3& ladder_end, const Sint16 end_triangle)
{
    m_State               = STATE_LADDER;
    m_LadderStart         = m_Position;
    m_LadderTriangleStart = m_Triangle;
    m_LadderEnd           = ladder_end;
    m_LadderTriangleEnd   = end_triangle;
}



const Vector3&
Entity::GetLadderStart(void) const
{
    return m_LadderStart;
}



const Sint16
Entity::GetLadderTriangleStart(void) const
{
    return m_LadderTriangleStart;
}



const Vector3&
Entity::GetLadderEnd(void) const
{
    return m_LadderEnd;
}



const Sint16
Entity::GetLadderTriangleEnd(void) const
{
    return m_LadderTriangleEnd;
}



void
Entity::SetJump(const Vector3& jump_to)
{
    m_State          = STATE_JUMP;
    m_JumpStart      = m_Position;
    m_JumpEnd        = jump_to;
}



const Vector3&
Entity::GetJumpStart(void) const
{
    return m_JumpStart;
}



const Vector3&
Entity::GetJumpEnd(void) const
{
    return m_JumpEnd;
}



void
Entity::SetWalkMeshMove(const Vector3& move_to)
{
    m_State                = STATE_WALKMESH_MOVE;
    m_WalkMeshMovePosition = move_to;
}



const Vector3&
Entity::GetWalkMeshMovePosition(void) const
{
    return m_WalkMeshMovePosition;
}



void
Entity::SetSolidRange(const Uint16 range)
{
    m_SolidRange = range;
}



const Uint16
Entity::GetSolidRange(void) const
{
    return m_SolidRange;
}



void
Entity::SetSolid(const bool solid)
{
    m_Solid = solid;
}



const bool
Entity::IsSolid(void) const
{
    return m_Solid;
}



void
Entity::SetTalkRange(const Uint16 range)
{
    m_TalkRange = range;
}



const Uint16
Entity::GetTalkRange(void) const
{
    return m_TalkRange;
}



void
Entity::SetTalk(const bool talk)
{
    m_Talk = talk;
}



const bool
Entity::IsTalk(void) const
{
    return m_Talk;
}



void
Entity::SetModelId(const Sint8 model_id)
{
    m_ModelId = model_id;
}



const Sint8
Entity::GetModelId(void) const
{
    return m_ModelId;
}



void
Entity::SetVisible(const bool visible)
{
    m_Visible = visible;
}



const bool
Entity::IsVisible(void) const
{
    return m_Visible;
}



void
Entity::SetPlayerCharacter(const Sint8 player_character)
{
    m_PlayerCharacter = player_character;
}



const Sint8
Entity::GetPlayerCharacter(void) const
{
    return m_PlayerCharacter;
}
