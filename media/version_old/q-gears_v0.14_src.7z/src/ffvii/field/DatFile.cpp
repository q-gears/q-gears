// $Id: DatFile.cpp 103 2006-11-26 07:19:38Z crazy_otaku $

#include <math.h>
#include <vector>

#include "common/display/math/Matrix.h"
#include "common/display/math/MatrixMath.h"
#include "common/display/math/Vector.h"
#include "common/display/math/VectorMath.h"
#include "common/utilites/Config.h"
#include "common/utilites/Logger.h"

#include "DatFile.h"
#include "Entity.h"
#include "Gateway.h"
#include "WalkMeshTriangle.h"
#include "ffvii/kernel/Kernel.h"



DatFile::DatFile(const RString &file):
    LzsFile(file)
{
}



DatFile::DatFile(File *file, const u32 &offset, const u32 &length):
    LzsFile(file, offset, length)
{
}



DatFile::DatFile(u8* buffer, const u32 &offset, const u32 &length):
    LzsFile(buffer, offset, length)
{
}



DatFile::DatFile(File *file):
    LzsFile(file)
{
}



DatFile::~DatFile()
{
}



void
DatFile::GetScripts(ObjectManager& object_manager)
{
    // get sector 1 offset (scripts and dialog)
    u32 offset_to_sector       = 0x1C;

    u8  number_of_entity        = GetU8(offset_to_sector + 0x02);
    u16 string_offset           = GetU16LE(offset_to_sector + 0x04);
    u8  number_of_extra_offsets = GetU8(offset_to_sector + 0x06);

    u32 script_offset = 0x20 + number_of_entity * 0x08 + number_of_extra_offsets * 0x04 + number_of_entity * 0x40;
    u32 script_size = string_offset - script_offset;

    Script* script = new Script(mpBuffer + offset_to_sector + script_offset, script_size);
    object_manager.AddScript(script);



    for (u8 i = 0; i < number_of_entity; ++i)
    {
        Entity* entity = new Entity();
        // get entity name
        RString name = RString(reinterpret_cast<char*>(mpBuffer) + offset_to_sector + 0x20 + i * 0x08, 0x08);
        entity->SetName(name);

        // run through all scripts and add them
        for (u8 j = 0; j < 31; ++j)
        {
            u32 entity_script_offset = GetU16LE(offset_to_sector + 0x20 + number_of_entity * 0x08 + number_of_extra_offsets * 0x04 + i * 0x40 + j * 0x02) - script_offset;

            entity->AddEntryPoint(entity_script_offset);
        }

        object_manager.AddEntity(entity);
    }
}



void
DatFile::GetDialogs(WindowManager& windowManager)
{
    // get sector 1 offset (scripts and dialog)
    u32 offset_to_sector  = 0x1C;
    u16 offset_to_dialogs = GetU16LE(offset_to_sector + 0x04);

    u16 number_of_dialogs = GetU16LE(offset_to_sector + offset_to_dialogs);

    for (u16 i = 0; i < number_of_dialogs; ++i)
    {
        // get offset of string data
        u32 offset = offset_to_sector + offset_to_dialogs + GetU16LE(offset_to_sector + offset_to_dialogs + 0x02 + i * 0x02);

        // read the string
        FFVIIString text;
        for (unsigned char temp = 0x00; temp != 0xFF; ++offset)
        {
            temp = GetU8(offset);

            if (temp == 0xF9)
            {
                printf("Opcode 0xF9.");
                // simple string compression, reference an earlier substring
                ++offset;
                int dist  = (GetU8(offset) & 0x3F) + 2;

                int count = (GetU8(offset) >> 6) * 2 + 4;
                for (int k = 0; (k < count) && (GetU8(offset - dist + k) != 0xFF); ++k)
                {
                    text.push_back(GetU8(offset - dist + k));
                }
            }
            else if (temp == 0xF8)
            {
                ++offset;
                ++offset;
                printf("Unknown opcode 0xF8.");
            }
            else
            {
                text.push_back(temp);
            }
        }

        windowManager.AddDialog(text);
    }
}



void
DatFile::GetBackground(BackgroundManager& backgroundManager)
{
    u32 offset_to_background = 0x1C + GetU32LE(0x08) - GetU32LE(0x00);
    //LOGGER->Log("offset_to_background = %x, offset_to_next = %x", offset_to_background, 0x1C + GetU32LE(0x0C) - GetU32LE(0x00));
    u32 offset_to_1 = offset_to_background + 0x10;
    u32 offset_to_2 = offset_to_background + GetU32LE(offset_to_background + 0x00);
    u32 offset_to_3 = offset_to_background + GetU32LE(offset_to_background + 0x04);
    u32 offset_to_4 = offset_to_background + GetU32LE(offset_to_background + 0x08);
    u32 offset_to_5 = offset_to_background + GetU32LE(offset_to_background + 0x0C);

    u32 s1 = offset_to_1;
    u32 s2 = offset_to_2;
    u32 s3 = offset_to_3;
    u32 s4 = offset_to_4;
    u32 s5 = offset_to_5;



    // get global texture setting
    Uint16 g_page_x   =  GetU16LE(s3) & 0x000F;
    Uint16 g_page_y   = (GetU16LE(s3) & 0x0010) >> 0x04;
    Uint8  g_blending = (GetU16LE(s3) & 0x0060) >> 0x05;
    Uint8  g_bpp      = (GetU16LE(s3) & 0x0180) >> 0x07;
    s3 += 0x02;
    if (CONFIG->mDumpSpecificGameData == true)
    {
        LOGGER->Log(LOGGER_INFO, "Set global tex page x = %04x, tex page y = %04x, blending = %02x, bpp = %02x", g_page_x, g_page_y, g_blending, g_bpp);
    }



    for (; s1 < offset_to_2; s1 += 0x06)
    {
        if (GetU16LE(s1) == 0x7FFE)
        {
            g_page_x   =  GetU16LE(s3) & 0x000F;
            g_page_y   = (GetU16LE(s3) & 0x0010) >> 0x04;
            g_blending = (GetU16LE(s3) & 0x0060) >> 0x05;
            g_bpp      = (GetU16LE(s3) & 0x0180) >> 0x07;
            s3 += 0x02;
            if (CONFIG->mDumpSpecificGameData == true)
            {
                LOGGER->Log(LOGGER_INFO, "Set global tex page x = %04x, tex page y = %04x, blending = %02x, bpp = %02x", g_page_x, g_page_y, g_blending, g_bpp);
            }

            s1 += 0x06;
        }
        if (GetU16LE(s1) == 0x7FFF)
        {
            s1 += 0x02;
            break; 
        }



        u16 sprite_num = GetU16LE(s1 + 0x04);

        for (u16 i = 0; i < sprite_num; ++i)
        {
            Sint16 dest_x =  GetU16LE(s2 + 0x00);
            Sint16 dest_y =  GetU16LE(s2 + 0x02);
            Uint8  src_x  =  GetU16LE(s2 + 0x04);
            Uint8  src_y  =  GetU16LE(s2 + 0x05);
            Uint16 clut_y = (GetU16LE(s2 + 0x06) & 0xFFC0) >> 6;
            Uint16 clut_x = (GetU16LE(s2 + 0x06) & 0x003F) << 4;

            if (CONFIG->mDumpSpecificGameData == true)
            {
                LOGGER->Log(LOGGER_INFO, "Add layer 1 sprite to (%d %d) from (%d %d texpage_x %d, texpage_y %d, clut_x %d, clut_y %d).", dest_x, dest_y, src_x, src_y, g_page_x, g_page_y, clut_x, clut_y);
            }

            backgroundManager.AddTile(0, dest_x, dest_y, src_x, src_y, clut_x, clut_y, g_bpp, g_page_x, g_page_y, 0, 0, 0, 0);

            s2 += 0x08;
        }
    }



    for (; s1 < offset_to_2; s1 += 0x06)
    {
        if (GetU16LE(s1) == 0x7FFF)
        {
            s1 += 0x02;
            break;
        }



        Uint16 sprite_num = GetU16LE(s1 + 0x04);

        for (Uint32 i = 0; i < sprite_num; ++i)
        {
            Sint16 dest_x    =  GetU16LE(s4 + 0x00);
            Sint16 dest_y    =  GetU16LE(s4 + 0x02);
            Uint8  src_x     =  GetU16LE(s4 + 0x04);
            Uint8  src_y     =  GetU16LE(s4 + 0x05);
            Uint16 clut_y    = (GetU16LE(s4 + 0x06) & 0xFFC0) >> 6;
            Uint16 clut_x    = (GetU16LE(s4 + 0x06) & 0x003F) << 4;
            Uint16 page_x    =  GetU16LE(s4 + 0x08) & 0x000F;
            Uint16 page_y    = (GetU16LE(s4 + 0x08) & 0x0010) >> 0x04;
            Uint8  bpp       = (GetU16LE(s4 + 0x08) & 0x0180) >> 0x07;
            Uint8  blending  = (GetU16LE(s4 + 0x08) & 0x60) >> 0x05;
            Uint16 distance  =  GetU16LE(s4 + 0x0A);
            Uint8  animation =  GetU8(s4 + 0x0C) & 0x0F;
            Uint8  index     =  GetU8(s4 + 0x0D);

            if (CONFIG->mDumpSpecificGameData == true)
            {
                LOGGER->Log(LOGGER_INFO, "Add layer 2 sprite to (%d %d) from (%d %d texpage_x %d, texpage_y %d, clut_x %d, clut_y %d). Depth %04x. Anim group %d, index %d. Anim %04x", dest_x, dest_y, src_x, src_y, g_page_x, g_page_y, clut_x, clut_y, distance, animation, index, GetU16LE(s4 + 0x08));
            }

            backgroundManager.AddTile(1, dest_x, dest_y, src_x, src_y, clut_x, clut_y, bpp, page_x, page_y, distance, blending, animation, index);

            s4 += 0x0E;
        }
    }



    for (; s1 < offset_to_2; s1 += 0x06)
    {
        if (GetU16LE(s1) == 0x7FFE)
        {
            g_page_x   =  GetU16LE(s3) & 0x000F;
            g_page_y   = (GetU16LE(s3) & 0x0010) >> 0x04;
            g_blending = (GetU16LE(s3) & 0x0060) >> 0x05;
            g_bpp      = (GetU16LE(s3) & 0x0180) >> 0x07;
            s3 += 0x02;

            if (CONFIG->mDumpSpecificGameData == true)
            {
                LOGGER->Log(LOGGER_INFO, "Set global tex page x = %04x, tex page y = %04x, blending = %02x, bpp = %02x", g_page_x, g_page_y, g_blending, g_bpp);
            }

            s1 += 0x06;
        }
        if (GetU16LE(s1) == 0x7FFF)
        {
            s1 += 0x02;
            break;
        }



        Uint16 sprite_num = GetU16LE(s1 + 0x04);

        for (Uint32 i = 0; i < sprite_num; ++i)
        {
            Sint16 dest_x    =  GetU16LE(s5 + 0x00);
            Sint16 dest_y    =  GetU16LE(s5 + 0x02);
            Uint8  src_x     =  GetU16LE(s5 + 0x04);
            Uint8  src_y     =  GetU16LE(s5 + 0x05);
            Uint16 clut_y    = (GetU16LE(s5 + 0x06) & 0xFFC0) >> 6;
            Uint16 clut_x    = (GetU16LE(s5 + 0x06) & 0x003F) << 4;
            Uint8  animation =  GetU8(s5 + 0x08) & 0x0F;
            Uint8  index     =  GetU8(s5 + 0x09);

            if (CONFIG->mDumpSpecificGameData == true)
            {
                LOGGER->Log(LOGGER_INFO, "Add layer 3 sprite to (%d %d) from (%d %d texpage_x %d, texpage_y %d, clut_x %d, clut_y %d). Anim group %d, index %d. Anim %04x", dest_x, dest_y, src_x, src_y, g_page_x, g_page_y, clut_x, clut_y, animation, index, GetU16LE(s5 + 0x08));
            }

            backgroundManager.AddTile(2, dest_x, dest_y, src_x, src_y, clut_x, clut_y, g_bpp, g_page_x, g_page_y, 0, g_blending, animation, index);

            s5 += 0x0A;
        }
    }



    // add layer 4 sprite
    for (; s1 < offset_to_2; s1 += 0x06)
    {
        if (GetU16LE(s1) == 0x7FFE)
        {
            g_page_x   =  GetU16LE(s3) & 0x000F;
            g_page_y   = (GetU16LE(s3) & 0x0010) >> 0x04;
            g_blending = (GetU16LE(s3) & 0x0060) >> 0x05;
            g_bpp      = (GetU16LE(s3) & 0x0180) >> 0x07;
            s3 += 0x02;

            if (CONFIG->mDumpSpecificGameData == true)
            {
                LOGGER->Log(LOGGER_INFO, "Set global tex page x = %04x, tex page y = %04x, blending = %02x, bpp = %02x", g_page_x, g_page_y, g_blending, g_bpp);
            }

            s1 += 0x06;
        }
        if (GetU16LE(s1) == 0x7FFF)
        {
            break;
        }



        Uint16 sprite_num = GetU16LE(s1 + 0x04);

        for (Uint32 i = 0; i < sprite_num; ++i)
        {
            Sint16 dest_x    =  GetU16LE(s5 + 0x00);
            Sint16 dest_y    =  GetU16LE(s5 + 0x02);
            Uint8  src_x     =  GetU16LE(s5 + 0x04);
            Uint8  src_y     =  GetU16LE(s5 + 0x05);
            Uint16 clut_y    = (GetU16LE(s5 + 0x06) & 0xFFC0) >> 6;
            Uint16 clut_x    = (GetU16LE(s5 + 0x06) & 0x003F) << 4;
            Uint8  animation =  GetU8(s5 + 0x08) & 0x0F;
            Uint8  index     =  GetU8(s5 + 0x09);

            if (CONFIG->mDumpSpecificGameData == true)
            {
                LOGGER->Log(LOGGER_INFO, "Add layer 4 sprite to (%d %d) from (%d %d texpage_x %d, texpage_y %d, clut_x %d, clut_y %d). Anim group %d, index %d. Anim %04x", dest_x, dest_y, src_x, src_y, g_page_x, g_page_y, clut_x, clut_y, animation, index, GetU16LE(s5 + 0x08));
            }

            backgroundManager.AddTile(3, dest_x, dest_y, src_x, src_y, clut_x, clut_y, g_bpp, g_page_x, g_page_y, 0, g_blending, animation, index);

            s5 += 0x0A;
        }
    }
}



void
DatFile::GetWalkMesh(ObjectManager& object_manager)
{
    // get sector 2 offset (walkmesh)
    u32 offset_to_walkmesh = 0x1C + GetU32LE(0x04) - GetU32LE(0x00);
    u32 number_of_poly = GetU32LE(offset_to_walkmesh);

    int start_walkmesh = offset_to_walkmesh + 0x04;
    int start_access   = offset_to_walkmesh + 0x04 + number_of_poly * 0x18;

    WalkMeshTriangle* triangle;
    Vector3 A, B, C;


    for (u32 i = 0; i < number_of_poly; ++i)
    {
        A.x =  static_cast<s16>(GetU16LE(start_walkmesh + 0x00));
        A.z =  static_cast<s16>(GetU16LE(start_walkmesh + 0x02));
        A.y =  static_cast<s16>(GetU16LE(start_walkmesh + 0x04));

        B.x =  static_cast<s16>(GetU16LE(start_walkmesh + 0x08));
        B.z =  static_cast<s16>(GetU16LE(start_walkmesh + 0x0A));
        B.y =  static_cast<s16>(GetU16LE(start_walkmesh + 0x0C));

        C.x =  static_cast<s16>(GetU16LE(start_walkmesh + 0x10));
        C.z =  static_cast<s16>(GetU16LE(start_walkmesh + 0x12));
        C.y =  static_cast<s16>(GetU16LE(start_walkmesh + 0x14));

        triangle = new WalkMeshTriangle(A, B, C);

        triangle->SetAccessSide(0, GetU16LE(start_access + 0x00));
        triangle->SetAccessSide(1, GetU16LE(start_access + 0x02));
        triangle->SetAccessSide(2, GetU16LE(start_access + 0x04));

        object_manager.AddWalkMeshTriangle(triangle);

        // go to the next triangle
        start_walkmesh += 0x18;
        start_access   += 0x06;
    }
}



void
DatFile::GetCameraMatrix(ScreenManager& camera)
{
    // get sector 4 offset (camera)
    u32 offset_to_camera = 0x1C + GetU32LE(0x0C) - GetU32LE(0x00);
    if (CONFIG->mDumpSpecificGameData == true)
    {
        LOGGER->Log(LOGGER_INFO, "Offset to Camera section: 0x%08x", offset_to_camera);
    }

    // get camera matrix (3 vectors)
    float vxx = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x00))) * 0.000244140625f; // divide by 4096
    float vxy = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x04))) * 0.000244140625f; // divide by 4096
    float vxz = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x02))) * 0.000244140625f; // divide by 4096

    float vyx = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x06))) * 0.000244140625f; // divide by 4096
    float vyy = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x0A))) * 0.000244140625f; // divide by 4096
    float vyz = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x08))) * 0.000244140625f; // divide by 4096

    float vzx = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x0C))) * 0.000244140625f; // divide by 4096
    float vzy = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x12))) * 0.000244140625f; // divide by 4096
    float vzz = static_cast<float>(-static_cast<s16>(GetU16LE(offset_to_camera + 0x0E))) * 0.000244140625f; // divide by 4096

    // get camera position in camera space
    s32 ox  = -(s32)(GetU32LE(offset_to_camera + 0x14));
    s32 oy  = -(s32)(GetU32LE(offset_to_camera + 0x18));
    s32 oz  = -(s32)(GetU32LE(offset_to_camera + 0x1C));

    float distance = GetU16LE(offset_to_camera + 0x24);



    // camera matrix
    Matrix mat(-vxx, vyx, vzx, 0,
               -vxy, vyy, vzy, 0,
               -vxz, vyz, vzz, 0,
                0,   0,   0,   1);
    camera.SetFieldCamera(mat);
    camera.SetFieldOrigin(Vector3(ox, oy, oz));



    // projection matrix
    float aspect = (float)CONFIG->GAME_WIDTH / (float)CONFIG->GAME_HEIGHT;
    float angley = atanf((CONFIG->GAME_HEIGHT * 0.5f) / distance) * 2.0f;
    float znear  = 1;
    float zfar   = 100000;

    float ymax   =  znear * tanf(angley / 2);
    float ymin   = -ymax;
    float xmin   =  ymin * aspect;
    float xmax   =  ymax * aspect;

    camera.SetFieldProjection(xmax, xmin, ymax, ymin);



    if (CONFIG->mDumpSpecificGameData == true)
    {
        LOGGER->Log(LOGGER_INFO, "Field camera vectors:              vxx = %f, vxy = %f, vxz = %f", vxx, vxy, vxz);
        LOGGER->Log(LOGGER_INFO, "                                   vyx = %f, vyy = %f, vyz = %f", vyx, vyy, vyz);
        LOGGER->Log(LOGGER_INFO, "                                   vzx = %f, vzy = %f, vzz = %f", vzx, vzy, vzz);
        LOGGER->Log(LOGGER_INFO, "Camera position (in camera space): ox = %d, oy = %d, oz = %d", ox, oy, oz);
        LOGGER->Log(LOGGER_INFO, "Camera distance:                   distance = %f", distance);
    }
}




void
DatFile::GetGateway(ObjectManager& object_manager, FieldModule* field_module)
{
    // get sector 5 triggers
    Uint32 offset_to_triggers = 0x1C + GetU32LE(0x10) - GetU32LE(0x00);

    Uint32 start_triggers = offset_to_triggers + 0x38;
    Uint32 start_flags    = offset_to_triggers + 0x218;

    Gateway* gateway;

    for (Uint32 i = 0; i < 12; ++i)
    {
        Sint16 map_id = GetU16LE(start_triggers + 0x12);

        // if not inactive gateway
        if (map_id != 32767)
        {
            Vector3 point1  (static_cast<s16>(GetU16LE(start_triggers + 0x00)),
                             static_cast<s16>(GetU16LE(start_triggers + 0x04)),
                             static_cast<s16>(GetU16LE(start_triggers + 0x02)));
            Vector3 point2  (static_cast<s16>(GetU16LE(start_triggers + 0x06)),
                             static_cast<s16>(GetU16LE(start_triggers + 0x0A)),
                             static_cast<s16>(GetU16LE(start_triggers + 0x08)));
            Vector3 position(static_cast<s16>(GetU16LE(start_triggers + 0x0C)),
                             static_cast<s16>(GetU16LE(start_triggers + 0x10)),
                             static_cast<s16>(GetU16LE(start_triggers + 0x0E)));

            gateway = new Gateway(field_module, point1, point2, position, map_id);

            object_manager.AddGateway(gateway);

            if (CONFIG->mDumpSpecificGameData == true)
            {
                LOGGER->Log(LOGGER_INFO, "Set gateway to map %d", map_id);
            }

            // add mark triangle if set
            if (GetU8(start_flags) == 0x01)
            {
                Vector3 mark_pos((point2.x + point1.x) / 2, (point2.y + point1.y) / 2, (point2.z + point1.z) / 2);

                object_manager.AddMarkTriangle(mark_pos, RED);

                if (CONFIG->mDumpSpecificGameData == true)
                {
                    LOGGER->Log(LOGGER_INFO, "Set mark triangle for gateway %f %f %f", mark_pos.x, mark_pos.y, mark_pos.z);
                }
            }
        }

        // go to the next gateway
        start_triggers += 0x18;
        start_flags    += 0x01;
    }
}



void
DatFile::GetMarkTriangles(ObjectManager& object_manager)
{
    // get sector 5 triggers
    Uint32 offset_to_triggers = 0x1C + GetU32LE(0x10) - GetU32LE(0x00);
    if (CONFIG->mDumpSpecificGameData == true)
    {
        LOGGER->Log(LOGGER_INFO, "Offset to Trigger section: 0x%08x", offset_to_triggers);
    }
    Uint32 start_triangles = offset_to_triggers + 0x224;

    for (Uint32 i = 0; i < 12; ++i)
    {
        Vector3 position(static_cast<Sint16>(GetU16LE(start_triangles + 0x00)),
                         static_cast<Sint16>(GetU16LE(start_triangles + 0x08)),
                         static_cast<Sint16>(GetU16LE(start_triangles + 0x04)));

        Uint32 color_id = GetU32LE(start_triangles + 0x0C);
        if (CONFIG->mDumpSpecificGameData == true)
        {
            LOGGER->Log(LOGGER_INFO, "Triangle position %f %f %f", position.x, position.y, position.z);
            LOGGER->Log(LOGGER_INFO, "Triangle color id = %08x", color_id);
        }

        MarkTriangleColor color = INVISIBLE;
        switch (color_id)
        {
            case 0:  color = INVISIBLE; break;
            case 1:  color = RED;       break;
            case 2:  color = GREEN;     break;
            default: color = RED;
        }

        object_manager.AddMarkTriangle(position, color);

        // go to the next triangle
        start_triangles += 0x10;
    }
}



void
DatFile::GetScreenRange(ScreenManager& screen)
{
    // get sector 5 triggers
    u32 offset_to_triggers = 0x1C + GetU32LE(0x10) - GetU32LE(0x00);

    Sint16 min_x = GetU16LE(offset_to_triggers + 0x0C);
    Sint16 min_y = GetU16LE(offset_to_triggers + 0x0E);
    Sint16 max_x = GetU16LE(offset_to_triggers + 0x10);
    Sint16 max_y = GetU16LE(offset_to_triggers + 0x12);

    screen.SetScreenRange(max_x, min_x, max_y, min_y);

    if (CONFIG->mDumpSpecificGameData == true)
    {
        LOGGER->Log(LOGGER_INFO, "Screen range: x: max = %d", max_x);
        LOGGER->Log(LOGGER_INFO, "                 min = %d", min_x);
        LOGGER->Log(LOGGER_INFO, "              y: max = %d", max_y);
        LOGGER->Log(LOGGER_INFO, "                 min = %d", min_y);
    }
}



void
DatFile::GetMovementRotation(ObjectManager& object_manager)
{
    // get sector 5 triggers
    u32 offset_to_triggers = 0x1C + GetU32LE(0x10) - GetU32LE(0x00);

    Uint32 movement = GetU32LE(offset_to_triggers + 0x08);

    object_manager.SetMovement(movement);

    if (CONFIG->mDumpSpecificGameData == true)
    {
        LOGGER->Log(LOGGER_INFO, "Movement: %08x", movement);
    }
}



void
DatFile::GetEncounter(ObjectManager& objectManager)
{
    // get sector 6 encounters
    u32 offset_to_encounters = 0x1C + GetU32LE(0x14) - GetU32LE(0x00);

    EncounterTable table;

    for (u8 i = 0; i < 2; ++i)
    {
        table.enabled                     = GetU8(offset_to_encounters + i * 0x18 + 0x00);
        table.rate                        = GetU8(offset_to_encounters + i * 0x18 + 0x01);

        table.standart_encounter[0].rate  = GetU16LE(offset_to_encounters + i * 0x18 + 0x02) >> 10;
        table.standart_encounter[0].scene = GetU16LE(offset_to_encounters + i * 0x18 + 0x02) & 0x03FF;
        table.standart_encounter[1].rate  = GetU16LE(offset_to_encounters + i * 0x18 + 0x04) >> 10;
        table.standart_encounter[1].scene = GetU16LE(offset_to_encounters + i * 0x18 + 0x04) & 0x03FF;
        table.standart_encounter[2].rate  = GetU16LE(offset_to_encounters + i * 0x18 + 0x06) >> 10;
        table.standart_encounter[2].scene = GetU16LE(offset_to_encounters + i * 0x18 + 0x06) & 0x03FF;
        table.standart_encounter[3].rate  = GetU16LE(offset_to_encounters + i * 0x18 + 0x08) >> 10;
        table.standart_encounter[3].scene = GetU16LE(offset_to_encounters + i * 0x18 + 0x08) & 0x03FF;
        table.standart_encounter[4].rate  = GetU16LE(offset_to_encounters + i * 0x18 + 0x0A) >> 10;
        table.standart_encounter[4].scene = GetU16LE(offset_to_encounters + i * 0x18 + 0x0A) & 0x03FF;
        table.standart_encounter[5].rate  = GetU16LE(offset_to_encounters + i * 0x18 + 0x0C) >> 10;
        table.standart_encounter[5].scene = GetU16LE(offset_to_encounters + i * 0x18 + 0x0C) & 0x03FF;

        table.special_encounter[0].rate      = GetU16LE(offset_to_encounters + i * 0x18 + 0x0E) >> 10;
        table.special_encounter[0].scene     = GetU16LE(offset_to_encounters + i * 0x18 + 0x0E) & 0x03FF;
        table.special_encounter[1].rate      = GetU16LE(offset_to_encounters + i * 0x18 + 0x10) >> 10;
        table.special_encounter[1].scene     = GetU16LE(offset_to_encounters + i * 0x18 + 0x10) & 0x03FF;
        table.special_encounter[2].rate      = GetU16LE(offset_to_encounters + i * 0x18 + 0x12) >> 10;
        table.special_encounter[2].scene     = GetU16LE(offset_to_encounters + i * 0x18 + 0x12) & 0x03FF;
        table.special_encounter[3].rate      = GetU16LE(offset_to_encounters + i * 0x18 + 0x14) >> 10;
        table.special_encounter[3].scene     = GetU16LE(offset_to_encounters + i * 0x18 + 0x14) & 0x03FF;

        objectManager.AddEncounterTable(table);
    }
}
