// $Id$

#ifndef TDB_FILE_h
#define TDB_FILE_h

#include "common/display/surface/Surface.h"
#include "common/utilites/StdString.h"

#include "ffvii/filetypes/LzsFile.h"
#include "ffvii/filetypes/image/Vram.h"



class TdbFile : public LzsFile
{
public:
    explicit     TdbFile(const RString& file);
    explicit     TdbFile(File* pFile);
                 TdbFile(File* pFile, const u32& offset, const u32& length);
                 TdbFile(u8* pBuffer, const u32& offset, const u32& length);
    virtual     ~TdbFile(void);
};



#endif // TDB_FILE_h
