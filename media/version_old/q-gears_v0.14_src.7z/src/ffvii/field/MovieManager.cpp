// $Id$

#include <math.h>

#include "common/display/Display.h"
#include "common/movie/Movie.h"
#include "common/utilites/Config.h"
#include "common/utilites/Logger.h"

#include "FieldModule.h"
#include "MovieManager.h"



MovieManager::MovieManager(FieldModule* field_module):
    m_FieldModule(field_module),

    m_Play(true),
    m_WaitForPlay(-1)
{
    Vertex point;
    point.p.x = 0.0f; point.p.y =  0.0f; point.p.z = 0.0f;
    point.c.r = 1.0f; point.c.g =  1.0f; point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 0.0f; point.t.y =  0.0f;
    m_Poly.vertexes.push_back(point);
    point.p.x = 512.0f; point.p.y =  0.0f; point.p.z = 0.0f;
    point.c.r = 1.0f; point.c.g =  1.0f; point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f; point.t.y =  0.0f;
    m_Poly.vertexes.push_back(point);
    point.p.x = 512.0f; point.p.y = -256.0f; point.p.z = 0.0f;
    point.c.r = 1.0f; point.c.g =  1.0f; point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f; point.t.y =  1.0f;
    m_Poly.vertexes.push_back(point);
    point.p.x = 0.0f; point.p.y = -256.0f; point.p.z = 0.0f;
    point.c.r = 1.0f; point.c.g =  1.0f; point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 0.0f; point.t.y =  1.0f;
    m_Poly.vertexes.push_back(point);
}



MovieManager::~MovieManager(void)
{
}



void
MovieManager::Clear(void)
{
    MOVIEMAN->Stop();

    m_Play = false;
}



void
MovieManager::Draw(void) const
{
    if (m_Play == true)
    {
        DISPLAY->PushMatrix();
        DISPLAY->LoadIdentity();
        DISPLAY->Scale(2.0f / CONFIG->GAME_WIDTH, 2.0f / CONFIG->GAME_HEIGHT, 1.0f);
        DISPLAY->Translate(-160.0f, 112.0f, 0.0f);

        DISPLAY->CameraPushMatrix();
        DISPLAY->CameraLoadIdentity();
        DISPLAY->TexturePushMatrix();
        DISPLAY->TextureLoadIdentity();

        DISPLAY->SetTexture(MOVIEMAN->GetFrameTextureId());
        DISPLAY->DrawQuads(m_Poly);
        DISPLAY->UnsetTexture();

        DISPLAY->TexturePopMatrix();
        DISPLAY->CameraPopMatrix();
        DISPLAY->PopMatrix();
    }
}



void
MovieManager::Input(const InputEvent& input)
{
}



void
MovieManager::Update(const Uint32 delta_time)
{
    if (MOVIEMAN->IsPlaying() != true)
    {
        m_Play = false;
        if (m_WaitForPlay != -1)
        {
            m_FieldModule->m_ObjectManager.SetWait(m_WaitForPlay, false);

            m_FieldModule->m_ScreenManager.SetMoviePlay(false);

            m_WaitForPlay = -1;
        }
    }
    else
    {
        SetMovieCameraToScreenManager();
    }
}



void
MovieManager::SetMovieToPlay(const Uint32 movie_id)
{
    MOVIEMAN->SetMovieToPlay(movie_id);
}



void
MovieManager::Play(const Sint8 entity_id)
{
    if (KERNEL->MovieLockGet() == true)
    {
        m_FieldModule->m_ObjectManager.SetWait(entity_id, false);
        return;
    }

    m_Play        = true;
    m_WaitForPlay = entity_id;

    m_FieldModule->m_ScreenManager.SetMoviePlay(true);

    MOVIEMAN->Play();
}



bool
MovieManager::IsPlay(void) const
{
    return m_Play;
}



const Uint32
MovieManager::GetFrame(void) const
{
    return MOVIEMAN->GetFrame();
}



void
MovieManager::SetMovieCameraToScreenManager(void)
{
    Uint8* data = MOVIEMAN->GetAdditionalBuffer();



    // get camera matrix (3 vectors)
    float vxx = -(*((Sint16*)(data + 0x00))) * 0.000244140625f; // divide by 4096
    float vxy = -(*((Sint16*)(data + 0x04))) * 0.000244140625f; // divide by 4096
    float vxz = -(*((Sint16*)(data + 0x02))) * 0.000244140625f; // divide by 4096

    float vyx = -(*((Sint16*)(data + 0x06))) * 0.000244140625f; // divide by 4096
    float vyy = -(*((Sint16*)(data + 0x0A))) * 0.000244140625f; // divide by 4096
    float vyz = -(*((Sint16*)(data + 0x08))) * 0.000244140625f; // divide by 4096

    float vzx = -(*((Sint16*)(data + 0x0C))) * 0.000244140625f; // divide by 4096
    float vzy = -(*((Sint16*)(data + 0x12))) * 0.000244140625f; // divide by 4096
    float vzz = -(*((Sint16*)(data + 0x0E))) * 0.000244140625f; // divide by 4096

    // get camera position in camera space
    s32 ox  = -(*((Sint32*)(data + 0x14)));
    s32 oy  = -(*((Sint32*)(data + 0x18)));
    s32 oz  = -(*((Sint32*)(data + 0x1C)));

    //LOGGER->Log(LOGGER_INFO, "x = %d, y = %d, ?? = %d", (*((Sint16*)(data + 0x20))), (*((Sint16*)(data + 0x22))), (*((Sint16*)(data + 0x26))));

    float distance = *((Uint16*)(data + 0x24));



    // camera matrix
    Matrix mat(-vxx, vyx, vzx, 0,
               -vxy, vyy, vzy, 0,
               -vxz, vyz, vzz, 0,
                0,   0,   0,   1);
    m_FieldModule->m_ScreenManager.SetMovieCamera(mat);
    m_FieldModule->m_ScreenManager.SetMovieOrigin(Vector3(ox, oy, oz));



    // projection matrix
    float aspect = (float)CONFIG->GAME_WIDTH / (float)CONFIG->GAME_HEIGHT;
    float angley = atanf((CONFIG->GAME_HEIGHT * 0.5f) / distance) * 2.0f;
    float znear  = 1;
    float zfar   = 100000;

    float ymax   =  znear * tanf(angley / 2);
    float ymin   = -ymax;
    float xmin   =  ymin * aspect;
    float xmax   =  ymax * aspect;

    m_FieldModule->m_ScreenManager.SetMovieProjection(xmax, xmin, ymax, ymin);
}
