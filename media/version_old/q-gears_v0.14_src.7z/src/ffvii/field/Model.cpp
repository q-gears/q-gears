// $Id: Model.cpp 94 2006-11-12 19:44:43Z crazy_otaku $

#include "common/display/Display.h"
#include "common/utilites/Logger.h"

#include "Model.h"



Model::Model(void)
{
}



Model::~Model(void)
{
}



void
Model::Input(const InputEvent& input)
{
}



void
Model::Update(const Uint32 delta_time)
{
}



void
Model::Draw(void) const
{
    //DISPLAY->SetCullMode(CULL_BACK);
    DISPLAY->SetZTestMode(ZTEST_WRITE_ON_PASS);
    DISPLAY->PushMatrix();
    DISPLAY->RotateX(180);
    //DISPLAY->SetPolygonMode(POLYGON_LINE);
    DrawHierarchy(-1);
    //DISPLAY->SetPolygonMode(POLYGON_FILL);
    DISPLAY->PopMatrix();
    DISPLAY->SetZTestMode(ZTEST_OFF);
    //DISPLAY->SetCullMode(CULL_NONE);
}



void
Model::DrawHierarchy(const Sint8 level) const
{
    for (Uint32 i = 0; i < m_Skeleton.size(); ++i)
    {
//LOGGER->Log("i = %d", i);
        if (m_Skeleton[i].parent_id == level)
        {
            DISPLAY->PushMatrix();

            DISPLAY->Translate(0, 0, m_Skeleton[i].length);

            DISPLAY->RotateY(-m_Animation[0].idle[i].rotation_y);
            DISPLAY->RotateX(-m_Animation[0].idle[i].rotation_x);
            DISPLAY->RotateZ(m_Animation[0].idle[i].rotation_z);

//LOGGER->Log("i = %d m_Skeleton[i].length %d, r_x = %f, r_y = %f, r_z = %f", i, m_Skeleton[i].length, m_Animation[0].idle[i].rotation_x, m_Animation[0].idle[i].rotation_y, m_Animation[0].idle[i].rotation_z);

            if (m_Skeleton[i].part_id > -1)
            {
                if (m_Skeleton[i].part_id < m_Parts.size())
                {
                    DISPLAY->DrawGeometrys(m_Parts[m_Skeleton[i].part_id]);
                }
            }

            DrawHierarchy(i);

            DISPLAY->PopMatrix();
        }
    }
}



void
Model::AddBone(const Sint16 length, const Sint8 parent_id, const Sint8 part_id)
{
    Bone bone;
    bone.length    = length;
    bone.parent_id = parent_id;
    bone.part_id   = part_id;

    m_Skeleton.push_back(bone);
}



void
Model::AddPart(const TotalGeometry& geometry)
{
    m_Parts.push_back(geometry);
}



void
Model::AddAnimation(const Animation& animation)
{
    m_Animation.push_back(animation);
}
