// $Id: DbWeapon.h 98 2006-11-21 21:46:28Z einherjar $

#ifndef DBWEAPON_H
#define DBWEAPON_H

#include "common/TypeDefine.h"

struct DBWeapon
{
    u8 Unknown[44];
};

#endif
