// $Id: DbAttack.h 98 2006-11-21 21:46:28Z einherjar $

#ifndef DBATTACK_H
#define DBATTACK_H

#include "common/TypeDefine.h"

struct DBAttack
{
    u8 Unknown[28];
};

#endif
