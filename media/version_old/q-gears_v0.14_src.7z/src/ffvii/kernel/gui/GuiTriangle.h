// $Id: GuiTriangle.h 103 2006-11-26 07:19:38Z crazy_otaku $

#ifndef GUI_TRIANGLE_h
#define GUI_TRIANGLE_h

#include "../../../common/TypeDefine.h"
#include "../../../common/display/3dTypes.h"
#include "../../../common/display/surface/Surface.h"
#include "../../../common/utilites/NoCopy.h"



enum TriangleColor {RED, GREEN};



class GuiTriangle : public NoCopy<GuiTriangle>
{
public:
    GuiTriangle(Surface* image, Surface* image2);

    virtual ~GuiTriangle(void);

    void Draw(const int& x, const int& y, const u8& frame, const TriangleColor& color);

private:
    int      mTexId[8];
    Geometry mPoly;
};



#endif // GUI_GATEWAY_TRIANGLE_h
