// $Id$

#include "GuiColorOverlay.h"
#include "common/display/3dTypes.h"
#include "common/display/Display.h"
#include "common/utilites/Logger.h"



GuiColorOverlay::GuiColorOverlay(void)
{
    Vertex point;
    point.p.x = 0.0f;   point.p.y =  0.0f;   point.p.z = 0.0f;
    mPoly.vertexes.push_back(point);
    point.p.x = 640.0f; point.p.y =  0.0f;   point.p.z = 0.0f;
    mPoly.vertexes.push_back(point);
    point.p.x = 640.0f; point.p.y = -480.0f; point.p.z = 0.0f;
    mPoly.vertexes.push_back(point);
    point.p.x = 0.0f;   point.p.y = -480.0f; point.p.z = 0.0f;
    mPoly.vertexes.push_back(point);
}



GuiColorOverlay::~GuiColorOverlay(void)
{
}



void
GuiColorOverlay::Draw(const Color& color)
{
    mPoly.vertexes[0].c = color;
    mPoly.vertexes[1].c = color;
    mPoly.vertexes[2].c = color;
    mPoly.vertexes[3].c = color;

    DISPLAY->DrawQuads(mPoly);
}
