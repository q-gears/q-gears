// $Id: DialogWindow.h 103 2006-11-26 07:19:38Z crazy_otaku $

#ifndef DIALOGWINDOW_H
#define DIALOGWINDOW_H



#include "common/display/3dTypes.h"
#include "common/display/surface/Surface.h"
#include "common/utilites/NoCopy.h"



class DialogWindow : public NoCopy<DialogWindow>
{
public:
             DialogWindow(Surface* image);

    virtual ~DialogWindow();

    void     DrawWindow(const int& x, const int& y, const int& width, const int& height, const bool& opacity);

private:
    float               mBorderWidth;
    float               mBorderHeight;

    int                 mWindowTexId[9];
    Geometry            mWindowPoly;
};



#endif
