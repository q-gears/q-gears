// $Id: GuiSlash.h 103 2006-11-26 07:19:38Z crazy_otaku $

#ifndef GUISLASH_H
#define GUISLASH_H



#include "common/display/3dTypes.h"
#include "common/display/surface/Surface.h"
#include "common/utilites/NoCopy.h"



class GuiSlash : public NoCopy<GuiSlash>
{
public:
             GuiSlash(Surface* image);
    virtual ~GuiSlash();

    void     DrawSlash(const int &x, const int &y);

private:
    int      mTexId;
    Geometry mPoly;
};



#endif
