// $Id: GuiBarExp.h 103 2006-11-26 07:19:38Z crazy_otaku $

#ifndef GUIBAREXP_H
#define GUIBAREXP_H



#include "common/display/3dTypes.h"
#include "common/display/surface/Surface.h"
#include "common/utilites/NoCopy.h"



enum BarExpType {EXP_BAR, LIMIT_BAR, SADNESS_LIMIT_BAR, FURY_LIMIT_BAR};



class GuiBarExp : public NoCopy<GuiBarExp>
{
public:
             GuiBarExp(Surface* image);
    virtual ~GuiBarExp();

    void     DrawBarExp(const int &x, const int &y, const unsigned int &cur, const unsigned int &max, const BarExpType &type);

private:
    int      mTexId;
    Geometry mPoly;
    Geometry mPolyOverlay;
};



#endif
