// $Id: GuiCounter.cpp 147 2007-02-24 06:13:17Z super_gb $

#include "GuiCounter.h"
#include "common/display/3dTypes.h"
#include "common/display/Display.h"
#include "common/display/surface/Surface.h"
#include "common/utilites/Logger.h"



GuiCounter::GuiCounter(Surface* image)
{
    Surface* temp;

    // 0
    temp = CreateSubSurface(176, 80, 16, 24, image);
    SetSurfaceSize(temp, 16, 32);
    mCounterTexId.insert(std::make_pair(0x30, DISPLAY->CreateTexture(temp)));
    delete temp;
    // 1
    temp = CreateSubSurface(192, 80, 16, 24, image);
    SetSurfaceSize(temp, 16, 32);
    mCounterTexId.insert(std::make_pair(0x31, DISPLAY->CreateTexture(temp)));
    delete temp;
    // 2
    temp = CreateSubSurface(208, 80, 16, 24, image);
    SetSurfaceSize(temp, 16, 32);
    mCounterTexId.insert(std::make_pair(0x32, DISPLAY->CreateTexture(temp)));
    delete temp;
    // 3
    temp = CreateSubSurface(224, 80, 16, 24, image);
    SetSurfaceSize(temp, 16, 32);
    mCounterTexId.insert(std::make_pair(0x33, DISPLAY->CreateTexture(temp)));
    delete temp;
    // 4
    temp = CreateSubSurface(240, 80, 16, 24, image);
    SetSurfaceSize(temp, 16, 32);
    mCounterTexId.insert(std::make_pair(0x34, DISPLAY->CreateTexture(temp)));
    delete temp;
    // 5
    temp = CreateSubSurface(176, 104, 16, 24, image);
    SetSurfaceSize(temp, 16, 32);
    mCounterTexId.insert(std::make_pair(0x35, DISPLAY->CreateTexture(temp)));
    delete temp;
    // 6
    temp = CreateSubSurface(192, 104, 16, 24, image);
    SetSurfaceSize(temp, 16, 32);
    mCounterTexId.insert(std::make_pair(0x36, DISPLAY->CreateTexture(temp)));
    delete temp;
    // 7
    temp = CreateSubSurface(208, 104, 16, 24, image);
    SetSurfaceSize(temp, 16, 32);
    mCounterTexId.insert(std::make_pair(0x37, DISPLAY->CreateTexture(temp)));
    delete temp;
    // 8
    temp = CreateSubSurface(224, 104, 16, 24, image);
    SetSurfaceSize(temp, 16, 32);
    mCounterTexId.insert(std::make_pair(0x38, DISPLAY->CreateTexture(temp)));
    delete temp;
    // 9
    temp = CreateSubSurface(240, 104, 16, 24, image);
    SetSurfaceSize(temp, 16, 32);
    mCounterTexId.insert(std::make_pair(0x39, DISPLAY->CreateTexture(temp)));
    delete temp;
    // _
    temp = CreateSubSurface(144, 104, 16, 24, image);
    SetSurfaceSize(temp, 16, 32);
    mCounterTexId.insert(std::make_pair(0x5F, DISPLAY->CreateTexture(temp)));
    delete temp;
    // -
    temp = CreateSubSurface(160, 104, 16, 24, image);
    SetSurfaceSize(temp, 16, 32);
    mCounterTexId.insert(std::make_pair(0x2D, DISPLAY->CreateTexture(temp)));
    delete temp;
    // :
    temp = CreateSubSurface(160, 80, 8, 24, image);
    SetSurfaceSize(temp, 16, 32);
    mCounterTexId.insert(std::make_pair(0x3A, DISPLAY->CreateTexture(temp)));
    delete temp;
    //
    temp = CreateSubSurface(168, 80, 8, 24, image);
    SetSurfaceSize(temp, 16, 32);
    mCounterTexId.insert(std::make_pair(0x20, DISPLAY->CreateTexture(temp)));
    delete temp;



    Vertex point;
    point.p.x = 0.0f;  point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 0.0f;  point.t.y = 0.0f;
    mCounterPoly.vertexes.push_back(point);
    point.p.x = 16.0f; point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 0.0f;
    mCounterPoly.vertexes.push_back(point);
    point.p.x = 16.0f; point.p.y = -32.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 1.0f;
    mCounterPoly.vertexes.push_back(point);
    point.p.x = 0.0f;  point.p.y = -32.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;   point.c.b = 1.0f; point.c.a =  1.0f;
    point.t.x = 0.0f;  point.t.y = 1.0f;
    mCounterPoly.vertexes.push_back(point);
}



GuiCounter::~GuiCounter()
{
    std::map<int, int>::iterator i;

    for (i = mCounterTexId.begin(); i != mCounterTexId.end(); ++i)
    {
        DISPLAY->DeleteTexture((*i).second);
    }
}



void
GuiCounter::DrawCounter(const int &x, const int &y, const RString &string)
{
    DISPLAY->PushMatrix();
    DISPLAY->Translate(x, -y, 0);

    for (int i = 0; i < string.size(); ++i)
    {
        std::map<int, int>::const_iterator tile = mCounterTexId.find(static_cast<int>(string[i]));

        if (tile == mCounterTexId.end())
        {
            LOGGER->Log(LOGGER_WARNING, "Unidentify counter type %02x.", string[i]);
        }
        else
        {
            DISPLAY->SetTexture((*tile).second);
            DISPLAY->DrawQuads(mCounterPoly);
            DISPLAY->UnsetTexture();

            if ((*tile).first == 0x20 || (*tile).first == 0x3A)
            {
                DISPLAY->Translate(8.0f, 0, 0);
            }
            else
            {
                DISPLAY->Translate(16.0f, 0, 0);
            }
        }
    }

    DISPLAY->PopMatrix();
}
