// $Id: GameState.h 94 2006-11-12 19:44:43Z crazy_otaku $

#ifndef GAMESTATE_H
#define GAMESTATE_H
// The Gamestate Class : Contain all info about current game state

#include "common/display/3dTypes.h"
#include "common/utilites/NoCopy.h"

#include "Player.h"
#include "Savemap.h"
#include "gui/FFVIIString.h"
#include "ffvii/filesystem/File.h"

// forward declaration
class Kernel;
class MemoryBank;



class GameState : public NoCopy<GameState>
{
    friend class Kernel;
    friend class MemoryBank;

public:
                       GameState(void);
    virtual           ~GameState(void);

    const Savemap&     GetSavemap(void) const;
    void               LoadSavemap(File* file);
    void               DumpSavemap(void);

    void               Update(void);

    // memory bank handling
    void               MemoryBankPut(const u8& memoryBank, const u8& offset, const u8& value);
    void               MemoryBankPut(const u8& memoryBank, const u8& offset, const u16& value);
    u8                 MemoryBankGet(const u8& memoryBank, const u8& offset);
    u16                MemoryBankGet(const u8& memoryBank, const u16& offset);

    // map
    const u16&         CurrentFieldGet(void);
    void               CurrentFieldSet(const u16& currentMap);
    FFVIIString        CurrentFieldNameGet(void);
    void               CurrentFieldNameSet(FFVIIString name);

    // party
    void               PartyCharacterAdd(const u8& ubCharacter);
    void               PartyCharactersAdd(const u8& ubCharacter1, const u8& ubCharacter2, const u8& ubCharacter3);

    // timer
    void               TimerStart(void);
    void               TimerStop(void);

    // playerPlayer
    void               SetPlayerLoad(const bool load);
    const bool         GetPlayerLoad(void) const;
    void               SetPlayerPosition(const Vector3& position);
    const Vector3&     GetPlayerPosition(void) const;
    void               SetPlayerDirection(const float direction);
    const float        GetPlayerDirection(void) const;

private:
    // global values
    Savemap                       m_Savemap;

    // game timer
    bool                          mTimerStarted;

    // temp memory bank 5/6
    u8*                           mpMemoryBank56;

    // player unit stats
    Player                        m_Player;

    // map load related
    bool                          m_PlayerLoad;
    Vector3                       m_PlayerPosition;
    float                         m_PlayerDirection;
};



// Visible from every part of programm
extern GameState* GAMESTATE;



#endif // GAMESTATE_H
