// $Id: Kernel.h 103 2006-11-26 07:19:38Z crazy_otaku $

#ifndef KERNEL_H
#define KERNEL_H

#include "common/utilites/NoCopy.h"
#include "common/utilites/StdString.h"

#include "gui/BattleFont.h"
#include "gui/DialogWindow.h"
#include "gui/Font.h"
#include "gui/FFVIIString.h"
#include "gui/GuiAvatar.h"
#include "gui/GuiBar.h"
#include "gui/GuiBarExp.h"
#include "gui/GuiCounter.h"
#include "gui/GuiDigit.h"
#include "gui/GuiColorOverlay.h"
#include "gui/GuiPointer.h"
#include "gui/GuiSlash.h"
#include "gui/GuiMarkTriangle.h"



// maybe in gamestate?
struct GameButtons
{
    bool assist;
    bool start;
    bool up;
    bool right;
    bool down;
    bool left;
    bool camera;
    bool target;
    bool next;
    bool previous;
    bool menu;
    bool ok;
    bool cancel;
    bool switch_;
};



class Kernel : public NoCopy<Kernel>
{
public:
                       Kernel(void);
    virtual           ~Kernel(void);

    void               Init(void);
    void               Update(void);

    const GameButtons& GetGameButtonsCurrentState(void) const;
    const GameButtons& GetGameButtonsPreviousState(void) const;

    // battle
    const bool         BattleLockGet(void);
    void               BattleLockSet(const bool lock);
    // movie
    const bool         MovieLockGet(void);
    void               MovieLockSet(const bool lock);

    void               DrawAvatar(const int x, const int y, const unsigned char avatar_id);
    void               DrawBar(const int x, const int y, const unsigned int cur, const unsigned int max, const BarType& type);
    void               DrawBarExp(const int x, const int y, const unsigned int cur, const unsigned int max, const BarExpType& type);
    void               DrawBattleString(const RString& string, const int x, const int y, const BattleFontColor& color);
    void               DrawCounter(const int x, const int y, const RString& string);
    void               DrawDigit(const int x, const int y, const RString& string);
    void               DrawColorOverlay(const Color& color);
    void               DrawMarkTriangle(const int x, const int y, const u8 frame, const MarkTriangleColor& color);
    void               DrawPointer(const int x, const int y, const PointerType& type);
    void               DrawSlash(const int x, const int y);
    void               DrawString(const FFVIIString& string, const int x, const int y, const FontColor& color, const int size = 0);
    void               DrawWindow(const int x, const int y, const int width, const int height, const bool opacity);

private:
    void               InitGraphics(void);

    void               SetFrontScreen(void);
    void               UnsetFrontScreen(void);

private:
    GuiAvatar*          mGuiAvatar;
    GuiBar*             mGuiBar;
    GuiBarExp*          mGuiBarExp;
    GuiCounter*         mGuiCounter;
    GuiDigit*           mGuiDigit;
    GuiColorOverlay*    mGuiColorOverlay;
    GuiPointer*         mGuiPointer;
    GuiSlash*           mGuiSlash;
    GuiMarkTriangle*    mGuiMarkTriangle;
    BattleFont*         mBattleFont;
    Font*               mFont;
    DialogWindow*       mWindow;



    GameButtons         m_ButtonsCurrentState;
    GameButtons         m_ButtonsPreviousState;

    bool                m_BattleLock;
    bool                m_MovieLock;
};



// Visible from every part of programm
extern Kernel* KERNEL;



#endif // KERNEL_H
