// $Id: GameState.cpp 147 2007-02-24 06:13:17Z super_gb $

#include <memory.h>

#include "GameState.h"
#include "Savemap.h"
#include "common/utilites/Logger.h"



GameState* GAMESTATE = NULL; // global and accessable from anywhere in our program



GameState::GameState():
    mTimerStarted(false),

    mpMemoryBank56(NULL),

    m_PlayerLoad(false),
    m_PlayerPosition(0.0f, 0.0f, 0.0f),
    m_PlayerDirection(0.0f)
{
    mpMemoryBank56 = (u8*)malloc(sizeof(u8) * 256);
}



GameState::~GameState()
{
    free(mpMemoryBank56);
}



const Savemap&
GameState::GetSavemap() const
{
    return m_Savemap;
}



void
GameState::LoadSavemap(File* file)
{
    Uint8* temp = reinterpret_cast<Uint8*>(&m_Savemap);
    file->GetFileBuffer(temp, 0, file->GetFileSize());
}



void
GameState::DumpSavemap()
{
    LOGGER->Log(LOGGER_INFO, "Checksum: %08x\n\n", m_Savemap.Checksum);

    LOGGER->Log(LOGGER_INFO, "Preview\n");

    LOGGER->Log(LOGGER_INFO, "PreviewLeadCharacterLevel: %d", m_Savemap.PreviewLeadCharacterLevel);
    LOGGER->Log(LOGGER_INFO, "PreviewLeadCharacterPortrait: %02x", m_Savemap.PreviewLeadCharacterPortrait);
    LOGGER->Log(LOGGER_INFO, "PreviewSecondCharacterPortrait: %02x", m_Savemap.PreviewSecondCharacterPortrait);
    LOGGER->Log(LOGGER_INFO, "PreviewThirdCharacterPortrait: %02x", m_Savemap.PreviewThirdCharacterPortrait);
    LOGGER->Log(LOGGER_INFO, "PreviewLeadCharacterName[16] --- skip");
    LOGGER->Log(LOGGER_INFO, "PreviewLeadCharacterCurrentHP: %d", m_Savemap.PreviewLeadCharacterCurrentHP);
    LOGGER->Log(LOGGER_INFO, "PreviewLeadCharacterMaxHP: %d", m_Savemap.PreviewLeadCharacterMaxHP);
    LOGGER->Log(LOGGER_INFO, "PreviewLeadCharacterCurrentMP: %d", m_Savemap.PreviewLeadCharacterCurrentMP);
    LOGGER->Log(LOGGER_INFO, "PreviewLeadCharacterMaxMP: %d", m_Savemap.PreviewLeadCharacterMaxMP);
    LOGGER->Log(LOGGER_INFO, "PreviewGilAmount: %d", m_Savemap.PreviewGilAmount);
    LOGGER->Log(LOGGER_INFO, "PreviewPlayedSeconds: %d", m_Savemap.PreviewPlayedSeconds);
    LOGGER->Log(LOGGER_INFO, "PreviewCurrentLocationName[32] --- skip\n\n");

    LOGGER->Log(LOGGER_INFO, "Window RGB\n\n");

    LOGGER->Log(LOGGER_INFO, "Character Record\n");
    for (int i = 0; i < 9; ++i)
    {
        switch (i)
        {
            case 0: LOGGER->Log(LOGGER_INFO, "Cloud\n");  break;
            case 1: LOGGER->Log(LOGGER_INFO, "Barret\n"); break;
            case 2: LOGGER->Log(LOGGER_INFO, "Tifa\n"); break;
            case 3: LOGGER->Log(LOGGER_INFO, "Aeris\n"); break;
            case 4: LOGGER->Log(LOGGER_INFO, "RedXIII\n"); break;
            case 5: LOGGER->Log(LOGGER_INFO, "Yuffie\n"); break;
            case 6: LOGGER->Log(LOGGER_INFO, "CaitSith\n"); break;
            case 7: LOGGER->Log(LOGGER_INFO, "Vinsent\n"); break;
            case 8: LOGGER->Log(LOGGER_INFO, "Cid\n"); break;
        }

        LOGGER->Log(LOGGER_INFO, "Id: %02x", m_Savemap.Character[i].Id);
        LOGGER->Log(LOGGER_INFO, "Level: %d", m_Savemap.Character[i].Level);
        LOGGER->Log(LOGGER_INFO, "Strength: %d", m_Savemap.Character[i].Strength);
        LOGGER->Log(LOGGER_INFO, "Vitality: %d", m_Savemap.Character[i].Vitality);
        LOGGER->Log(LOGGER_INFO, "Magic: %d", m_Savemap.Character[i].Magic);
        LOGGER->Log(LOGGER_INFO, "Spirit: %d", m_Savemap.Character[i].Spirit);
        LOGGER->Log(LOGGER_INFO, "Dexterity: %d", m_Savemap.Character[i].Dexterity);
        LOGGER->Log(LOGGER_INFO, "Luck: %d", m_Savemap.Character[i].Luck);
        LOGGER->Log(LOGGER_INFO, "StrengthBonus: %d", m_Savemap.Character[i].StrengthBonus);
        LOGGER->Log(LOGGER_INFO, "VitalityBonus: %d", m_Savemap.Character[i].VitalityBonus);
        LOGGER->Log(LOGGER_INFO, "MagicBonus: %d", m_Savemap.Character[i].MagicBonus);
        LOGGER->Log(LOGGER_INFO, "SpiritBonus: %d", m_Savemap.Character[i].SpiritBonus);
        LOGGER->Log(LOGGER_INFO, "DexterityBonus: %d", m_Savemap.Character[i].DexterityBonus);
        LOGGER->Log(LOGGER_INFO, "LuckBonus: %d", m_Savemap.Character[i].LuckBonus);
        LOGGER->Log(LOGGER_INFO, "CurrentLimitLevel: %d", m_Savemap.Character[i].CurrentLimitLevel);
        LOGGER->Log(LOGGER_INFO, "CurrentLimitBar: %d", m_Savemap.Character[i].CurrentLimitBar);
        LOGGER->Log(LOGGER_INFO, "Name --- skip");
        LOGGER->Log(LOGGER_INFO, "EquippedWeapon: %02x", m_Savemap.Character[i].EquippedWeapon);
        LOGGER->Log(LOGGER_INFO, "EquippedArmor: %02x", m_Savemap.Character[i].EquippedArmor);
        LOGGER->Log(LOGGER_INFO, "EquippedAccessory: %02x", m_Savemap.Character[i].EquippedAccessory);
        LOGGER->Log(LOGGER_INFO, "StatusFlags: %02x", m_Savemap.Character[i].StatusFlags);
        LOGGER->Log(LOGGER_INFO, "RowFlags: %02x", m_Savemap.Character[i].RowFlags);
        LOGGER->Log(LOGGER_INFO, "LevelProgressBar: %02x", m_Savemap.Character[i].LevelProgressBar);
        LOGGER->Log(LOGGER_INFO, "LearnedLimitSkills: %04x", m_Savemap.Character[i].LearnedLimitSkills);
        LOGGER->Log(LOGGER_INFO, "NumberOfKills: %d", m_Savemap.Character[i].NumberOfKills);
        LOGGER->Log(LOGGER_INFO, "TimesUsedLimit11: %d", m_Savemap.Character[i].TimesUsedLimit11);
        LOGGER->Log(LOGGER_INFO, "TimesUsedLimit21: %d", m_Savemap.Character[i].TimesUsedLimit21);
        LOGGER->Log(LOGGER_INFO, "TimesUsedLimit31: %d", m_Savemap.Character[i].TimesUsedLimit31);
        LOGGER->Log(LOGGER_INFO, "CurrentHP: %d", m_Savemap.Character[i].CurrentHP);
        LOGGER->Log(LOGGER_INFO, "BaseHP: %d", m_Savemap.Character[i].BaseHP);
        LOGGER->Log(LOGGER_INFO, "CurrentMP: %d", m_Savemap.Character[i].CurrentMP);
        LOGGER->Log(LOGGER_INFO, "BaseMP: %d", m_Savemap.Character[i].BaseMP);
        LOGGER->Log(LOGGER_INFO, "Unknown1[4]: %02x %02x %02x %02x", m_Savemap.Character[i].Unknown1[0], m_Savemap.Character[i].Unknown1[1], m_Savemap.Character[i].Unknown1[2], m_Savemap.Character[i].Unknown1[3]);
        LOGGER->Log(LOGGER_INFO, "MaximumHP: %d", m_Savemap.Character[i].MaximumHP);
        LOGGER->Log(LOGGER_INFO, "MaximumMP: %d", m_Savemap.Character[i].MaximumMP);
        LOGGER->Log(LOGGER_INFO, "CurrentEXP: %d", m_Savemap.Character[i].CurrentEXP);
        LOGGER->Log(LOGGER_INFO, "WeaponMateriaSlot: %08x %08x %08x %08x %08x %08x %08x %08x", m_Savemap.Character[i].WeaponMateriaSlot1, m_Savemap.Character[i].WeaponMateriaSlot2, m_Savemap.Character[i].WeaponMateriaSlot3, m_Savemap.Character[i].WeaponMateriaSlot4, m_Savemap.Character[i].WeaponMateriaSlot5, m_Savemap.Character[i].WeaponMateriaSlot6, m_Savemap.Character[i].WeaponMateriaSlot7, m_Savemap.Character[i].WeaponMateriaSlot8);
        LOGGER->Log(LOGGER_INFO, "ArmorMateriaSlot: %08x %08x %08x %08x %08x %08x %08x %08x", m_Savemap.Character[i].ArmorMateriaSlot1, m_Savemap.Character[i].ArmorMateriaSlot2, m_Savemap.Character[i].ArmorMateriaSlot3, m_Savemap.Character[i].ArmorMateriaSlot4, m_Savemap.Character[i].ArmorMateriaSlot5, m_Savemap.Character[i].ArmorMateriaSlot6, m_Savemap.Character[i].ArmorMateriaSlot7, m_Savemap.Character[i].ArmorMateriaSlot8);
        LOGGER->Log(LOGGER_INFO, "NextLevelEXP: %d\n\n", m_Savemap.Character[i].NextLevelEXP);
    }

    LOGGER->Log(LOGGER_INFO, "Slot1Char: %02x", m_Savemap.Slot1Char);
    LOGGER->Log(LOGGER_INFO, "Slot2Char: %02x", m_Savemap.Slot2Char);
    LOGGER->Log(LOGGER_INFO, "Slot3Char: %02x", m_Savemap.Slot3Char);

    LOGGER->Log(LOGGER_INFO, "GilAmount: %d", m_Savemap.GilAmount);
    LOGGER->Log(LOGGER_INFO, "PlayedSeconds: %d", m_Savemap.PlayedSeconds);
    LOGGER->Log(LOGGER_INFO, "Unknown2[16]: %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x", m_Savemap.Unknown2[0], m_Savemap.Unknown2[1], m_Savemap.Unknown2[2], m_Savemap.Unknown2[3], m_Savemap.Unknown2[4], m_Savemap.Unknown2[5], m_Savemap.Unknown2[6], m_Savemap.Unknown2[7], m_Savemap.Unknown2[8], m_Savemap.Unknown2[9], m_Savemap.Unknown2[10], m_Savemap.Unknown2[11], m_Savemap.Unknown2[12], m_Savemap.Unknown2[13], m_Savemap.Unknown2[14], m_Savemap.Unknown2[15]);
    LOGGER->Log(LOGGER_INFO, "CurrentMap: %d", m_Savemap.CurrentMap);
    LOGGER->Log(LOGGER_INFO, "CurrentField: %d", m_Savemap.CurrentField);
    LOGGER->Log(LOGGER_INFO, "Unknown3[2]: %02x %02x", m_Savemap.Unknown3[0], m_Savemap.Unknown3[1]);
    LOGGER->Log(LOGGER_INFO, "MapLocationX: %d", m_Savemap.MapLocationX);
    LOGGER->Log(LOGGER_INFO, "MapLocationY: %d", m_Savemap.MapLocationY);
    LOGGER->Log(LOGGER_INFO, "MapLocationZ: %d", m_Savemap.MapLocationZ);
    LOGGER->Log(LOGGER_INFO, "Unknown4[4]: %02x %02x %02x %02x", m_Savemap.Unknown4[0], m_Savemap.Unknown4[1], m_Savemap.Unknown4[2], m_Savemap.Unknown4[3]);

    LOGGER->Log(LOGGER_INFO, "\n\nConfig\n");

    LOGGER->Log(LOGGER_INFO, "BattleSpeed: %02x", m_Savemap.BattleSpeed);
    LOGGER->Log(LOGGER_INFO, "BattleMessageSpeed: %02x", m_Savemap.BattleMessageSpeed);
    LOGGER->Log(LOGGER_INFO, "GeneralConfiguration: %04x", m_Savemap.GeneralConfiguration);
    LOGGER->Log(LOGGER_INFO, "UnknownFE[16]: %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x %02x", m_Savemap.UnknownFE[0], m_Savemap.UnknownFE[1], m_Savemap.UnknownFE[2], m_Savemap.UnknownFE[3], m_Savemap.UnknownFE[4], m_Savemap.UnknownFE[5], m_Savemap.UnknownFE[6], m_Savemap.UnknownFE[7], m_Savemap.UnknownFE[8], m_Savemap.UnknownFE[9], m_Savemap.UnknownFE[10], m_Savemap.UnknownFE[11], m_Savemap.UnknownFE[12], m_Savemap.UnknownFE[13], m_Savemap.UnknownFE[14], m_Savemap.UnknownFE[15]);
    LOGGER->Log(LOGGER_INFO, "MessageSpeed: %02x", m_Savemap.MessageSpeed);
    LOGGER->Log(LOGGER_INFO, "UnknownFF[7]: %02x %02x %02x %02x %02x %02x %02x", m_Savemap.UnknownFF[0], m_Savemap.UnknownFF[1], m_Savemap.UnknownFF[2], m_Savemap.UnknownFF[3], m_Savemap.UnknownFF[4], m_Savemap.UnknownFF[5], m_Savemap.UnknownFF[6]);
}



void
GameState::MemoryBankPut(const u8& memoryBank, const u8& offset, const u8& value)
{
    switch (memoryBank)
    {
        // savemap bank
        case 0x1 : case 0x2 : m_Savemap.MemoryBank12[offset] = value; break;
        case 0x3 : case 0x4 : m_Savemap.MemoryBank34[offset] = value; break;
        case 0x7 : case 0xF : m_Savemap.MemoryBank7F[offset] = value; break;
        case 0xB : case 0xC : m_Savemap.MemoryBankBC[offset] = value; break;
        case 0xD : case 0xE : m_Savemap.MemoryBankDE[offset] = value; break;
        // temp bank
        case 0x5 : case 0x6 : mpMemoryBank56[offset] = value;                               break;
    }
}



void
GameState::MemoryBankPut(const u8& memoryBank, const u8& offset, const u16& value)
{
    if (offset == 255)
    {
        LOGGER->Log(LOGGER_INFO, "Try to put u16 value in last byte in MemoryBank::Put();.");
        return;
    }

    u8 lower = static_cast<u8>(value & 0x00FF);
    u8 upper = static_cast<u8>(value >> 8);

//LOGGER->Log(LOGGER_INFO, "Put: memoryBank %d, offset %d, Upper: %02x, Lower: %02x", memoryBank, offset, upper, lower);

    switch (memoryBank)
    {
        // savemap bank
        case 0x1 : case 0x2 : m_Savemap.MemoryBank12[offset] = lower;
                              m_Savemap.MemoryBank12[offset + 1] = upper; break;
        case 0x3 : case 0x4 : m_Savemap.MemoryBank34[offset] = lower;
                              m_Savemap.MemoryBank34[offset + 1] = upper; break;
        case 0x7 : case 0xF : m_Savemap.MemoryBank7F[offset] = lower;
                              m_Savemap.MemoryBank7F[offset + 1] = upper; break;
        case 0xB : case 0xC : m_Savemap.MemoryBankBC[offset] = lower;
                              m_Savemap.MemoryBankBC[offset + 1] = upper; break;
        case 0xD : case 0xE : m_Savemap.MemoryBankDE[offset] = lower;
                              m_Savemap.MemoryBankDE[offset + 1] = upper; break;
        // temp bank
        case 0x5 : case 0x6 : mpMemoryBank56[offset] = lower;
                              mpMemoryBank56[offset + 1] = upper;                               break;
    }
}



u8
GameState::MemoryBankGet(const u8& memoryBank, const u8& offset)
{
    u8 ret = 0;

    switch (memoryBank)
    {
        // savemap bank
        case 0x1 : case 0x2 : ret = m_Savemap.MemoryBank12[offset]; break;
        case 0x3 : case 0x4 : ret = m_Savemap.MemoryBank34[offset]; break;
        case 0x7 : case 0xF : ret = m_Savemap.MemoryBank7F[offset]; break;
        case 0xB : case 0xC : ret = m_Savemap.MemoryBankBC[offset]; break;
        case 0xD : case 0xE : ret = m_Savemap.MemoryBankDE[offset]; break;
        // temp bank
        case 0x5 : case 0x6 : ret = mpMemoryBank56[offset];                                   break;
        // immediate value
        case 0x0 : ret = offset;
    }

    return ret;
}



u16
GameState::MemoryBankGet(const u8& memoryBank, const u16& offset)
{
    u16 ret = 0;

    if (memoryBank != 0 && offset == 255)
    {
        LOGGER->Log(LOGGER_INFO, "Try to get u16 value from last byte in MemoryBank::Get();.");
        return ret;
    }

    u16 lower = 0;
    u16 upper = 0;

    switch (memoryBank)
    {
        // savemap bank
        case 0x1 : case 0x2 : lower = m_Savemap.MemoryBank12[offset];
                              upper = m_Savemap.MemoryBank12[offset + 1]; break;
        case 0x3 : case 0x4 : lower = m_Savemap.MemoryBank34[offset];
                              upper = m_Savemap.MemoryBank34[offset + 1]; break;
        case 0x7 : case 0xF : lower = m_Savemap.MemoryBank7F[offset];
                              upper = m_Savemap.MemoryBank7F[offset + 1]; break;
        case 0xB : case 0xC : lower = m_Savemap.MemoryBankBC[offset];
                              upper = m_Savemap.MemoryBankBC[offset + 1]; break;
        case 0xD : case 0xE : lower = m_Savemap.MemoryBankDE[offset];
                              upper = m_Savemap.MemoryBankDE[offset + 1]; break;
        // temp bank
        case 0x5 : case 0x6 : lower = mpMemoryBank56[offset];
                              upper = mpMemoryBank56[offset + 1];                               break;
        // immediate value
        case 0x0 :            ret = offset;
    }

//LOGGER->Log(LOGGER_INFO, "Get: memoryBank %d, offset %d, Upper: %02x, Lower: %02x", memoryBank, offset, upper, lower);

    // swap bytes
    if (upper != 0 || lower != 0)
    {
        ret = (upper << 8) | (lower);
    }

    return ret;
}



const u16&
GameState::CurrentFieldGet(void)
{
    return m_Savemap.CurrentField;
}



void
GameState::CurrentFieldSet(const u16& currentMap)
{
    m_Savemap.CurrentField = currentMap;
}



FFVIIString
GameState::CurrentFieldNameGet(void)
{
    FFVIIString location_name;

    location_name.resize(24);

    std::copy(&(m_Savemap.MemoryBankDE[104]),
              &(m_Savemap.MemoryBankDE[104 + 24]),
              location_name.begin());

    return location_name;
}



void
GameState::CurrentFieldNameSet(FFVIIString name)
{
    for (u8 i = 0; i < 24; ++i)
    {
        if (i < name.size())
        {
            m_Savemap.MemoryBankDE[i + 104] = name[i];
        }
        else
        {
            m_Savemap.MemoryBankDE[i + 104] = 0x00;
        }
    }
}



void
GameState::PartyCharacterAdd(const u8& ubCharacter)
{
    if (ubCharacter != 0xFF &&
        ubCharacter != m_Savemap.Slot1Char &&
        ubCharacter != m_Savemap.Slot2Char &&
        ubCharacter != m_Savemap.Slot3Char)
    {
        if (m_Savemap.Slot1Char == 0xFF)
        {
            m_Savemap.Slot1Char = ubCharacter;
        }
        else if (m_Savemap.Slot2Char == 0xFF)
        {
            m_Savemap.Slot2Char = ubCharacter;
        }
        else
        {
            m_Savemap.Slot3Char = ubCharacter;
        }
    }
}



void
GameState::PartyCharactersAdd(const u8& ubCharacter1, const u8& ubCharacter2, const u8& ubCharacter3)
{
    m_Savemap.Slot1Char = (ubCharacter1 == 0xFE) ? 0xFF : ubCharacter1;
    m_Savemap.Slot2Char = (ubCharacter2 == 0xFE) ? 0xFF : ubCharacter2;
    m_Savemap.Slot3Char = (ubCharacter3 == 0xFE) ? 0xFF : ubCharacter3;
}



void
GameState::TimerStart(void)
{
    mTimerStarted = true;
}



void
GameState::TimerStop(void)
{
    mTimerStarted = false;
}



void
GameState::Update(void)
{
    // one second pass
    static unsigned char timer = 0;
    ++timer;
    if (timer == 100)
    {
        // move game time forward
        ++m_Savemap.PlayedSeconds;
        timer = 0;



        // count down timer if enabled
        if (mTimerStarted == true)
        {
            // if seconds are ended but we have minutes or hours
            if (m_Savemap.MemoryBank12[0x17] == 0 && (m_Savemap.MemoryBank12[0x16] != 0 || m_Savemap.MemoryBank12[0x15] != 0))
            {
                // if minutes are ended but we have hours
                if (m_Savemap.MemoryBank12[0x16] == 0 && m_Savemap.MemoryBank12[0x15] != 0)
                {
                    --m_Savemap.MemoryBank12[0x15];
                    m_Savemap.MemoryBank12[0x16] = 60;
                }

                --m_Savemap.MemoryBank12[0x16];
                m_Savemap.MemoryBank12[0x17] = 60;
            }

            // if we have seconds to go down
            if (m_Savemap.MemoryBank12[0x17] != 0)
            {
                --(m_Savemap.MemoryBank12[0x17]);
            }
            // else stop timer
            else
            {
                mTimerStarted = false;
            }
        }
    }
}



void
GameState::SetPlayerLoad(const bool load)
{
    m_PlayerLoad = load;
}



const bool
GameState::GetPlayerLoad(void) const
{
    return m_PlayerLoad;
}



void
GameState::SetPlayerPosition(const Vector3& position)
{
    m_PlayerPosition = position;
}



const Vector3&
GameState::GetPlayerPosition(void) const
{
    return m_PlayerPosition;
}



void
GameState::SetPlayerDirection(const float direction)
{
    m_PlayerDirection = direction;
}



const float
GameState::GetPlayerDirection(void) const
{
    return m_PlayerDirection;
}
