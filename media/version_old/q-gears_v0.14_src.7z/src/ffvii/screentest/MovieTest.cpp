/* 
 * Movie Testing Module source file
 *
 * Copyright (C) (2006-2007) (Gennadiy Brich) <gennadiy.brich@gmail.com>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */



#include "MovieTest.h"



MovieTest::MovieTest():
	m_PlayingMovieId(1)
{
	Vertex point;
	point.p.x = 0.0f; point.p.y =  0.0f; point.p.z = 0.0f;
	point.c.r = 1.0f; point.c.g =  1.0f; point.c.b = 1.0f; point.c.a = 1.0f;
	point.t.x = 0.0f; point.t.y =  0.0f;
	m_Poly.vertexes.push_back(point);
	point.p.x = 1.0f; point.p.y =  0.0f; point.p.z = 0.0f;
	point.c.r = 1.0f; point.c.g =  1.0f; point.c.b = 1.0f; point.c.a = 1.0f;
	point.t.x = 1.0f; point.t.y =  0.0f;
	m_Poly.vertexes.push_back(point);
	point.p.x = 1.0f; point.p.y = -1.0f; point.p.z = 0.0f;
	point.c.r = 1.0f; point.c.g =  1.0f; point.c.b = 1.0f; point.c.a = 1.0f;
	point.t.x = 1.0f; point.t.y =  1.0f;
	m_Poly.vertexes.push_back(point);
	point.p.x = 0.0f; point.p.y = -1.0f; point.p.z = 0.0f;
	point.c.r = 1.0f; point.c.g =  1.0f; point.c.b = 1.0f; point.c.a = 1.0f;
	point.t.x = 0.0f; point.t.y =  1.0f;
	m_Poly.vertexes.push_back(point);
}


MovieTest::~MovieTest()
{
}


void MovieTest::Input(const InputEvent &input)
{
	switch(input.button)
	{
		case KEY_Cp:
			MOVIEMAN->Play();
			break;

		case KEY_Cf:
			MOVIEMAN->Pause();
			break;

		case KEY_Cs:
			MOVIEMAN->Stop();
			break;

		case KEY_Cb:
			if(!MOVIEMAN->IsPlaying())
			{
				if(m_PlayingMovieId > 1)
					m_PlayingMovieId--;
				MOVIEMAN->SetMovieToPlay(m_PlayingMovieId);
			}
			break;

		case KEY_Cn:
			if(!MOVIEMAN->IsPlaying())
			{
				if(m_PlayingMovieId < 51)
					m_PlayingMovieId++;
				MOVIEMAN->SetMovieToPlay(m_PlayingMovieId);
			}
			break;

		case KEY_Cz:
			MOVIEMAN->Stop();
			MODULEMAN->PopTopModule();
	}
}


void MovieTest::Update(const Uint32 delta_time)
{
}


void MovieTest::Draw() const
{
	KERNEL->DrawWindow(10, 2, 150, 23, false);
	KERNEL->DrawString(RStringToFFVIIString("Movie Viewer Module"),
		20, 9, F_WHITE);
	KERNEL->DrawWindow(10, 25, 150, 100, false);
	KERNEL->DrawString(RStringToFFVIIString("Controls: "), 20, 30, F_WHITE);
	KERNEL->DrawString(RStringToFFVIIString("P - Play"), 20, 45, F_WHITE);
	KERNEL->DrawString(RStringToFFVIIString("F - Freeze"), 20, 60, F_WHITE);
	KERNEL->DrawString(RStringToFFVIIString("S - Stop"), 20, 75, F_WHITE);
	KERNEL->DrawString(RStringToFFVIIString("N - Next"), 20, 90, F_WHITE);
	KERNEL->DrawString(RStringToFFVIIString("B - Previous"), 20, 105, F_WHITE);

	if(MOVIEMAN->IsPlaying())
	{
		DISPLAY->PushMatrix();
		DISPLAY->LoadIdentity();
		DISPLAY->Translate(-1.0f, 1.0f, 0.0f);
		DISPLAY->Scale(3.2f, 2.286f, 1.0f);
		DISPLAY->CameraPushMatrix();
		DISPLAY->CameraLoadIdentity();
		DISPLAY->TextureLoadIdentity();
	
		DISPLAY->SetTexture(MOVIEMAN->GetFrameTextureId());
		DISPLAY->DrawQuads(m_Poly);
		DISPLAY->UnsetTexture();
	
		DISPLAY->CameraPopMatrix();
		DISPLAY->PopMatrix();
	}
}

