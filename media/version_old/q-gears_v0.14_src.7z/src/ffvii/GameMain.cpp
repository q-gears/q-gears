// $Id: GameMain.cpp 147 2007-02-24 06:13:17Z super_gb $

#include "common/filesystem/RealFileSystem.h"
#include "common/input/InputFilter.h"
#include "common/module/ModuleManager.h"
#include "common/movie/Movie.h"
#include "common/movie/MovieXmlFile.h"
#include "common/utilites/Logger.h"
#include "common/utilites/StdString.h"
#include "common/utilites/timer/Timer.h"
#include "common/utilites/timer/TimerSDL.h"

#include "GameDefine.h"
#include "GameMain.h"
#include "filesystem/GameFileSystem.h"
#include "kernel/DataBase.h"
#include "kernel/GameState.h"
#include "kernel/Kernel.h"
#include "field/FieldModule.h"




unsigned char  state;  /**< @brief global game state */



void
handle_input_events(void)
{
    INPUTFILTER->Update();

    static InputEventArray input_event_array;
    input_event_array.clear();
    INPUTFILTER->GetInputEvents(input_event_array);

    for (int i = 0; i < input_event_array.size(); ++i)
    {
        MODULEMAN->Input(input_event_array[i]);
    }
}



RString
game_title(void)
{
    RString title = APPLICATION_NAME;
    return title;
}



void
game_module_start(void)
{
    // load display test
    FieldModule* module = new FieldModule();
    MODULEMAN->PushModule(module);
}



void
game_main(void)
{
    LOGGER->Log(LOGGER_INFO, "Init game filesystem.");
    GAMEFILESYSTEM = new GameFileSystem();
    LOGGER->Log(LOGGER_INFO, "Game filesystem inited.");
    LOGGER->Log(LOGGER_INFO, "Init kernel.");
    KERNEL = new Kernel();
    KERNEL->Init();
    LOGGER->Log(LOGGER_INFO, "Kernel inited.");

    // game state init
    LOGGER->Log(LOGGER_INFO, "Init game state.");
    GAMESTATE = new GameState();
    File* save_file = new File(*REALFILESYSTEM, "data/savemap");
    GAMESTATE->LoadSavemap(save_file);
    delete save_file;
    LOGGER->Log(LOGGER_INFO, "Game state inited.");

    // database init
    LOGGER->Log(LOGGER_INFO, "Init game database.");
    DATABASE = new DataBase();
    LOGGER->Log(LOGGER_INFO, "Game database inited.");

    // movie player init
    LOGGER->Log(LOGGER_INFO, "Init movie player from data/MOVIE/movie.xml.");
    // we read data and add it to player during initialization
    {
        MovieXmlFile movie_data("data/MOVIE/movie.xml");
    }
    LOGGER->Log(LOGGER_INFO, "Movie player inited.");



    TimerSDL::InitTimer();
    Timer* timer = MakeTimer();
    unsigned int delta = 0;

    state = GAME;
    LOGGER->Log(LOGGER_INFO, "===================== Start the game!!!");
    while (state != EXIT)
    {
        // Handle all necessary game logic
        if (delta > 10)
        {
            KERNEL->Update();
            GAMESTATE->Update();
            MODULEMAN->Update(delta);
            MOVIEMAN->Update(delta);
            handle_input_events();
            MODULEMAN->Draw();
            delta = 0;
        }

        delta += timer->GetDeltaTime();
    }
    LOGGER->Log(LOGGER_INFO, "===================== Stop the game!!!");


    delete timer;
    TimerSDL::QuitTimer();



    delete DATABASE;
    delete GAMESTATE;
    delete KERNEL;
    delete GAMEFILESYSTEM;
    
    return;
}
