// $Id: MeshFile.cpp 93 2006-11-12 13:49:02Z einherjar $

#include "../../../common/utilites/Logger.h"
#include "../../filesystem/GameFileSystem.h"

#include "MeshFile.h"



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

MeshFile::MeshFile(const RString& file):
    File(*GAMEFILESYSTEM, file)
{
}



MeshFile::MeshFile(File* pFile):
    File(pFile)
{
}



MeshFile::MeshFile(File* pFile, const u32& offset, const u32& length):
    File(pFile, offset, length)
{
}



MeshFile::MeshFile(u8* pBuffer, const u32& offset, const u32& length):
    File(pBuffer, offset, length)
{
}



MeshFile::~MeshFile(void)
{
}



//============================= OPERATIONS ===================================

void
MeshFile::GetGeometry(std::vector<TotalGeometry>& resultGeometry, ModelUtilites::VectorTexForGen& textures)
{
    // clear the geometry array
    resultGeometry.clear();



    // numbers of subblock
    u32 block_count = GetU32LE(0);

    for (u32 i = 0; i < block_count; ++i)
    {
        // total geometry to insert into result
        TotalGeometry total_geometry;

        MeshBlockHeader* mesh_block_header = (MeshBlockHeader*)(mpBuffer + 0x10 + i * 0x38);

        // start position of vertex
        u32 start            = mesh_block_header->offset_to_vertex_block;
        // number of vertex
        u16 number_of_vertex = mesh_block_header->number_of_vertex;

        std::vector<Vector3> vertex;
        // add all vertex to structure
        for (int j = 0; j < number_of_vertex; ++j)
        {
            Vector3 v;
            v.x = -(s16)GetU16LE(start + 0);
            v.y = -(s16)GetU16LE(start + 2);
            v.z =  (s16)GetU16LE(start + 4);
            vertex.push_back(v);

            // go to the next vertex
            start += 8;
        }



        // start position of first mesh block
        start                    = mesh_block_header->offset_to_mesh_block;
        // number of mesh block
        u16 number_of_mesh_block = mesh_block_header->number_of_mesh_block;
        // start position of texture coords block
        u32 start_tex = GetU32LE(0x10 + i * 0x38 + 0x14);

        // used texture
        ModelUtilites::TexForGen texture_index;
        texture_index.texture_x = 0;
        texture_index.texture_y = 0;
        texture_index.palette_y = 0;
        texture_index.palette_x = 0;
        texture_index.bpp       = true;

        // texture index
        u8 tex_index = 0;

        Geometry geometry;

        for (int k = 0; k < number_of_mesh_block; ++k)
        {
            CommandPacket* command_packet = (CommandPacket*)(mpBuffer + start + 0x00);

            // number of mesh
            u16 number_of_mesh = GetU16LE(start + 0x02);
            start += 0x04;

            for (int j = 0; j < number_of_mesh; ++j)
            {
                // color for polygon
                Color color(1, 1, 1, 1);
                // if monochrome polygon
                bool monochrome = false;

                bool texture_changed = false;

                // if monochrome quad or triangle
                if (GetU8(start_tex + 0x03) == 0x20 ||
                    GetU8(start_tex + 0x03) == 0x22 ||
                    GetU8(start_tex + 0x03) == 0x28 ||
                    GetU8(start_tex + 0x03) == 0x30)
                {
                    // if this is the first monochrome polygon then change texture
                    if (monochrome == false)
                    {
                        monochrome = true;
                        texture_changed = true;
                    }
                    color.b = (float)GetU8(start_tex + 0x02) / 256.0f;
                    color.g = (float)GetU8(start_tex + 0x01) / 256.0f;
                    color.r = (float)GetU8(start_tex + 0x00) / 256.0f;

                    start_tex += 4;
                }
                else
                {
                    // if texture page settings
                    if (GetU8(start_tex + 0x03) == 0xC4)
                    {
                        texture_index.texture_x =  GetU16LE(start_tex) & 0x0F;
                        texture_index.texture_y = (GetU16LE(start_tex) >> 4) & 0x01;
                        texture_index.bpp       = (GetU16LE(start_tex) >> 7 == 1) ? true : false;
                        texture_changed = true;

                        start_tex += 4;
                    }
                    // if CLUT settings
                    if (GetU8(start_tex + 0x03) == 0xC8)
                    {
                        texture_index.palette_y = GetU16LE(start_tex) >> 6;
                        texture_index.palette_x = GetU16LE(start_tex) & 0x3F;
                        texture_changed = true;

                        start_tex += 4;
                    }
                }

                if (texture_changed)
                {
                    // if texture changed not to monochrome poly
                    if (monochrome != true)
                    {
                        tex_index = AddTexture(texture_index, textures);
                    }

                    texture_changed = false;
                    // if we set at least one polygon
                    if (j || k)
                    {
//                        total_geometry.GeometryVector.push_back(geometry);
//                        geometry.Clear();
                    }
                }


                // if command packet vertex data == 1 then this is quad
                if (command_packet->vertex == 1)
                {
                    Vertex v[4];

                    v[0].c = color; v[1].c = color; v[2].c = color; v[3].c = color;

                    if (monochrome == true)
                    {
                        monochrome = false;
//                        geometry.TexEnabled = false;
                    }
                    else
                    {
//                        geometry.TexIndex = tex_index;
//                        geometry.TexEnabled = true;

                        v[0].t[0] = GetU8(start_tex + 0x04);
                        v[0].t[1] = GetU8(start_tex + 0x05);
                        v[1].t[0] = GetU8(start_tex + 0x06);
                        v[1].t[1] = GetU8(start_tex + 0x07);
                        v[3].t[0] = GetU8(start_tex + 0x08);
                        v[3].t[1] = GetU8(start_tex + 0x09);
                        v[2].t[0] = GetU8(start_tex + 0x0A);
                        v[2].t[1] = GetU8(start_tex + 0x0B);

                        start_tex += 0x0C;
                    }

                    v[0].p = vertex[GetU16LE(start + 0x00)];
                    v[1].p = vertex[GetU16LE(start + 0x02)];
                    v[3].p = vertex[GetU16LE(start + 0x04)];
                    v[2].p = vertex[GetU16LE(start + 0x06)];

//                    geometry.AddQuad(v);
                }
                else // if (command_packet->vertex == 1)
                {
                    Vertex v[3];

                    v[0].c = color; v[1].c = color; v[2].c = color;

                    if (monochrome == true)
                    {
                        monochrome = false;
//                        geometry.TexEnabled = false;
                    }
                    else
                    {
//                        geometry.TexIndex = tex_index;
//                        geometry.TexEnabled = true;

                        v[2].t[0] = GetU8(start_tex + 0x00);
                        v[2].t[1] = GetU8(start_tex + 0x01);
                        v[0].t[0] = GetU8(start_tex + 0x04);
                        v[0].t[1] = GetU8(start_tex + 0x05);
                        v[1].t[0] = GetU8(start_tex + 0x06);
                        v[1].t[1] = GetU8(start_tex + 0x07);

                        start_tex += 0x08;
                    }

                    v[0].p = vertex[GetU16LE(start + 0x00)];
                    v[1].p = vertex[GetU16LE(start + 0x02)];
                    v[2].p = vertex[GetU16LE(start + 0x04)];

//                    geometry.AddTriangle(v);
                } // if (command_packet->vertex == 1)

                // go to the next mesh
                start += 0x08;
            } // for (int j = 0; j < number_of_mesh; j++)
        } // for (int k = 0; k < number_of_mesh_block; k++)

//        total_geometry.GeometryVector.push_back(geometry);
//        resultGeometry.push_back(total_geometry);
    } // for (u32 i = 0; i < block_count; i++)
}



u32
MeshFile::AddTexture(ModelUtilites::TexForGen& texture, ModelUtilites::VectorTexForGen& textures)
{
    u32 i = 0;
    for (; i < textures.size(); ++i)
    {
        if (texture == textures[i])
        {
            return i;
        }
    }

    textures.push_back(texture);

    return i;
}
