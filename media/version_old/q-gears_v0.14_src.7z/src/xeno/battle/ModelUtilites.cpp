#include "ModelUtilites.h"



Surface*
ModelUtilites::Gen256x256Tex(Surface* pClut, Surface* pVram, TexForGen texForGen)
{
    Surface* image = CreateSurface(256, 256);

    for (int y = 0; y < 256; ++y)
    {
        for (int x = 0; x < 256; ++x)
        {
            unsigned char clut_x;

            if (texForGen.bpp)
            {
                clut_x = *(pVram->pixels + (y + texForGen.texture_y * 256) * pVram->width * 4 + (x + texForGen.texture_x * 128));
            }
            else
            {
                if (x % 2)
                {
                    clut_x = ((*(pVram->pixels + (y + texForGen.texture_y * 256) * pVram->width * 4 + ((x >> 1) + texForGen.texture_x * 128))) >> 4) + texForGen.palette_x * 16;
                }
                else
                {
                    clut_x = ((*(pVram->pixels + (y + texForGen.texture_y * 256) * pVram->width * 4 + ((x >> 1) + texForGen.texture_x * 128))) & 0x0F) + texForGen.palette_x * 16;
                }
            }

            *(image->pixels + y * 256 * 4 + x * 4 + 0) = *(pClut->pixels + texForGen.palette_y * pClut->width * 4 + clut_x * 4 + 0);
            *(image->pixels + y * 256 * 4 + x * 4 + 1) = *(pClut->pixels + texForGen.palette_y * pClut->width * 4 + clut_x * 4 + 1);
            *(image->pixels + y * 256 * 4 + x * 4 + 2) = *(pClut->pixels + texForGen.palette_y * pClut->width * 4 + clut_x * 4 + 2);
            *(image->pixels + y * 256 * 4 + x * 4 + 3) = *(pClut->pixels + texForGen.palette_y * pClut->width * 4 + clut_x * 4 + 3);
        }
    }

    return image;
}



Surface*
ModelUtilites::Gen8bppTex(Surface* pClut, Surface* pVram, const u16& clutY)
{
    Surface* image = CreateSurface(pVram->width * 4, pVram->height);

    for (int y = 0; y < image->height; ++y)
    {
        for (int x = 0; x < image->width; ++x)
        {
            unsigned char clut_x;

            clut_x = *(pVram->pixels + y * pVram->width * 4 + x);

            *(image->pixels + y * image->width * 4 + x * 4 + 0) = *(pClut->pixels + clutY * pClut->width * 4 + clut_x * 4 + 0);
            *(image->pixels + y * image->width * 4 + x * 4 + 1) = *(pClut->pixels + clutY * pClut->width * 4 + clut_x * 4 + 1);
            *(image->pixels + y * image->width * 4 + x * 4 + 2) = *(pClut->pixels + clutY * pClut->width * 4 + clut_x * 4 + 2);
            *(image->pixels + y * image->width * 4 + x * 4 + 3) = *(pClut->pixels + clutY * pClut->width * 4 + clut_x * 4 + 3);
        }
    }

    return image;
}
