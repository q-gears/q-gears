// $Id: Model.h 93 2006-11-12 13:49:02Z einherjar $

/**
 * @brief Class for battle field model.
 */
#ifndef MODEL_h
#define MODEL_h

#include <vector>

#include "../../common/display/3dTypes.h"
#include "../../common/utilites/NoCopy.h"
#include "../../common/utilites/StdString.h"

#include "ModelUtilites.h"
#include "../filetypes/model/HrcFile.h"



class Model : public NoCopy<Model>
{
public:
// LIFECYCLE

    /**
     * @brief A constructor.
     *
     * Loads given file into memory.
     * @param pFile - pointer to file.
     */
    explicit Model(const RString& file);

    /**
     * @brief A destructor.
     */
    virtual ~Model(void);

// OPERATIONS

    /**
     * @brief Draw model.
     */
    void Draw(void);

private:
    std::vector<TotalGeometry>     mBlockMeshes; /**< @brief model geometry. It divided in block because each block may be used twice */
    HrcArray                       mHierarchy;   /**< @brief model part hierarchy */
    std::vector<u32>               mTex;         /**< @brief array of generated texture indexes */

    // temp
    ModelUtilites::VectorTexForGen mTexForGen;   /**< @brief array of texture data that needs to be generated */
};



#endif // MODEL_h
