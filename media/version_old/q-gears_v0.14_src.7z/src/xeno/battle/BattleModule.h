// $Id: BattleModule.h 93 2006-11-12 13:49:02Z einherjar $

/**
 * @brief Battle module.
 */

#ifndef BATTLE_MODULE_h
#define BATTLE_MODULE_h

#include <vector>

#include "Model.h"
#include "../../common/display/3dTypes.h"
#include "../../common/display/actor/Actor.h"



class BattleModule : public Actor
{
public:
// LIFECYCLE

    /**
     * @brief Default constructor.
     */
    BattleModule(void);

    /**
     * @brief Default destructor.
     */
    virtual ~BattleModule(void);

// OPERATIONS

    /**
     * @brief Init module.
     */
    virtual void Init(void);

    /**
     * @brief Draw module.
     */
    virtual void Draw(void);

    /**
     * @brief Handles input.
     *
     * @param input - single input event.
     */
    virtual void Input(const InputEvent &input);

    /**
     * @brief Handles update.
     *
     * @param deltaTime - time passed from last call.
     */
    virtual void Update(const u32& deltaTime);



private:
    std::vector<Vertex>     mAxis;

    Model*                  mBackgroundModel;
    u16                     mModelNumber;
};



#endif // BATTLE_MODULE_h
