// $Id: GameDefine.h 76 2006-08-25 18:41:20Z crazy_otaku $

#ifndef GAME_DEFINE_H
#define GAME_DEFINE_H



#define APPLICATION_NAME "XENO v0.01a"



#endif // GAME_DEFINE_H
