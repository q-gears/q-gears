// $Id: UnitManager.h 96 2006-11-13 03:34:17Z crazy_otaku $

/**
 * @brief Unit manager for field module.
 */

#ifndef UNIT_MANAGER_h
#define UNIT_MANAGER_h

#include <vector>

#include "../../common/TypeDefine.h"
#include "../../common/input/InputFilter.h"
#include "../../common/utilites/NoCopy.h"

class FieldModule;



struct WalkMeshTriangle
{
    WalkMeshTriangle(void):
        accessible(true)
    {
    }

    Vector3 A;
    Vector3 B;
    Vector3 C;

    u16    access[3];
    bool   accessible;
};



class UnitManager : public NoCopy<UnitManager>
{
public:
// LIFECYCLE

    UnitManager(FieldModule* pFieldModule);

    virtual ~UnitManager(void);

// OPERATIONS

    void Clear(void);

    void Draw(void);

    bool Input(const InputEvent& input);

    void Update(const u32& deltaTime);

    void AddWalkMeshTriangle(const WalkMeshTriangle& triangle);

private:
    FieldModule*                  mpFieldModule;  /**< @brief feed back to field module */

    std::vector<WalkMeshTriangle> mWalkMesh;
};



#endif // UNIT_MANAGER_h
