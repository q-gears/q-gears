// $Id: FieldModule.cpp 96 2006-11-13 03:34:17Z crazy_otaku $

#include "../../common/display/Display.h"
#include "../../common/filesystem/RealFileSystem.h"
#include "../../common/module/ModuleManager.h"
#include "../../common/utilites/Config.h"
#include "../../common/utilites/Logger.h"

#include "FieldModule.h"
#include "FieldPackFile.h"
#include "WalkMeshFile.h"



FieldModule::FieldModule():
    mViewAxis(true)
{
    mpUnitManager   = new UnitManager(this);

    Init();
}



FieldModule::~FieldModule()
{
    delete mpUnitManager;
}



void
FieldModule::Init()
{
    DISPLAY->SetZTestMode(ZTEST_WRITE_ON_PASS);
    DISPLAY->SetAlphaTest(true);
    DISPLAY->SetBlendMode(BLEND_PSX_1);
    DISPLAY->SetCullMode(CULL_NONE);

    Vertex point;
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 0.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 500.0f; point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 0.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 0.0f;   point.c.g = 1.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 500.0f; point.p.z = 0.0f;
    point.c.r = 0.0f;   point.c.g = 1.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 0.0f;   point.c.g = 0.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 500.0f;
    point.c.r = 0.0f;   point.c.g = 0.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    mAxis.push_back(point);



    // load map from savemap
    LoadMap(0);
}



void
FieldModule::LoadMap(const u16& id)
{
    // clear all managers
    mpUnitManager->Clear();



    // read info from DAT file
    FieldPackFile *field_pack  = new FieldPackFile("11/0610");

    // walkmesh
    LOGGER->Log(LOGGER_INFO, "Loading walkmesh from FieldFile.");
    File* temp = field_pack->Extract(1);
    WalkMeshFile* walkmesh_file = new WalkMeshFile(temp);
    delete temp;
    walkmesh_file->GetWalkMesh(mpUnitManager);



    delete field_pack;
}



void
FieldModule::Input(const InputEvent &input)
{
    // handle system input ourself
    if (input.type == IET_FIRST_PRESS)
    {
        switch (input.button)
        {
            case KEY_Cl:    mViewAxis       = (mViewAxis)       ? false : true; break;
        }
    }



    // give input to all unit on map
    if (mpUnitManager->Input(input) == true)
    {
        // if we handled input - return
        return;
    }
}



void
FieldModule::Update(const Uint32 delta_time)
{
    // update all units on map
    mpUnitManager->Update(delta_time);
}



void
FieldModule::Draw() const
{
    DISPLAY->LoadLookAt(50, Vector3(-1000, 3000, 1000), Vector3(0, 0, 0), Vector3(0, 1, 0));

    // draw axis
    if (mViewAxis == true)
    {
        DISPLAY->SetPointSize(3);
        DISPLAY->DrawPoints(mAxis);
        DISPLAY->SetLineWidth(1);
        DISPLAY->DrawLines(mAxis);
    }

    // draw all units on map
    DISPLAY->PushMatrix();
    mpUnitManager->Draw();
    DISPLAY->PopMatrix();
}
