// $Id: GameMain.h 94 2006-11-12 19:44:43Z crazy_otaku $

#ifndef GAME_MAIN_H
#define GAME_MAIN_H



enum
{
    EXIT,
    GAME
};

extern unsigned char state;



#endif // GAME_MAIN_H
