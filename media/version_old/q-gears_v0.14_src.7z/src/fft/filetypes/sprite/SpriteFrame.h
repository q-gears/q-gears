// $Id$

#ifndef SPRITE_FRAME_h
#define SPRITE_FRAME_h

#include <vector>

#include "../../../common/TypeDefine.h"
#include "../../../common/display/actor/Actor.h"

#include "SpriteTile.h"



class SpriteFrame : public Actor
{
public:
    SpriteFrame(void);

    virtual
    ~SpriteFrame(void);

    virtual void
    Init(void);

    virtual void
    Input(const InputEvent &input);

    virtual void
    Update(const Uint32 delta_time);

    virtual void
    Draw(void) const;

    void
    AddTile(SpriteTile* tile);

private:
    std::vector<SpriteTile*> m_Tiles;
};



#endif // SPRITE_FRAME_h
