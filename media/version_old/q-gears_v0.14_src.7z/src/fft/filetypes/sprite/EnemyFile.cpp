// $Id: TimFile.cpp 105 2006-12-02 00:07:47Z einherjar $

#include "../../../common/display/surface/SurfaceSaveBmp.h"
#include "../../../common/utilites/Logger.h"

#include "EnemyFile.h"
#include "../../filesystem/GameFileSystem.h"



EnemyFile::EnemyFile(const RString& file):
    File(*GAMEFILESYSTEM, file)
{
}



EnemyFile::EnemyFile(File* pFile):
    File(pFile)
{
}



EnemyFile::EnemyFile(File* pFile, const u32& offset, const u32& length):
    File(pFile, offset, length)
{
}



EnemyFile::EnemyFile(u8* pBuffer, const u32& offset, const u32& length):
    File(pBuffer, offset, length)
{
}



EnemyFile::~EnemyFile(void)
{
}



void
EnemyFile::LoadEnemies(SpriteAnimation& animation)
{
    // number of enemies
    Uint32 number_of_enemies = GetU32LE(0x00);

    for (Uint32 enemy_number = 0; enemy_number < 1/*number_of_enemies*/; ++enemy_number)
    {
        LOGGER->Log(LOGGER_INFO, "Start parse enemy %d", enemy_number);

        // enemy data block offset
        Uint32 enemy_offset     = GetU32LE(0x08 + enemy_number * 0x0C);

        Uint32 animation_offset = enemy_offset + GetU32LE(enemy_offset + 0x04);
        Uint32 frame_offset     = enemy_offset + GetU32LE(enemy_offset + 0x08);
        Uint32 palette_offset   = enemy_offset + GetU32LE(enemy_offset + 0x0C);

        // texture offset
        Uint32 tilesets_offset  = GetU32LE(0x08 + enemy_number * 0x0C + 0x04);

        LOGGER->Log(LOGGER_INFO, "Offsets: enemy_offset     = %08x", enemy_offset);
        LOGGER->Log(LOGGER_INFO, "         animation_offset = %08x", animation_offset);
        LOGGER->Log(LOGGER_INFO, "         frame_offset     = %08x", frame_offset);
        LOGGER->Log(LOGGER_INFO, "         palette_offset   = %08x", palette_offset);
        LOGGER->Log(LOGGER_INFO, "         tilesets_offset  = %08x", tilesets_offset);



        // read clut
        Uint16 number_of_clut    = GetU16LE(palette_offset + 0x00);
        Uint16 number_of_monster = GetU16LE(palette_offset + 0x02) + 1;
        LOGGER->Log(LOGGER_INFO, "Clut parsing: number_of_clut %d, number_of_monster = %d", number_of_clut, number_of_monster);

        Uint16 total_clut = number_of_clut * number_of_monster;
        LOGGER->Log(LOGGER_INFO, "              total_clut %d", total_clut);

        for (Uint16 y = 0; y < total_clut; ++y)
        {
            for (Uint16 x = 0; x < 16; ++x)
            {
                Uint16 color = GetU16LE(palette_offset + 0x04 + y * 32 + x * 2);
                // put it into 0,0 in VRam
                mVram.PutU16(x * 2, y, color);
            }
        }


        //Surface* vram = mVram.GetSurface();
        //SurfaceUtils::SaveBMP("vram.bmp", vram);
        //delete vram;


        // read texture
        Uint32 number_of_tilesets = GetU32LE(tilesets_offset + 0x00);
        LOGGER->Log(LOGGER_INFO, "Tileset parsing: number_of_tilesets %d", number_of_tilesets);

        // create set of tilesets for future use
        std::vector<Surface*> tilesets;

        for (Uint32 tileset_number = 0; tileset_number < number_of_tilesets; ++tileset_number)
        {
            Uint32 tileset_offset = tilesets_offset + GetU32LE(tilesets_offset + 0x04 + 0x04 * tileset_number);
            LOGGER->Log(LOGGER_INFO, "Offset to tileset %d: %08x", tileset_number, tileset_offset);

            Uint16 width  = GetU16LE(tileset_offset + 0x00) * 2;
            Uint16 height = GetU16LE(tileset_offset + 0x02);
            LOGGER->Log(LOGGER_INFO, "width %d, height %d", width, height);

            Uint16 vram_position = 256 * (tileset_number + 1);

            for (Uint16 y = 0; y < height; ++y)
            {
                for (Uint16 x = 0; x < width; ++x)
                {
                    Uint8 data = GetU8(tileset_offset + 0x04 + y * width + x);
                    // put it into 256,0 in VRam and each next tileset +256,0
                    mVram.PutU8(vram_position + x, y, data);
                }
            }



            for (Uint16 clut = 0; clut < number_of_clut; ++clut)
            {
                Surface* tileset = CreateSurface(width * 2, height);
                ClutColor color;

                for (Uint16 y = 0; y < height; ++y)
                {
                    for (Uint16 x = 0; x < width; ++x)
                    {
                        Uint16 real_x = vram_position + x;

                        Uint8 data = mVram.GetU8(real_x, y) & 0x0F;
                        Uint16 col = mVram.GetU16(data * 2, clut);

                        color.r = ((col      ) & 31) * 255 / 31;
                        color.g = ((col >>  5) & 31) * 255 / 31;
                        color.b = ((col >> 10) & 31) * 255 / 31;
                        Uint8 stp = (col & 0x80) >> 15;
                        if (col == 0x0000)
                        {
                            color.a = 0;
                        }
                        else if (stp == 1 && color.r == 0 && color.g == 0 && color.b == 0)
                        {
                            color.a = 127;
                        }
                        else if (stp == 1 && (color.r != 0 || color.g != 0 || color.b == 0))
                        {
                            color.a = 0;
                        }
                        else if (stp == 0 && (color.r != 0 || color.g != 0 || color.b == 0))
                        {
                            color.a = 255;
                        }

                        memcpy(tileset->pixels + x * 8 + tileset->width * 4 * y + 0x00, &color, sizeof(ClutColor));

                        data    = (mVram.GetU8(real_x, y) & 0xF0) >> 4;
                        col     = mVram.GetU16(data * 2, clut);

                        color.r = ((col      ) & 31) * 255 / 31;
                        color.g = ((col >>  5) & 31) * 255 / 31;
                        color.b = ((col >> 10) & 31) * 255 / 31;
                        stp = (col & 0x80) >> 15;
                        if (col == 0x0000)
                        {
                            color.a = 0;
                        }
                        else if (stp == 1 && color.r == 0 && color.g == 0 && color.b == 0)
                        {
                            color.a = 127;
                        }
                        else if (stp == 1 && (color.r != 0 || color.g != 0 || color.b == 0))
                        {
                            color.a = 0;
                        }
                        else if (stp == 0 && (color.r != 0 || color.g != 0 || color.b == 0))
                        {
                            color.a = 255;
                        }

                        memcpy(tileset->pixels + x * 8 + tileset->width * 4 * y + 0x04, &color, sizeof(ClutColor));
                    }
                }

                tilesets.push_back(tileset);
            }
        }



        ClutColor color;

        LOGGER->Log(LOGGER_INFO, "Start parse enemy %d animation.", enemy_number);
        Uint8 number_of_frames = GetU8(frame_offset);
        LOGGER->Log(LOGGER_INFO, "Number of frames: %d.", number_of_frames);

        for (Uint8 frame_number = 0; frame_number < number_of_frames; ++frame_number)
        {
            LOGGER->Log(LOGGER_INFO, "Start parse %d frame.", frame_number);

            SpriteFrame* sprite_frame = new SpriteFrame();

            Uint32 frame_start = frame_offset + GetU16LE(frame_offset + 0x02 + frame_number * 0x02);
            Uint8 number_of_tiles = GetU8(frame_start);
            LOGGER->Log(LOGGER_INFO, "Number of tiles: %d.", number_of_tiles);

            // current tile start
            Uint32 tile_in_frame_start = frame_start + 0x04 + number_of_tiles * 0x02;

            for (Uint8 tile_number = 0; tile_number < number_of_tiles; ++tile_number)
            {
                Uint8 clut = 0;

                for (Uint8 src = 0x00;;)
                {
                    src = GetU8(tile_in_frame_start + tile_number * 0x03);
                    if ((src >> 4) == 0x0E)
                    {
                        tile_in_frame_start += 3;
                    }
                    else if ((src >> 4) == 0x0C)
                    {
                        tile_in_frame_start += 1;
                    }
                    else if (src == 0x00)
                    {
                        clut = 0;
                        break;
                    }
                    else if (src == 0x01)
                    {
                        clut = 1;
                        break;
                    }
                    else
                    {
                        LOGGER->Log(LOGGER_INFO, "Strange tile flag %02x.", src);
                        break;
                    }
                }
                Uint16 tile_start = frame_offset + GetU16LE(frame_start + 0x04 + tile_number * 0x02);

                Uint8 tileset_number  = GetU8(tile_start + 0x00) >> 1;
                tileset_number        = tileset_number * number_of_clut + clut;
                tileset_number        = (tileset_number >= tilesets.size()) ? 0 : tileset_number;
                Uint8 tile_x          = GetU8(tile_start + 0x01);
                Uint8 tile_y          = GetU8(tile_start + 0x02);
                Uint8 tile_width      = GetU8(tile_start + 0x03);
                Uint8 tile_height     = GetU8(tile_start + 0x04);

                LOGGER->Log(LOGGER_INFO, "Tileset number: %d", tileset_number);
                LOGGER->Log(LOGGER_INFO, "Tile X:         %d", tile_x);
                LOGGER->Log(LOGGER_INFO, "Tile Y:         %d", tile_y);
                LOGGER->Log(LOGGER_INFO, "Tile Width:     %d", tile_width);
                LOGGER->Log(LOGGER_INFO, "Tile Height:    %d", tile_height);

                Surface* texture = CreateSurface(tile_width, tile_height);

                Uint8 tile_in_frame_x = GetU8(tile_in_frame_start + tile_number * 0x03 + 0x01);
                Uint8 tile_in_frame_y = GetU8(tile_in_frame_start + tile_number * 0x03 + 0x02);

                for (Uint8 y = 0; y < tile_height; ++y)
                {
                    for (Uint8 x = 0; x < tile_width; ++x)
                    {
                        texture->pixels[y * tile_width * 4 + x * 4 + 0] = tilesets[tileset_number]->pixels[(tile_y + y) * 1024 + (tile_x + x) * 4 + 0];
                        texture->pixels[y * tile_width * 4 + x * 4 + 1] = tilesets[tileset_number]->pixels[(tile_y + y) * 1024 + (tile_x + x) * 4 + 1];
                        texture->pixels[y * tile_width * 4 + x * 4 + 2] = tilesets[tileset_number]->pixels[(tile_y + y) * 1024 + (tile_x + x) * 4 + 2];
                        texture->pixels[y * tile_width * 4 + x * 4 + 3] = tilesets[tileset_number]->pixels[(tile_y + y) * 1024 + (tile_x + x) * 4 + 3];
                    }
                }

                SpriteTile* sprite_tile = new SpriteTile();
                sprite_tile->SetTexture(texture);
                sprite_tile->SetFrameX(tile_in_frame_x);
                sprite_tile->SetFrameY(tile_in_frame_y);
                sprite_frame->AddTile(sprite_tile);
                delete texture;
            }

            animation.AddFrame(sprite_frame);

            LOGGER->Log(LOGGER_INFO, "End parse %d frame.", frame_number);
        }



        LOGGER->Log(LOGGER_INFO, "End of parsing enemy\n");
    }
}
