// $Id$

#include "../../../common/display/Display.h"
#include "../../../common/utilites/Logger.h"
#include "../../../common/utilites/Utilites.h"

#include "SpriteTile.h"



SpriteTile::SpriteTile(void):
    m_FrameX(0),
    m_FrameY(0),
    m_TextureId(0),
    m_Width(0),
    m_Height(0)
{
    Init();
}



SpriteTile::~SpriteTile(void)
{
    DISPLAY->DeleteTexture(m_TextureId);
}



void
SpriteTile::Init(void)
{
    Vertex point;
    point.p.x =  0.0f; point.p.y =  0.0f; point.p.z = 0.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x =  0.0f; point.t.y =  0.0f;
    m_Quad.vertexes.push_back(point);
    point.p.x =  1.0f; point.p.y =  0.0f; point.p.z = 0.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x =  1.0f; point.t.y =  0.0f;
    m_Quad.vertexes.push_back(point);
    point.p.x =  1.0f; point.p.y = -1.0f; point.p.z = 0.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x =  1.0f; point.t.y =  1.0f;
    m_Quad.vertexes.push_back(point);
    point.p.x =  0.0f; point.p.y = -1.0f; point.p.z = 0.0f;
    point.c.r =  1.0f; point.c.g =  1.0f; point.c.b = 1.0f; point.c.a =  1.0f;
    point.t.x =  0.0f; point.t.y =  1.0f;
    m_Quad.vertexes.push_back(point);
}



void
SpriteTile::Input(const InputEvent &input)
{
}



void
SpriteTile::Update(const Uint32 delta_time)
{
}



void
SpriteTile::Draw(void) const
{
    DISPLAY->SetTexture(m_TextureId);
    DISPLAY->PushMatrix();
    DISPLAY->Translate(m_FrameX, -m_FrameY, 0.0f);
    DISPLAY->Scale(m_Width, m_Height, 0.0f);
    DISPLAY->DrawQuads(m_Quad);
    DISPLAY->PopMatrix();
    DISPLAY->UnsetTexture();
}



void
SpriteTile::SetFrameX(const Uint16 x)
{
    m_FrameX = x;
}



void
SpriteTile::SetFrameY(const Uint16 y)
{
    m_FrameY = y;
}



void
SpriteTile::SetTexture(Surface* texture)
{
    if (texture == NULL)
    {
        LOGGER->Log(LOGGER_ERROR,
			"SpriteTile::SetTexture: Receive NULL pointer to texture.");
    }

    m_Width  = power_of_two(texture->width);
    m_Height = power_of_two(texture->height);

    SetSurfaceSize(texture, m_Width, m_Height);

    m_TextureId = DISPLAY->CreateTexture(texture);
}
