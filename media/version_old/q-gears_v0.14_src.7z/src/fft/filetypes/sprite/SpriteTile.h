// $Id$

#ifndef SPRITE_TILE_h
#define SPRITE_TILE_h

#include "../../../common/TypeDefine.h"
#include "../../../common/display/3dTypes.h"
#include "../../../common/display/actor/Actor.h"
#include "../../../common/display/surface/Surface.h"



class SpriteTile : public Actor
{
public:
    SpriteTile(void);

    virtual
    ~SpriteTile(void);

    virtual void
    Init(void);

    virtual void
    Input(const InputEvent& input);

    virtual void
    Update(const Uint32 delta_time);

    virtual void
    Draw(void) const;

    void
    SetFrameX(const Uint16 x);

    void
    SetFrameY(const Uint16 y);

    void
    SetTexture(Surface* texture);

private:
    Uint16   m_FrameX;
    Uint16   m_FrameY;
    Uint32   m_TextureId;
    Uint16   m_Width;
    Uint16   m_Height;

    Geometry m_Quad;
};



#endif // SPRITE_TILE_h
