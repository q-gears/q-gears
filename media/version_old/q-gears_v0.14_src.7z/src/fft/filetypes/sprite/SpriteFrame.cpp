// $Id$

#include "../../../common/utilites/Logger.h"

#include "SpriteFrame.h"



SpriteFrame::SpriteFrame(void)
{
    Init();
}



SpriteFrame::~SpriteFrame(void)
{
    for (Uint32 i = 0; i < m_Tiles.size(); ++i)
    {
        delete m_Tiles[i];
    }
}



void
SpriteFrame::Init(void)
{
}



void
SpriteFrame::Input(const InputEvent &input)
{
}



void
SpriteFrame::Update(const Uint32 delta_time)
{
}



void
SpriteFrame::Draw(void) const
{
    for (Uint32 i = 0; i < m_Tiles.size(); ++i)
    {
        m_Tiles[i]->Draw();
    }
}



void
SpriteFrame::AddTile(SpriteTile* tile)
{
    m_Tiles.push_back(tile);
}
