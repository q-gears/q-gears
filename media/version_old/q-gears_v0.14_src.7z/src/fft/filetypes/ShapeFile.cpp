// $Id: TimFile.cpp 105 2006-12-02 00:07:47Z einherjar $

#include "../../common/utilites/Logger.h"

#include "ShapeFile.h"
#include "../filesystem/GameFileSystem.h"



ShapeFile::ShapeFile(const RString& file):
    File(*GAMEFILESYSTEM, file)
{
//    InnerGetFrames();
}



ShapeFile::ShapeFile(File* pFile):
    File(pFile)
{
//    InnerGetFrames();
}



ShapeFile::ShapeFile(File* pFile, const u32& offset, const u32& length):
    File(pFile, offset, length)
{
//    InnerGetFrames();
}



ShapeFile::ShapeFile(u8* pBuffer, const u32& offset, const u32& length):
    File(pBuffer, offset, length)
{
//    InnerGetFrames();
}



ShapeFile::~ShapeFile(void)
{
}



/*const FrameData
ShapeFile::GetFrame(const Uint32 frame) const
{
    if (frame > m_Frame.size())
    {
        LOGGER->Log("ShapeFile::GetFrame: Warning: 'frame' is greater than number of frames in file.");
        return FrameData();
    }

    return m_Frame[frame];
}
*/

/*
void
ShapeFile::InnerGetFrames(void)
{
    Uint32 start = 0x040A;
    Uint16 number_of_frames = 0x100;

    for (Uint16 frame_number = 0; frame_number < number_of_frames; ++frame_number)
    {
        Uint32 frame_start = start + GetU32LE(0x08 + frame_number * 0x04);
        Uint16 number_of_tile = GetU16LE(frame_start);

        FrameData frame;

        for (Uint16 tile_number = 0; tile_number <= number_of_tile; ++tile_number)
        {
            TileData tile;
            tile.frame_x = GetU8(frame_start + 0x02 + tile_number * 0x04 + 0x00) + 127;
            tile.frame_y = GetU8(frame_start + 0x02 + tile_number * 0x04 + 0x01) + 127;

            Uint16 flags = GetU16LE(frame_start + 0x02 + tile_number * 0x04 + 0x02);

            switch ((flags >> 10) & 0x0F)
            {
                case 0x06: tile.width = 24; tile.height = 24; break; // !!
                case 0x08: tile.width = 32; tile.height = 16; break; // !!
                case 0x09: tile.width = 32; tile.height = 24; break; // !!
                case 0x0A: tile.width = 32; tile.height = 32; break; // !!
                case 0x0B: tile.width = 32; tile.height = 40; break; // !!
                case 0x0D: tile.width = 48; tile.height = 48; break;
                case 0x0E: tile.width = 56; tile.height = 48; break;
                default  : LOGGER->Log("Unknown sprite value %04x", (flags >> 10) & 0x0F);
            }
            LOGGER->Log("Flags for this shape %04x.", flags >> 10);

            tile.tile_x =  (flags & 0x001F) * 8;
            tile.tile_y = ((flags >> 5) & 0x001F) * 8;
//            tile.height = 16 + ((flags >> 10) & 0x0003) * 16;
//            tile.width  = 8  + ((flags >> 12) & 0x0003) * 16;

            frame.tile.push_back(tile);
        }

        m_Frame.push_back(frame);
    }
}
*/
