// $Id: GameMain.cpp 103 2006-11-26 07:19:38Z crazy_otaku $

#include "../common/input/InputFilter.h"
#include "../common/module/ModuleManager.h"
#include "../common/utilites/Logger.h"
#include "../common/utilites/StdString.h"
#include "../common/utilites/timer/Timer.h"
#include "../common/utilites/timer/TimerSDL.h"

#include "GameDefine.h"
#include "GameMain.h"
#include "filesystem/GameFileSystem.h"
#include "screentest/DisplayTest.h"




unsigned char  state;  /**< @brief global game state */



void
handle_input_events(void)
{
    INPUTFILTER->Update();

    static InputEventArray input_event_array;
    input_event_array.clear();
    INPUTFILTER->GetInputEvents(input_event_array);

    for (int i = 0; i < input_event_array.size(); ++i)
    {
        MODULEMAN->Input(input_event_array[i]);
    }
}



RString
game_title(void)
{
    RString title = APPLICATION_NAME;
    return title;
}



void
game_module_start(void)
{
    // load display test
    ScreenDisplayTest* screen1 = new ScreenDisplayTest();
    MODULEMAN->PushModule(screen1);
}



void
game_main(void)
{
    LOGGER->Log(LOGGER_INFO, "Init game filesystem.");
    GAMEFILESYSTEM = new GameFileSystem();
    LOGGER->Log(LOGGER_INFO, "Game filesystem inited.");



    TimerSDL::InitTimer();
    Timer* timer = MakeTimer();
    unsigned int delta = 0;

    state = GAME;
    LOGGER->Log(LOGGER_INFO, "===================== Start the game!!!");
    while (state != EXIT)
    {
        // Handle all necessary game logic
        if (delta > 10)
        {
            MODULEMAN->Draw();
            MODULEMAN->Update(delta);
            handle_input_events();
            delta = 0;
        }

        delta += timer->GetDeltaTime();
    }
    LOGGER->Log(LOGGER_INFO, "===================== Stop the game!!!");


    delete timer;
    TimerSDL::QuitTimer();



    delete GAMEFILESYSTEM;
    
    return;
}
