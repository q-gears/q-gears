In order to compile QGears you have to download 4 Dependency's and place them within the 3rdParty Folder.

- SDL Win32 Development Librarys
	http://www.libsdl.org/download-1.2.php
	(z.b.: SDL-devel-1.2.11-VC6.zip)	

- libxml2 Win32 Development Librarys
	ftp://xmlsoft.org/libxml2/win32/
	(z.b.: libxml2-2.6.23.win32.zip)

- iconv Win32 Development Librarys
	ftp://xmlsoft.org/libxml2/win32/
	(z.b.: iconv-1.9.1.win32.zip)

- zlib Win32 Development Librarys
	ftp://xmlsoft.org/libxml2/win32/
	(z.b.: zlib-1.2.3.win32.zip)


After extracting those you need to have the following Librarys (together with some include directories)
3rdParty\iconv\lib\iconv.lib
3rdParty\libxml2\lib\libxml2.lib
3rdParty\SDL\lib\SDL.lib
3rdParty\SDL\lib\SDLmain.lib
3rdParty\zlib\lib\zlib.lib


The Last step is to create a Subfolder for the SDL Includes, since the win32 Version is layed out like this: "3rdParty\SDL\Include\*.*" and within the Sources it's always linked as "SDL\SDL_*.h".

For that reason we have to make a new Subfolder within Include and put everything there:
3rdParty\SDL\Include\*.* --> 3rdParty\SDL\Include\SDL\*.*


Now everything should compile without errors.

by Coldmoon :)

