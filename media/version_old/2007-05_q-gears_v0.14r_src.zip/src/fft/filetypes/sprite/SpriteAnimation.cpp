// $Id$

#include "../../../common/utilites/Logger.h"

#include "SpriteAnimation.h"



SpriteAnimation::SpriteAnimation(void)
{
    Init();
}



SpriteAnimation::~SpriteAnimation(void)
{
    for (Uint32 i = 0; i < m_Animation.size(); ++i)
    {
        delete m_Animation[i];
    }
}



void
SpriteAnimation::Init(void)
{
}



void
SpriteAnimation::Input(const InputEvent &input)
{
}



void
SpriteAnimation::Update(const Uint32 delta_time)
{
    if (m_FrameSequence.size() > 0)
    {
        if (m_FrameSequence.front().show_time != 0)
        {
            --m_FrameSequence.front().show_time;
        }

        if (m_FrameSequence.front().show_time == 0)
        {
            m_FrameSequence.pop();
        }
    }
}



void
SpriteAnimation::Draw(void) const
{
    if (m_FrameSequence.size() > 0)
    {
        Uint32 frame_id = m_FrameSequence.front().frame_id;

        if (frame_id < m_Animation.size())
        {
            LOGGER->Log(LOGGER_INFO, "Draw frame %d.", frame_id);
            m_Animation[frame_id]->Draw();
        }
        else
        {
            LOGGER->Log(LOGGER_INFO, "There is no frame with id %d.", frame_id);
        }
    }
}



void
SpriteAnimation::AddFrame(SpriteFrame* frame)
{
    m_Animation.push_back(frame);
}



void
SpriteAnimation::SetFrameToDraw(const Uint32 frame_id, const Uint32 show_time)
{
    FrameForSequence temp_frame;
    temp_frame.frame_id  = frame_id;
    temp_frame.show_time = show_time;

    m_FrameSequence.push(temp_frame);
}
