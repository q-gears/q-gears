// $Id$

#ifndef SPRITE_FILE_h
#define SPRITE_FILE_h

#include "../../common/display/surface/Surface.h"
#include "../../common/utilites/StdString.h"

#include "image/Vram.h"
#include "../filesystem/File.h"



class SpriteFile : public File
{
public:
    explicit  SpriteFile(const RString& file);
    explicit  SpriteFile(File* pFile);
              SpriteFile(File* pFile, const u32& offset, const u32& length);
              SpriteFile(u8* pBuffer, const u32& offset, const u32& length);
    virtual  ~SpriteFile(void);

    Surface*  GetSurface(const u32& clutNumber);

private:
    void      InnerGetImage(void);

private:

    struct ClutColor
    {
        u8 r;                 /**< @brief red color in CLUT */
        u8 g;                 /**< @brief green color in CLUT */
        u8 b;                 /**< @brief blue color in CLUT */
        u8 a;                 /**< @brief alpha in CLUT */
    };

    u32  mIdTag;               /**< @brief tim id tag */
    u32  mIdTagClut;           /**< @brief tim clut id tag */

    u16  mClutVramPositionX;
    u16  mClutVramPositionY;
    u16  mClutWidth;
    u16  mClutHeight;

    u16  mImageVramPositionX;
    u16  mImageVramPositionY;
    u16  mImageWidth;
    u16  mImageHeight;

    Vram mVram;
};



#endif
