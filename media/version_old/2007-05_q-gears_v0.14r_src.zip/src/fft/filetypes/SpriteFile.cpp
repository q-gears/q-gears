// $Id: TimFile.cpp 105 2006-12-02 00:07:47Z einherjar $

#include "../../common/utilites/Logger.h"

#include "SpriteFile.h"
#include "../filesystem/GameFileSystem.h"



SpriteFile::SpriteFile(const RString& file):
    File(*GAMEFILESYSTEM, file),
    mClutWidth(16),
    mClutHeight(16),
    mClutVramPositionX(0),
    mClutVramPositionY(0),

    mImageWidth(128),
    mImageHeight(256),
    mImageVramPositionX(0x200),
    mImageVramPositionY(0)
{
    InnerGetImage();
}



SpriteFile::SpriteFile(File* pFile):
    File(pFile)
{
    InnerGetImage();
}



SpriteFile::SpriteFile(File* pFile, const u32& offset, const u32& length):
    File(pFile, offset, length)
{
    InnerGetImage();
}



SpriteFile::SpriteFile(u8* pBuffer, const u32& offset, const u32& length):
    File(pBuffer, offset, length)
{
    InnerGetImage();
}



SpriteFile::~SpriteFile(void)
{
}



Surface*
SpriteFile::GetSurface(const u32& clutNumber)
{
    Surface* ret = NULL;

    if (clutNumber > mClutHeight)
    {
        LOGGER->Log(LOGGER_WARNING,
			"TimFile::GetSurface: Warning: 'clut_number' is greater than number of clut in file.");
        return ret;
    }

    // temp clut color
    ClutColor color;

    // convert 4BPP tim
    ret = CreateSurface(mImageWidth * 2, mImageHeight);

    for (int y = 0; y < mImageHeight; ++y)
    {
        for (int x = 0; x < mImageWidth; ++x)
        {
            u16 real_x = mImageVramPositionX + x;
            u16 real_y = mImageVramPositionY + y;
            u16 clut_y = clutNumber + mClutVramPositionY;

            u8 data = mVram.GetU8(real_x, real_y) & 0x0F;
            u16 col = mVram.GetU16(data * 2 + mClutVramPositionX, clut_y);

            color.r = ((col      ) & 31) * 255 / 31;
            color.g = ((col >>  5) & 31) * 255 / 31;
            color.b = ((col >> 10) & 31) * 255 / 31;
            u8 stp = (col & 0x80) >> 15;
            if (col == 0x0000)
            {
                color.a = 0;
            }
            else if (stp == 1 && color.r == 0 && color.g == 0 && color.b == 0)
            {
                color.a = 127;
            }
            else if (stp == 1 && (color.r != 0 || color.g != 0 || color.b == 0))
            {
                color.a = 0;
            }
            else if (stp == 0 && (color.r != 0 || color.g != 0 || color.b == 0))
            {
                color.a = 255;
            }

            memcpy(ret->pixels + x * 8 + ret->width * 4 * y + 0x00, &color, sizeof(ClutColor));

            data    = (mVram.GetU8(real_x, real_y) & 0xF0) >> 4;
            col     = mVram.GetU16(data * 2 + mClutVramPositionX, clut_y);

            color.r = ((col      ) & 31) * 255 / 31;
            color.g = ((col >>  5) & 31) * 255 / 31;
            color.b = ((col >> 10) & 31) * 255 / 31;
            stp = (col & 0x80) >> 15;
            if (col == 0x0000)
            {
                color.a = 0;
            }
            else if (stp == 1 && color.r == 0 && color.g == 0 && color.b == 0)
            {
                color.a = 127;
            }
            else if (stp == 1 && (color.r != 0 || color.g != 0 || color.b == 0))
            {
                color.a = 0;
            }
            else if (stp == 0 && (color.r != 0 || color.g != 0 || color.b == 0))
            {
                color.a = 255;
            }

            memcpy(ret->pixels + x * 8 + ret->width * 4 * y + 0x04, &color, sizeof(ClutColor));
        }
    }

    return ret;
}



void
SpriteFile::InnerGetImage(void)
{
    for (int y = 0; y < mClutHeight; ++y)
    {
        for (int x = 0; x < mClutWidth; ++x)
        {
            u16 color = GetU16LE(y * mClutWidth * 2 + x * 2);
            mVram.PutU16(x * 2 + mClutVramPositionX, y + mClutVramPositionY, color);
        }
    }



    for (int y = 0; y < mImageHeight; ++y)
    {
        for (int x = 0; x < mImageWidth; ++x)
        {
            u8 data = GetU8(0x200 + y * mImageWidth + x);
            mVram.PutU8(x + mImageVramPositionX, y + mImageVramPositionY, data);
        }
    }
}
