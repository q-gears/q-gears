// $Id: DisplayTest.cpp 105 2006-12-02 00:07:47Z einherjar $

#include "../../common/display/Display.h"
#include "../../common/display/surface/SurfaceLoad.h"
#include "../../common/display/surface/SurfaceSaveBmp.h"
#include "../../common/module/ModuleManager.h"
#include "../../common/utilites/Logger.h"

#include "DisplayTest.h"
#include "../filetypes/BinGZipFile.h"

// fft
#include "../filetypes/ShapeFile.h"
#include "../filetypes/SpriteFile.h"

// xeno
#include "../filetypes/sprite/EnemyFile.h"



ScreenDisplayTest::ScreenDisplayTest()
{
    Init();
}



ScreenDisplayTest::~ScreenDisplayTest()
{
}



void
ScreenDisplayTest::Init()
{
    EnemyFile enemy("2635.unk3");
    enemy.LoadEnemies(m_Animation);

    for (Uint8 i = 0; i < 66; ++i)
    {
        m_Animation.SetFrameToDraw(i, 10);
    }
}



void
ScreenDisplayTest::Input(const InputEvent &input)
{
    m_Animation.Input(input);
}



void
ScreenDisplayTest::Update(const Uint32 delta_time)
{
    m_Animation.Update(delta_time);
}



void
ScreenDisplayTest::Draw(void) const
{
    DISPLAY->PushMatrix();
    DISPLAY->LoadIdentity();
    DISPLAY->Translate(-1.0f, 1.0f, 0.0f);
    DISPLAY->Scale(2.0f/640.0f, 2.0f/480.0f, 1.0f);

    DISPLAY->CameraPushMatrix();
    DISPLAY->CameraLoadIdentity();
    DISPLAY->TexturePushMatrix();
    DISPLAY->TextureLoadIdentity();

//    DISPLAY->Translate(256.0f, 256.0f, 0.0f);
    m_Animation.Draw();

    DISPLAY->TexturePopMatrix();
    DISPLAY->CameraPopMatrix();
    DISPLAY->PopMatrix();
}
