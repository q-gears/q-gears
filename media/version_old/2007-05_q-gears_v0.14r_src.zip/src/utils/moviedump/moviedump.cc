/*
 * FF7 PSX Movie Dumper
 *
 * Currently supported dumping only from RAW PSX CD-ROM images.
 * 
 * Copyright (C) (2007) (Gennadiy Brich) <gennadiy.brich@gmail.com>
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later
 * version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */



#include <inttypes.h>
#include <fstream>
#include <iostream>
#include <string>



using namespace std;



static const uint8_t CDXA_SUBHEADER_EOF = 128;



struct CDXASector
{
	uint8_t sync[12];
	uint8_t header[4];
	struct CDXASubHeader
	{
		uint8_t file_number;
		uint8_t channel;
		uint8_t submode;
		uint8_t coding_info;
		uint8_t file_number_copy;
		uint8_t channel_number_copy;
		uint8_t submode_copy;
		uint8_t coding_info_copy;
	} subheader;
	uint8_t data[2328];
};



struct ISO9660PrimaryVolumeDescriptor
{
	uint8_t volume_descriptor_type;
	uint8_t standard_indentifier[6];
	uint8_t padding_first;
	uint8_t system_identifier[32];
	uint8_t volume_identifier[32];
	uint64_t padding_second;
	uint64_t volume_space_size;
	uint8_t padding_third[32];
	uint32_t volume_set_size;
	uint32_t volume_sequence_number;
	uint32_t logical_block_size;
	uint64_t path_table_size;
	uint32_t path_table_l_offset;
	uint32_t path_table_l_optional_offset;
	uint32_t path_table_m_offset;
	uint32_t path_table_m_optional_offset;
	uint8_t root_directory_record[34];
	uint8_t volume_set_identifier[128];
	uint8_t publisher_identifier[128];
	uint8_t data_preparer_identifier[128];
	uint8_t application_identifier[128];
	uint8_t copyright_file_identifier[37];
	uint8_t abstract_file_identifier[37];
	uint8_t bibliographic_file_identifier[37];
	uint8_t volume_creation_date[17];
	uint8_t volume_modification_date[17];
	uint8_t volume_expiration_date[17];
	uint8_t volume_effective_date[17];
	uint8_t file_structure_version;
	uint8_t reserved_for_future_standardization_first;
	uint8_t application_data[512];
	uint8_t reserved_for_future_standardization_second[653];
} __attribute__((packed));



int main(int argc, char *argv[])
{
	// if proper command line arguments
	if(argc != 2)
	{
		cout << "Usage: " << argv[0] << " <filename.bin>" << endl;
		exit(EXIT_FAILURE);
	}

	// open image
	fstream iF;
	iF.open(argv[1], ios::binary | ios::in);
	if(iF.fail())
	{
		cout << "Error: can't open file " << argv[1] << "." << endl;
		exit(EXIT_FAILURE);
	}

	// read primary volume descriptor
	CDXASector sector;
	uint64_t sector_offset = 16 * sizeof(CDXASector);
	iF.seekg(sector_offset);
	iF.read((char *)&sector, sizeof(sector));
	ISO9660PrimaryVolumeDescriptor *pvd;
	pvd = (ISO9660PrimaryVolumeDescriptor *)sector.data;

	// go to path table
	sector_offset = pvd->path_table_l_offset * sizeof(CDXASector);
	iF.seekg(sector_offset);

	// go to MOVIE directory
	iF.read((char *)&sector, sizeof(sector));
	uint32_t directory_offset;
	for(uint16_t i = 0; i < 2048;)
	{
		if(sector.data[i] == 0)
		{
			cout << "Can't find MOVIE directory record" << endl;
			iF.close();
			exit(EXIT_FAILURE);
		}

		uint8_t name_length = sector.data[i];
//		uint8_t xa_sectors_number = sector.data[i + 1];
		directory_offset = *(uint32_t *)&sector.data[i + 2];
//		uint16_t record_number = *(uint16_t *)&sector.data[i + 6];

		if(!memcmp(sector.data + i + 8, "MOVIE", 5))
			break;
		
		i += name_length + 8 + name_length % 2;
	}
	sector_offset = directory_offset * sizeof(CDXASector);
	iF.seekg(sector_offset);

	// seek through directory record for *.MOV files
	bool directory_ended = false;
	while(!directory_ended)
	{
		iF.read((char *)&sector, sizeof(sector));
		for(uint16_t i = 0; i < 2048;)
		{
			if(i == 0 && sector.data[i] == 0)
			{
				directory_ended = true;
				break;
			}

			if(sector.data[i] == 0)
				break;

			uint8_t record_length = sector.data[i];
//			uint8_t xa_sector_count = sector.data[i + 1];
			uint32_t file_offset_le = *(uint32_t *)&sector.data[i + 2];
//			uint32_t file_offset_be = *(uint32_t *)&sector.data[i + 6];
			uint32_t file_size_le = *(uint32_t *)&sector.data[i + 10];
//			uint32_t file_size_be = *(uint32_t *)&sector.data[i + 14];
//			uint8_t years_passed_since_1900 = sector.data[i + 18];
//			uint8_t month_number = sector.data[i + 19];
//			uint8_t day_number = sector.data[i + 20];
//			uint8_t hour_number = sector.data[i + 21];
//			uint8_t minute_number = sector.data[i + 22];
//			uint8_t second_number = sector.data[i + 23];
//			int8_t gmt_offset_number = sector.data[i + 24];
//			uint8_t file_flags = sector.data[i + 25];
//			uint8_t interleaved_file_unit_size = sector.data[i + 26];
//			uint8_t interleaved_gap_size = sector.data[i + 27];
//			uint16_t volume_sequence_number_le =
//				*(uint16_t *)&sector.data[i + 28];
//			uint16_t volume_sequence_number_be =
//				*(uint16_t *)&sector.data[i + 30];

			uint8_t identifier_length = sector.data[i + 32];

			// if *.MOV - dump file and return get pointer here
			if(!memcmp((void *)&sector.data[i + 33 + (identifier_length - 6)],
				".MOV", 4))
			{
				string output_filename((char *)&sector.data[i + 33],
					identifier_length - 2);

				uint64_t current_get_position = iF.tellg();
				sector_offset = file_offset_le * sizeof(CDXASector);
				iF.seekg(sector_offset);
				fstream oF;
				cout << "Dumping " << output_filename << "... " << flush;
				oF.open(output_filename.c_str(), ios::binary | ios::out);
				CDXASector temp_sector;
				uint32_t bytes_to_copy = file_size_le / 2048 *
					sizeof(temp_sector);
				while(bytes_to_copy)
				{
					iF.read((char *)&temp_sector, sizeof(temp_sector));
					oF.write((char *)&temp_sector, sizeof(temp_sector));
					bytes_to_copy -= sizeof(temp_sector);
				}
				oF.close();
				cout << "done" << endl;
				iF.seekg(current_get_position);
			}

			i += record_length;
		}
	}

	// close image
	iF.close();

	return 0;
}

