// $Id: Config.h 93 2006-11-12 13:49:02Z einherjar $

#ifndef CONFIG_H
#define CONFIG_H
// The Config Class : Implements basic config file



#include "NoCopy.h"
#include "StdString.h"
#include "common/TypeDefine.h"



class Config : public NoCopy<Config>
{
public:
    Config();

    virtual ~Config();

    void ReadConfig(const RString& file);

public:
    // Debug:
    bool    mDumpSpecificGameData;
    bool    m_DumpScript;

    Uint32  GAME_WIDTH;
    Uint32  GAME_HEIGHT;
    Uint32  SCREEN_WIDTH;
    Uint32  SCREEN_HEIGHT;
};



extern Config* CONFIG; // global and accessable from anywhere in our program



#endif // CONFIG_H
