// $Id: TimerSDL.cpp 147 2007-02-24 06:13:17Z super_gb $

#include "TimerSDL.h"
#include "common/utilites/Logger.h"

#include <SDL/SDL.h>



bool TimerSDL::mTimerInited = false;



void
TimerSDL::InitTimer()
{
    if (mTimerInited == false)
    {
        if (SDL_InitSubSystem(SDL_INIT_TIMER) == -1)
        {
            LOGGER->Log(LOGGER_ERROR, "SDL_INIT_TIMER failed: %s",
				SDL_GetError());
        }
        else
        {
            mTimerInited = true;
            LOGGER->Log(LOGGER_INFO, "SDL_INIT_TIMER initialized");
        }
    }
}



void
TimerSDL::QuitTimer()
{
    if (mTimerInited == true)
    {
        mTimerInited = false;
        SDL_QuitSubSystem(SDL_INIT_TIMER);
    }
}



Timer*
MakeTimer()
{
    return new TimerSDL();
}


Timer*
MakeTimer(const unsigned int &seconds)
{
    return new TimerSDL(seconds);
}



TimerSDL::TimerSDL():
    Timer()
{
    InitTimer();
    mSeconds = GetTime();
}



TimerSDL::TimerSDL(const unsigned int &seconds):
    Timer(seconds)
{
}



TimerSDL::~TimerSDL()
{
}



unsigned int
TimerSDL::GetTime()
{
    unsigned int time = 0;

    if (mTimerInited == true)
    {
       time = SDL_GetTicks();
    }

    return time;
}
