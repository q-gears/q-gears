// $Id: TimerSDL.h 97 2006-11-19 22:25:49Z einherjar $

#ifndef TIMERSDL_H
#define TIMERSDL_H



#include "Timer.h"



class TimerSDL : public Timer
{
    friend Timer* MakeTimer();
    friend Timer* MakeTimer(const unsigned int &seconds);

public:
    virtual             ~TimerSDL();
    static void          InitTimer();
    static void          QuitTimer();

protected:
    virtual unsigned int GetTime();

private:
                         TimerSDL();
                         TimerSDL(const unsigned int &seconds);

private:
    static bool mTimerInited;
};



#endif
