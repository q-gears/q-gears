// $Id: Window.h 93 2006-11-12 13:49:02Z einherjar $

#ifndef WINDOW_H
#define WINDOW_H
// The Window Class : Abstract class for window

#include "common/utilites/NoCopy.h"



class Window : public NoCopy<Window>
{
public:
    virtual ~Window() {};

    virtual void SwapBuffers() = 0;

protected:
    // This need to be protected because implementation must call constructor
    Window() {};
};



#endif // WINDOW_H
