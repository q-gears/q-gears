// $Id: MatrixStack.h 93 2006-11-12 13:49:02Z einherjar $

#ifndef MATRIXSTACK_H
#define MATRIXSTACK_H
// The MatrixStack Class : Implementation stack ot the matrixes and operations with them



#include "math/Matrix.h"
#include "common/utilites/NoCopy.h"

#include <vector>



class MatrixStack : public NoCopy<MatrixStack>
{
public:
    MatrixStack();

    virtual ~MatrixStack();

    // Pops the top of the stack.
    void Pop();

    // Pushes the stack by one, duplicating the current matrix.
    void Push();

    // Obtain the current matrix at the top of the stack
    const Matrix* GetTop();

    // Operations with current matrix

    // Loads identity in the current matrix.
    void LoadIdentity();

    // Loads the given matrix into the current matrix
    void LoadMatrix(const Matrix &m);

    // Right-Multiplies the given matrix to the current matrix.
    // (transformation is about the current world origin)
    void MultMatrix(const Matrix &m);

    // Left-Multiplies the given matrix to the current matrix
    // (transformation is about the local origin of the object)
    void MultMatrixLocal(const Matrix &m);

    // Right multiply the current matrix with the computed rotation
    // matrix, counterclockwise about the given axis with the given angle.
    // (rotation is about the current world origin)
    void RotateX(float degrees);
    void RotateY(float degrees);
    void RotateZ(float degrees);

    // Left multiply the current matrix with the computed rotation
    // matrix. All angles are counterclockwise. (rotation is about the
    // local origin of the object)
    void RotateXLocal(float degrees);
    void RotateYLocal(float degrees);
    void RotateZLocal(float degrees);

    // Right multiply the current matrix with the computed scale
    // matrix. (transformation is about the current world origin)
    void Scale(float x, float y, float z);

    // Left multiply the current matrix with the computed scale
    // matrix. (transformation is about the local origin of the object)
    void ScaleLocal(float x, float y, float z);

    // Right multiply the current matrix with the computed translation
    // matrix. (transformation is about the current world origin)
    void Translate(float x, float y, float z);

    // Left multiply the current matrix with the computed translation
    // matrix. (transformation is about the local origin of the object)
    void TranslateLocal(float x, float y, float z);

private:
    std::vector<Matrix> stack;
};



#endif
