#include "Movie.h"



Movie* MOVIEMAN = NULL;



Movie::Movie():
	m_IsPlaying(false),
	m_AudioChannel(-1),
	m_VideoChannel(-1),
	m_BufferModifier(4),
	m_GameData(new uint8_t[40]),
	m_PlayingMovie(0),
	m_MovieDirectoryPath("MOVIE"),
	m_FstreamDataPath("data")
{
	m_GameData = new uint8_t[40];
	m_AudioBuffer = new int8_t[m_BufferModifier * 2 * m_AUDIO_FRAME_SIZE];

	if(InitAudioSystem() != -1)
		m_AudioSystemReady = true;
	else
		m_AudioSystemReady = false;
}


Movie::~Movie()
{
	if(m_AudioSystemReady)
	{
		SDL_CloseAudio();
		SDL_QuitSubSystem(SDL_INIT_AUDIO);
	}

	delete [] m_AudioBuffer;
	delete [] m_GameData;
}


void Movie::AddMovie(const RString& file_name, const Uint32 id)
{
	MovieWithId movie;
	movie.file_name = file_name;
	movie.id = id;
	
	// detect file type
	if(movie.file_name.substr(movie.file_name.length() - 4, 4) == ".STR")
	{
		movie.type = 0;
		LOGGER->Log(LOGGER_INFO,
			"Movie::AddMovie: %s - detected plain STR file.",
			movie.file_name.c_str());
	}
	else if(movie.file_name.substr(movie.file_name.length() - 4, 4) == ".MOV")
	{
		movie.type = 1;
		LOGGER->Log(LOGGER_INFO,
   	   		"Movie::AddMovie: %s - detected RAW CDXA sectors dump file.",
	   		movie.file_name.c_str());
	}
	
	m_Movies.push_back(movie);
}


int Movie::InitAudioSystem()
{
	if(SDL_InitSubSystem(SDL_INIT_AUDIO) == -1)
	{
		LOGGER->Log(LOGGER_ERROR, "Movie::InitAudioSystem(): %s",
			SDL_GetError());
		return -1;
	}

	SDL_AudioSpec wanted_config;
	wanted_config.freq = 37800;
	wanted_config.format = AUDIO_S16;
	wanted_config.channels = 2;
	wanted_config.samples = 2048;
	wanted_config.callback = fill_audio;
	wanted_config.userdata = &m_AudioPlayData;

	if(SDL_OpenAudio(&wanted_config, NULL) < 0)
	{
		LOGGER->Log(LOGGER_ERROR, "Movie::InitAudioSystem(): %s",
			SDL_GetError());
		return -1;
	}

	return 0;
}


void Movie::Update(const Uint32 delta_time)
{
	// if we are in playing state
	if(m_IsPlaying)
	{
		// if we didn't open video file yet
		if (!m_InputFile.is_open())
		{
			// open file
			RString fstream_file_path = m_FstreamDataPath + '/' +
				m_MovieDirectoryPath + '/' + m_Movies[m_PlayingMovie].file_name;
			m_InputFile.open(fstream_file_path.c_str(),
				std::ios::binary | std::ios::in);

			// if opened successfully
			if(m_InputFile.is_open())
			{
				// clear frame counter
				m_CurrentFrame = 0;

				// reset frame timer
				m_VideoTimeDelta = 0;

				// clear frame buffer if we are playing again after stop
				while(!m_VideoFrameBuffer.empty())
					m_VideoFrameBuffer.pop();

				m_AudioPlayData.start_pointer = m_AudioBuffer;
				m_AudioPlayData.end_pointer = m_AudioBuffer;
			}
			// if failed to open file
			else
			{
				LOGGER->Log(LOGGER_ERROR,
					"Movie::Update: %s - failed to open file.",
					fstream_file_path.c_str());
				m_IsPlaying = false;
				return;
			}
		}
		
		// fill audio & video buffers
		if(m_Movies[m_PlayingMovie].type == 0)
			FillBuffersFile();
		else if(m_Movies[m_PlayingMovie].type == 1)
			FillBuffersInterleaved();

		if(m_VideoFrameBuffer.empty())
		{
			LOGGER->Log(LOGGER_INFO, "Movie::Update(): Finished playing.");

			if(m_Movies[m_PlayingMovie].type == 1 && m_AudioSystemReady)
				SDL_PauseAudio(1);
			m_IsPlaying = false;
			m_InputFile.close();

			return;
		}

		// every 66.(6)msec - display 1 video frame
		m_VideoTimeDelta += delta_time;
		if(m_VideoTimeDelta > 66.666666)
		{
			m_VideoTimeDelta -= 66.666666;

			if(!m_VideoFrameBuffer.empty())
			{
				SetSurfaceSize(m_VideoFrameBuffer.front().frame, 512, 256);
				DISPLAY->DeleteTexture(m_CurrentTextureId);
				m_CurrentTextureId =
					DISPLAY->CreateTexture(m_VideoFrameBuffer.front().frame);
				delete m_VideoFrameBuffer.front().frame;
				for(uint8_t i = 0; i < 40; i++)
					m_GameData[i] = (m_VideoFrameBuffer.front()).data[i];
				delete [] m_VideoFrameBuffer.front().data;
				m_VideoFrameBuffer.pop();
				m_CurrentFrame++;
			}
		}
	}
}


void Movie::SetMovieToPlay(const Uint32 movie_id)
{
	for(Uint32 i = 0; i < m_Movies.size(); i++)
		if (m_Movies[i].id == movie_id)
		{
			m_PlayingMovie = i;

			if(m_Movies[m_PlayingMovie].type == 1 && m_AudioSystemReady)
				SDL_PauseAudio(1);

			if(m_InputFile.is_open())
			{
				m_IsPlaying = false;
				m_InputFile.close();
			}
			
			break;
		}
}


void Movie::Play()
{
	if(m_Movies[m_PlayingMovie].type == 1 && m_AudioSystemReady)
		SDL_PauseAudio(0);

	m_IsPlaying = true;
}


void Movie::Pause()
{
	if(m_Movies[m_PlayingMovie].type == 1 && m_AudioSystemReady)
		SDL_PauseAudio(1);
	m_IsPlaying = false;
}


void Movie::Stop()
{
	if(m_Movies[m_PlayingMovie].type == 1 && m_AudioSystemReady)
		SDL_PauseAudio(1);

	m_IsPlaying = false;
    if(m_InputFile.is_open())
		m_InputFile.close();
}


const bool Movie::IsPlaying() const
{
	return m_IsPlaying;
}


const Uint32 Movie::GetFrame() const
{
	return (Uint32)m_CurrentFrame;
}


const Uint32 Movie::GetFrameTextureId() const
{
	return m_CurrentTextureId;
}


Uint8* Movie::GetAdditionalBuffer() const
{
	return m_GameData;
}


void Movie::FillBuffersFile()
{
	CDXAVideoData video_chunk;
	uint8_t bitstream_image[32768];

	while(m_VideoFrameBuffer.size() < m_BufferModifier)
	{
		if(!m_InputFile.read((char *)&video_chunk, sizeof(video_chunk)))
			return;

		uint32_t bytes_to_copy = video_chunk.frame_size -
			video_chunk.sector_number * sizeof(video_chunk.frame);

		if(bytes_to_copy > 0)
		{
			if(bytes_to_copy > sizeof(video_chunk.frame))
				bytes_to_copy = sizeof(video_chunk.frame);

			memcpy(bitstream_image + video_chunk.sector_number *
				sizeof(video_chunk.frame), video_chunk.frame, bytes_to_copy);
		}

		// if we have full video frame
		// decode it & send to postprocessor
		if(video_chunk.sector_number == video_chunk.sector_count - 1)
		{
			VideoFrameContext frame_context;
			frame_context.data = new uint8_t[40];
            frame_context.frame = CreateSurface(video_chunk.frame_width,
				video_chunk.frame_height);

			// copy game data
			for(int i = 0; i < 40; i++)
				frame_context.data[i] = bitstream_image[i];

			// prepare frame
			m_VideoDecoder.DecodeFrameToRGBA32(
				(uint16_t *)(frame_context.frame->pixels),
				(uint16_t *)(bitstream_image + 40), video_chunk.frame_width,
				video_chunk.frame_height, false);

			m_VideoFrameBuffer.push(frame_context);
		}
	}
}


void Movie::FillBuffersInterleaved()
{
	CDXASector sector;
	uint8_t bitstream_image[32768];

	while(m_VideoFrameBuffer.size() < m_BufferModifier)
	{
		if(!m_InputFile.read((char *)&sector, sizeof(sector)))
			return;

		// we have audio sector
		if(sector.subheader.submode & m_CDXA_AUDIO)
		{
			// if audio channel is -1 - play first available
			if(m_AudioChannel == -1)
				m_AudioChannel = sector.subheader.channel;

			// if wanted audio channel decode it
			if(sector.subheader.channel == m_AudioChannel) 
			{
				if(m_BufferModifier * 2 * m_AUDIO_FRAME_SIZE -
					(m_AudioPlayData.end_pointer -
					m_AudioPlayData.start_pointer) < m_AUDIO_FRAME_SIZE)
					LOGGER->Log(LOGGER_ERROR,
						"Movie::FillBuffersInterleaved(): %s",
						"too slow, skipping audio sector.");
				else
				{
					if(m_AudioSystemReady)
						SDL_LockAudio();
	
					memcpy(m_AudioBuffer, m_AudioPlayData.start_pointer,
						m_AudioPlayData.end_pointer -
						m_AudioPlayData.start_pointer);
					m_AudioPlayData.end_pointer = m_AudioBuffer +
						(m_AudioPlayData.end_pointer -
						m_AudioPlayData.start_pointer);
					m_AudioPlayData.start_pointer = m_AudioBuffer;
	
					if(m_AudioSystemReady)
						SDL_UnlockAudio();

					m_AudioDecoder.DecodeFrameToPCM(m_AudioPlayData.end_pointer,
						sector.data, (bool)(sector.subheader.coding_info &
						m_CDXA_STEREO));
	
					m_AudioPlayData.end_pointer += m_AUDIO_FRAME_SIZE;
				}
			}
		}

		// we have video or data sector
		else if(sector.subheader.submode & m_CDXA_VIDEO)
		{
			// if video channel is -1 - play first available 
			if(m_VideoChannel == -1)
				m_VideoChannel = sector.subheader.channel;

			// if wanted video channel decode it
			if(sector.subheader.channel == m_VideoChannel)
			{
				CDXAVideoData *video_chunk = (CDXAVideoData *)&sector.data[0];

				uint32_t bytes_to_copy = video_chunk->frame_size -
					video_chunk->sector_number * sizeof(video_chunk->frame);

				if(bytes_to_copy > 0)
				{
					if(bytes_to_copy > sizeof(video_chunk->frame))
						bytes_to_copy = sizeof(video_chunk->frame);
					memcpy(bitstream_image + video_chunk->sector_number *
						sizeof(video_chunk->frame), video_chunk->frame,
						bytes_to_copy);
				}

				// if we have full video frame
				// decode it & send to postprocessor
				if(video_chunk->sector_number == video_chunk->sector_count - 1)
				{
					VideoFrameContext frame_context;
					frame_context.data = new uint8_t[40];
		            frame_context.frame = CreateSurface(video_chunk->frame_width
						, video_chunk->frame_height);

					// copy game data
					for(int i = 0; i < 40; i++)
						frame_context.data[i] = bitstream_image[i];

		            // prepare frame
					m_VideoDecoder.DecodeFrameToRGBA32(
						(uint16_t *)(frame_context.frame->pixels),
						(uint16_t *)(bitstream_image + 40),
						video_chunk->frame_width,
						video_chunk->frame_height, false);

					m_VideoFrameBuffer.push(frame_context);
				}
			}
		}

		// empty sectors
		else
			return;
	}
}



void fill_audio(void *data, Uint8 *audio_stream, int play_length)
{
	if(((AudioPlayData *)data)->start_pointer + play_length <=
		((AudioPlayData *)data)->end_pointer)
	{
		SDL_MixAudio(audio_stream,
			(Uint8 *)(((AudioPlayData *)data)->start_pointer), play_length,
			SDL_MIX_MAXVOLUME);
		((AudioPlayData *)data)->start_pointer += play_length;
	}
	else
		LOGGER->Log(LOGGER_ERROR, "fill_audio(): %s",
			"Skipping audio frame, empty audio buffer!");
}

