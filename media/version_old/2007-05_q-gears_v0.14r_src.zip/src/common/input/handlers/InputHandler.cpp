// $Id: InputHandler.cpp 93 2006-11-12 13:49:02Z einherjar $

#include "InputHandler.h"
#include "common/input/InputFilter.h"



void
InputHandler::ButtonPressed(Button b, bool Down)
{
    INPUTFILTER->ButtonPressed(b, Down);
}
