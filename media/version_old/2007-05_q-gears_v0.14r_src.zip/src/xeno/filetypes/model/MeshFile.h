// $Id: MeshFile.h 93 2006-11-12 13:49:02Z einherjar $

/**
 * @brief Class for common model mesh.
 */

#ifndef MESH_FILE_h
#define MESH_FILE_h

#include <vector>

#include "../../../common/display/3dTypes.h"
#include "../../../common/utilites/StdString.h"

#include "../../battle/ModelUtilites.h"
#include "../../filesystem/File.h"



class MeshFile : public File
{
public:
// LIFECYCLE

    /**
     * @brief A constructor.
     *
     * Read file from given path into memory.
     * @note after creation in buffer stored unarchived file.
     * @param file - path to file that we want to open.
     */
    explicit MeshFile(const RString& file);

    /**
     * @brief A constructor.
     *
     * Create completle copy of given file.
     * @note after creation in buffer stored unarchived file.
     * @param pFile - object that we want to copy.
     */
    explicit MeshFile(File* pFile);

    /**
     * @brief A constructor.
     *
     * Create partitial copy of given file.
     * @note after creation in buffer stored unarchived file.
     * @param pFile  - object that we want to copy.
     * @param offset - offset from where we want to copy data.
     * @param length - size of data that we want ot copy.
     */
    MeshFile(File* pFile, const u32& offset, const u32& length);

    /**
     * @brief A constructor.
     *
     * Create partitial copy of given buffer.
     * @note after creation in buffer stored unarchived file.
     * @param pBuffer - buffer from which we want to create new file.
     * @param offset  - offset from where we want to copy data.
     * @param length  - size of data that we want ot copy.
     */
    MeshFile(u8* pBuffer, const u32& offset, const u32& length);

    /**
     * @brief A destructor.
     */
    virtual ~MeshFile(void);

// OPERATIONS

    /**
     * @brief Gets geometry and vector of textures data to generate.
     *
     * Clear given arrays and fill it with data.
     * @param resultGeometry - array of geometry to fill.
     * @param textures       - array of texture data to generate.
     */
    void GetGeometry(std::vector<TotalGeometry>& resultGeometry, ModelUtilites::VectorTexForGen& textures);

private:
    u32 AddTexture(ModelUtilites::TexForGen& texture, ModelUtilites::VectorTexForGen& textures);

private:
    struct MeshBlockHeader
    {
        u16 unknown1;
        u16 number_of_vertex;
        u16 number_of_mesh;
        u16 number_of_mesh_block;
        u32 offset_to_vertex_block;
        u32 offset_to_normal_block;
        u32 offset_to_mesh_block;
        u32 offset_to_texture_coords;
        u32 unknown2[8];
    };

    struct CommandPacket
    {
        u8 :1;
        u8 :1;
        u8 :1;
        u8 vertex:1;
    };
};



#endif // MESH_FILE_h
