// $Id: UnitManager.cpp 96 2006-11-13 03:34:17Z crazy_otaku $

#include "../../common/display/Display.h"
#include "../../common/utilites/Config.h"
#include "../../common/utilites/Logger.h"

#include "FieldModule.h"
#include "UnitManager.h"



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

UnitManager::UnitManager(FieldModule* pFieldModule):
    mpFieldModule(pFieldModule)
{
}



UnitManager::~UnitManager(void)
{
    Clear();
}



//============================= OPERATIONS ===================================

void
UnitManager::Clear(void)
{
    mWalkMesh.clear();
}



void
UnitManager::Draw(void)
{
    std::vector<Vertex> line;
    line.resize(2);

    Vertex v;
    Color color_grant(217.0f / 255.0f, 217.0f / 255.0f, 217.0f / 255.0f, 1.0f);
    Color color_deny(191.0f / 255.0f, 0.0f, 0.0f, 1.0f);
    Color color_point(0.0f, 0.0f, 217.0f / 255.0f, 1.0f);

    DISPLAY->SetPolygonMode(POLYGON_LINE);
    DISPLAY->SetLineWidth(1);
    DISPLAY->SetPointSize(3);

    for (u32 i = 0; i < mWalkMesh.size(); ++i)
    {
        // if this triangle is accessible
        // if we allowed to cross border
        // and if triangle to which we can cross is allowed
        v.c = (mWalkMesh[i].accessible == true && mWalkMesh[i].access[0] != 0xFFFF && mWalkMesh[mWalkMesh[i].access[0]].accessible == true) ? color_grant : color_deny;
        v.p.x = mWalkMesh[i].A.x; v.p.y = mWalkMesh[i].A.y; v.p.z = mWalkMesh[i].A.z;
        line[0] = v;
        v.p.x = mWalkMesh[i].B.x; v.p.y = mWalkMesh[i].B.y; v.p.z = mWalkMesh[i].B.z;
        line[1] = v;
        DISPLAY->DrawLines(line);
        line[0].c = color_point;
        line[1].c = color_point;
        DISPLAY->DrawPoints(line);

        v.c = (mWalkMesh[i].accessible == true && mWalkMesh[i].access[1] != 0xFFFF && mWalkMesh[mWalkMesh[i].access[1]].accessible == true) ? color_grant : color_deny;
        v.p.x = mWalkMesh[i].B.x; v.p.y = mWalkMesh[i].B.y; v.p.z = mWalkMesh[i].B.z;
        line[0] = v;
        v.p.x = mWalkMesh[i].C.x; v.p.y = mWalkMesh[i].C.y; v.p.z = mWalkMesh[i].C.z;
        line[1] = v;
        DISPLAY->DrawLines(line);
        line[0].c = color_point;
        line[1].c = color_point;
        DISPLAY->DrawPoints(line);

        v.c = (mWalkMesh[i].accessible == true && mWalkMesh[i].access[2] != 0xFFFF && mWalkMesh[mWalkMesh[i].access[2]].accessible == true) ? color_grant : color_deny;
        v.p.x = mWalkMesh[i].A.x; v.p.y = mWalkMesh[i].A.y; v.p.z = mWalkMesh[i].A.z;
        line[0] = v;
        v.p.x = mWalkMesh[i].C.x; v.p.y = mWalkMesh[i].C.y; v.p.z = mWalkMesh[i].C.z;
        line[1] = v;
        DISPLAY->DrawLines(line);
        line[0].c = color_point;
        line[1].c = color_point;
        DISPLAY->DrawPoints(line);
    }
    DISPLAY->SetPolygonMode(POLYGON_FILL);
}



bool
UnitManager::Input(const InputEvent &input)
{
    return false;
}



void
UnitManager::Update(const u32& deltaTime)
{
}



void
UnitManager::AddWalkMeshTriangle(const WalkMeshTriangle& triangle)
{
    mWalkMesh.push_back(triangle);
}
