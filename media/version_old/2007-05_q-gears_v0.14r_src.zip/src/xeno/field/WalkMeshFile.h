// $Id: WalkMeshFile.h 96 2006-11-13 03:34:17Z crazy_otaku $

#ifndef WALKMESH_FILE_h
#define WALKMESH_FILE_h

#include <vector>

#include "../../common/display/3dTypes.h"
#include "../../common/utilites/StdString.h"

#include "UnitManager.h"
#include "../filesystem/File.h"



class WalkMeshFile : public File
{
public:
    explicit WalkMeshFile(const RString &file);

    explicit WalkMeshFile(File* file);

    WalkMeshFile(File* file, const u32 &offset, const u32 &length);

    WalkMeshFile(u8* buffer, const u32 &offset, const u32 &length);

    virtual ~WalkMeshFile();



    void GetWalkMesh(UnitManager* unitManager);
};



#endif // WALKMESH_FILE_h
