// $Id: BattleModule.cpp 93 2006-11-12 13:49:02Z einherjar $

#include "../../common/display/Display.h"
#include "../../common/display/surface/Surface.h"
#include "../../common/display/surface/SurfaceSaveBmp.h"
#include "../../common/utilites/Logger.h"

#include "BattleModule.h"



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

BattleModule::BattleModule(void)
{
    Init();
}



BattleModule::~BattleModule(void)
{
    delete mBackgroundModel;
}



//============================= OPERATIONS ===================================

void
BattleModule::Init(void)
{
    DISPLAY->SetZTestMode(ZTEST_WRITE_ON_PASS);
    DISPLAY->SetAlphaTest(true);
    DISPLAY->SetBlendMode(BLEND_PSX_1);
    DISPLAY->SetCullMode(CULL_NONE);

    // set camera
    DISPLAY->LoadLookAt(50, Vector3(2000, 5000, -5000), Vector3(0, 0, 0), Vector3(0, 1, 0));

    // load axis
    Vertex point;
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 0.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 500.0f; point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 1.0f;   point.c.g = 0.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 0.0f;   point.c.g = 1.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 500.0f; point.p.z = 0.0f;
    point.c.r = 0.0f;   point.c.g = 1.0f;   point.c.b = 0.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 0.0f;
    point.c.r = 0.0f;   point.c.g = 0.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    mAxis.push_back(point);
    point.p.x = 0.0f;   point.p.y = 0.0f;   point.p.z = 500.0f;
    point.c.r = 0.0f;   point.c.g = 0.0f;   point.c.b = 1.0f; point.c.a = 1.0f;
    mAxis.push_back(point);

    mModelNumber = 2775;
    RString name = "";
    name.Format("18/%d", mModelNumber);

    mBackgroundModel = new Model(name);
}



void
BattleModule::Draw(void)
{
    DISPLAY->SetPointSize(3);
    DISPLAY->DrawPoints(mAxis);
    DISPLAY->SetLineWidth(1);
    DISPLAY->DrawLines(mAxis);

//    DISPLAY->SetPolygonMode(POLYGON_LINE);
//    DISPLAY->SetAlphaTest(false);
//    DISPLAY->SetBlendMode(BLEND_DISABLED);
    mBackgroundModel->Draw();
//    DISPLAY->SetBlendMode(BLEND_NORMAL);
//    DISPLAY->SetAlphaTest(true);
//    DISPLAY->SetPolygonMode(POLYGON_FILL);
}




void
BattleModule::Input(const InputEvent &input)
{
    if (input.type == IET_RELEASE)
    {
        switch (input.button)
        {
            case KEY_UP:
            {
                delete mBackgroundModel;

                mModelNumber +=2;
                RString name = "";
                name.Format("18/%d", mModelNumber);

                mBackgroundModel = new Model(name);
            }
            break;

            case KEY_DOWN:
            {
                delete mBackgroundModel;

                mModelNumber -=2;
                RString name = "";
                name.Format("18/%d", mModelNumber);

                mBackgroundModel = new Model(name);
            }
            break;
        }
    }
}



void
BattleModule::Update(const u32& deltaTime)
{
}
