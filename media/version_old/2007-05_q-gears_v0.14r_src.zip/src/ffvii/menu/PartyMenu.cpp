// $Id: PartyMenu.cpp 94 2006-11-12 19:44:43Z crazy_otaku $

#include "common/module/ModuleManager.h"
#include "common/utilites/Logger.h"

#include "PartyMenu.h"
#include "ffvii/kernel/GameState.h"
#include "ffvii/kernel/Kernel.h"



/////////////////////////////// PUBLIC ///////////////////////////////////////

//============================= LIFECYCLE ====================================

PartyMenu::PartyMenu(void)
{
    Init();
}



PartyMenu::~PartyMenu(void)
{
}



//============================= OPERATIONS ===================================

void
PartyMenu::Init(void)
{
    // set state of menu
    mStartLive       = true;
    mStartDie        = false;
    mStep            = 25;

    // set position of menu window
    mMenuX           = 278;
    mMenuStartY      = mMenuY = 220;
    mMenuFinishY     = 0;

    // set position of party window
    mPartyStartX     = mPartyX = 370;
    mPartyFinishX    = 0;
    mPartyY          = 12;

    // set position of time/gil window
    mTimeStartX      = mTimeX = -100;
    mTimeFinishX     = 278;
    mTimeY           = 159;

    // set position of location window
    mLocationX       = 184;
    mLocationStartY  = mLocationY = -30;
    mLocationFinishY = 195;

    // set timer
    mTimer           = GAMESTATE->GetSavemap().PlayedSeconds;
    mTimerColon      = true;
}



void
PartyMenu::Draw(void) const
{
    // party
    KERNEL->DrawWindow(mPartyX, mPartyY, 300, 190, false);

    DrawCharInfo(GAMESTATE->GetSavemap().Slot1Char, 22, 12);
    DrawCharInfo(GAMESTATE->GetSavemap().Slot2Char, 22, 72);
    DrawCharInfo(GAMESTATE->GetSavemap().Slot3Char, 22, 132);



    // menu
    KERNEL->DrawWindow(mMenuX, mMenuY, 86, 132, false);



    // timer
    KERNEL->DrawWindow(mTimeX, mTimeY, 86, 36, false);
    // time string
    KERNEL->DrawString(RStringToFFVIIString("Time"), mTimeX + 4, mTimeY + 6, F_WHITE);
    // time seconds string
    RString seconds;
    seconds.Format("%02d", mTimer % 60);
    KERNEL->DrawDigit(mTimeX + 67, mTimeY + 8, seconds);
    // time minutes string
    RString minutes;
    minutes.Format("%02d", (mTimer / 60) % 60);
    KERNEL->DrawDigit(mTimeX + 50, mTimeY + 8, minutes);
    // time hours string
    RString hours;
    hours.Format("%d", (mTimer / 60) / 60);
    KERNEL->DrawDigit(mTimeX + 45 - (hours.size() * 7), mTimeY + 8, hours);
    // colon string
    KERNEL->DrawBattleString(":", mTimeX + 44, mTimeY + 9, (mTimerColon) ? BF_WHITE : BF_GRAY);
    KERNEL->DrawBattleString(":", mTimeX + 62, mTimeY + 9, BF_WHITE);
    // gil string
    KERNEL->DrawString(RStringToFFVIIString("Gil"), mTimeX + 4, mTimeY + 20, F_WHITE);
    // gil amount string
    RString gil_amount;
    gil_amount.Format("%d", GAMESTATE->GetSavemap().GilAmount);
    KERNEL->DrawDigit(mTimeX + 81 - (gil_amount.size() * 7), mTimeY + 22, gil_amount);



    // location
    KERNEL->DrawWindow(mLocationX, mLocationY, 180, 24, false);
    // get name of location
    KERNEL->DrawString(GAMESTATE->CurrentFieldNameGet(), mLocationX + 8, mLocationY + 6, F_WHITE);
}



void
PartyMenu::Input(const InputEvent& input)
{
    switch (input.button)
    {
        case KEY_Cz:
        {
            if (mStartLive != true)
            {
                mStartDie = true;
            }
            break;
        }
    }
}



void
PartyMenu::Update(const Uint32 deltaTime)
{
    // update timer
    static char timer = 0;
    ++timer;
    if (timer == 50)
    {
        if (mTimerColon == false)
        {
            mTimerColon = true;
            ++mTimer;
        }
        else
        {
            mTimerColon = false;
        }
        timer = 0;
    }



    // if we appeared on screen
    if (mStartLive == true)
    {
        mPartyX    += (mPartyFinishX - mPartyStartX) / mStep;
        mPartyX     = (mPartyX < mPartyFinishX) ? mPartyFinishX : mPartyX;

        mMenuY     += (mMenuFinishY - mMenuStartY) / mStep;
        mMenuY      = (mMenuY < mMenuFinishY) ? mMenuFinishY : mMenuY;

        mTimeX     += (mTimeFinishX - mTimeStartX) / mStep;
        mTimeX      = (mTimeX > mTimeFinishX) ? mTimeFinishX : mTimeX;

        mLocationY += (mLocationFinishY - mLocationStartY) / mStep;
        mLocationY  = (mLocationY > mLocationFinishY) ? mLocationFinishY : mLocationY;

        // if we finished appearing
        if (mPartyX ==  mPartyFinishX && mMenuY == mMenuFinishY && mLocationY == mLocationFinishY && mTimeX == mTimeFinishX)
        {
            mStartLive = false;
        }
    }



    // if we disappear from screen
    if (mStartDie == true)
    {
        mPartyX    += (mPartyStartX - mPartyFinishX) / mStep;
        mPartyX     = (mPartyX > mPartyStartX) ? mPartyStartX : mPartyX;

        mMenuY     += (mMenuStartY - mMenuFinishY) / mStep;
        mMenuY      = (mMenuY > mMenuStartY) ? mMenuStartY : mMenuY;

        mTimeX     += (mTimeStartX - mTimeFinishX) / mStep;
        mTimeX      = (mTimeX < mTimeStartX) ? mTimeStartX : mTimeX;

        mLocationY += (mLocationStartY - mLocationFinishY) / mStep;
        mLocationY  = (mLocationY < mLocationStartY) ? mLocationStartY : mLocationY;

        // if we finished appearing
        if (mPartyX ==  mPartyStartX && mMenuY == mMenuStartY && mLocationY == mLocationStartY && mTimeX == mTimeStartX)
        {
            MODULEMAN->PopTopModule();
        }
    }
}



/////////////////////////////// PRIVATE    ///////////////////////////////////

//============================= OPERATIONS ===================================

void
PartyMenu::DrawCharInfo(const u32& slotChar, const s32& x, const s32& y) const
{
    if (slotChar < 9)
    {
        // name
        FFVIIString name;
        name.resize(12);
        std::copy(&(GAMESTATE->GetSavemap().Character[slotChar].Name[0]),
                  &(GAMESTATE->GetSavemap().Character[slotChar].Name[12]),
                  name.begin());
        KERNEL->DrawString(name, mPartyX + x + 80, mPartyY + y + 3, F_WHITE);

        // lv hp mp next_level limit level strings
        KERNEL->DrawBattleString("LV", mPartyX + x + 80, mPartyY + y + 15, BF_BLUE);
        KERNEL->DrawBattleString("HP", mPartyX + x + 80, mPartyY + y + 26, BF_BLUE);
        KERNEL->DrawBattleString("MP", mPartyX + x + 80, mPartyY + y + 36, BF_BLUE);
        KERNEL->DrawString(RStringToFFVIIString("next level"), mPartyX + x + 164, mPartyY + y + 5, F_WHITE);
        KERNEL->DrawString(RStringToFFVIIString("Limit level"), mPartyX + x + 164, mPartyY + y + 26, F_WHITE);
        // slashes between hp mp value
        KERNEL->DrawSlash(mPartyX + x + 126, mPartyY + y + 25);
        KERNEL->DrawSlash(mPartyX + x + 126, mPartyY + y + 35);

        // avatar
        // get row of character
        int row = (GAMESTATE->GetSavemap().Character[slotChar].RowFlags & 0x01) ? 0 : 24;
        KERNEL->DrawAvatar(mPartyX + x + row, mPartyY + y, GAMESTATE->GetSavemap().Character[slotChar].Id);

        // lv value
        RString level;
        level.Format("%d", GAMESTATE->GetSavemap().Character[slotChar].Level);
        KERNEL->DrawDigit(mPartyX + x + 126 - (level.size() * 7), mPartyY + y + 15, level);

        // current hp value
        RString currenthp;
        currenthp.Format("%d", GAMESTATE->GetSavemap().Character[slotChar].CurrentHP);
        KERNEL->DrawDigit(mPartyX + x + 126 - (currenthp.size() * 7), mPartyY + y + 25, currenthp);

        // maximum hp value
        RString maximumhp;
        maximumhp.Format("%d", GAMESTATE->GetSavemap().Character[slotChar].MaximumHP);
        KERNEL->DrawDigit(mPartyX + x + 158 - (maximumhp.size() * 7), mPartyY + y + 25, maximumhp);

        // hp bar
        KERNEL->DrawBar(mPartyX + x + 98, mPartyY + y + 33,
                        GAMESTATE->GetSavemap().Character[slotChar].CurrentHP,
                        GAMESTATE->GetSavemap().Character[slotChar].MaximumHP,
                        HP_BAR);

        // current mp value
        RString currentmp;
        currentmp.Format("%d", GAMESTATE->GetSavemap().Character[slotChar].CurrentMP);
        KERNEL->DrawDigit(mPartyX + x + 126 - (currentmp.size() * 7), mPartyY + y + 35, currentmp);

        // maximum mp value
        RString maximummp;
        maximummp.Format("%d", GAMESTATE->GetSavemap().Character[slotChar].MaximumMP);
        KERNEL->DrawDigit(mPartyX + x + 158 - (maximummp.size() * 7), mPartyY + y + 35, maximummp);

        // mp bar
        KERNEL->DrawBar(mPartyX + x + 98, mPartyY + y + 43,
                        GAMESTATE->GetSavemap().Character[slotChar].CurrentMP,
                        GAMESTATE->GetSavemap().Character[slotChar].MaximumMP,
                        MP_BAR);

        // exp bar
        KERNEL->DrawBarExp(mPartyX + x + 180, mPartyY + y + 16,
                        GAMESTATE->GetSavemap().Character[slotChar].LevelProgressBar,
                        0x3D,
                        EXP_BAR);

        // current limit level
        RString level_limit;
        level_limit.Format("%d", GAMESTATE->GetSavemap().Character[slotChar].CurrentLimitLevel);
        KERNEL->DrawDigit(mPartyX + x + 228, mPartyY + y + 28, level_limit);

        // limit bar
        BarExpType limit_type = LIMIT_BAR;
        switch (GAMESTATE->GetSavemap().Character[slotChar].StatusFlags)
        {
            case 0x10: limit_type = SADNESS_LIMIT_BAR; break;
            case 0x20: limit_type = FURY_LIMIT_BAR;    break;
        }
        KERNEL->DrawBarExp(mPartyX + x + 180, mPartyY + y + 37,
                        GAMESTATE->GetSavemap().Character[slotChar].CurrentLimitBar,
                        255,
                        limit_type);
    }
}
