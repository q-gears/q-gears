// $Id: Menu.h 93 2006-11-12 13:49:02Z einherjar $

/**
 * @brief Menu base module.
 */

#ifndef MENU_h
#define MENU_h

#include "common/TypeDefine.h"
#include "common/display/actor/Actor.h"



class Menu : public Actor
{
public:
// LIFECYCLE

    /**
     * @brief Default constructor.
     */
    Menu(void);

    /**
     * @brief Default destructor.
     */
    virtual ~Menu(void);

// OPERATIONS

    /**
     * @brief Init module.
     */
    virtual void Init(void);

    /**
     * @brief Draw module.
     */
    virtual void Draw(void);

    /**
     * @brief Handles input.
     *
     * @param input - single input event.
     */
    virtual void Input(const InputEvent& input);

    /**
     * @brief Handles update.
     *
     * @param deltaTime - time passed from last call.
     */
    virtual void Update(const Uint32 deltaTime);
};



#endif // MENU_h
