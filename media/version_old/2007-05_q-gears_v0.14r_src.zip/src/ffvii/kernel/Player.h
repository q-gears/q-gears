// $Id$

#ifndef PLAYER_h
#define PLAYER_h

#include <map>
#include <vector>

#include "common/TypeDefine.h"

//class Character;



struct ItemSlot
{
    ItemSlot(void):
        id(-1),
        quantity(0)
    {
    }

    Sint32 id;
    Uint32 quantity;
};



struct MateriaSlot
{
    MateriaSlot(void):
        id(-1),
        ap(0)
    {
    }

    Sint32 id;
    Sint32 ap;
};



class Player
{
public:
                       Player(void);
    virtual           ~Player(void);

    void               AddItems(const Sint32 item_id, const Uint32 quantity);
    const Uint32       GetItemQuantityById(const Sint32 item_id);
    const Uint32       GetItemQuantityBySlot(const Uint32 slot_id) const;
    const Sint32       GetItemIdBySlot(const Uint32 slot_id) const;
    void               RemoveItems(const Sint32 item_id, const Uint32 quantity);

    void               AddMateria(const Sint32 materia_id, const Sint32 ap);
    const Sint32       GetMateriaIdBySlot(const Uint32 slot_id) const;
    const Sint32       GetMateriaApBySlot(const Uint32 slot_id) const;
    void               RemoveMateria(const Uint32 slot_id);

    void               AddMoney(const Uint32 amount);
    const Uint32       GetMoney(void) const;
    void               RemoveMoney(const Uint32 amount);

private:
    std::vector<ItemSlot>    m_Items;
    std::vector<MateriaSlot> m_Materias;
    Uint32                   m_Money;

//    std::vector<Character*>  m_Characters;
//    std::vector<Character*>  m_Party;
};



#endif
