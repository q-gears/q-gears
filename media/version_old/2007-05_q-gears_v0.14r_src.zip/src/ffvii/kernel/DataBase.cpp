// $Id: DataBase.cpp 94 2006-11-12 19:44:43Z crazy_otaku $

#include "common/utilites/Logger.h"

#include "DataBase.h"
#include "ffvii/filetypes/BinGZipFile.h"



// initializing of static member
std::vector<DBCommand>   DataBase::mCommands;
std::vector<DBAttack>    DataBase::mAttacks;
std::vector<DBItem>      DataBase::mItems;
std::vector<DBWeapon>    DataBase::mWeapons;
std::vector<DBArmor>     DataBase::mArmors;
std::vector<DBAccessory> DataBase::mAccessorys;
std::vector<DBMateria>   DataBase::mMaterias;

std::vector<FFVIIString> DataBase::mCommandDescriptions;
std::vector<FFVIIString> DataBase::mMagicDescriptions;
std::vector<FFVIIString> DataBase::mItemDescriptions;
std::vector<FFVIIString> DataBase::mWeaponDescriptions;
std::vector<FFVIIString> DataBase::mArmorDescriptions;
std::vector<FFVIIString> DataBase::mAccessoryDescriptions;
std::vector<FFVIIString> DataBase::mMateriaDescriptions;
std::vector<FFVIIString> DataBase::mKeyItemDescriptions;
std::vector<FFVIIString> DataBase::mCommandNames;
std::vector<FFVIIString> DataBase::mMagicNames;
std::vector<FFVIIString> DataBase::mItemNames;
std::vector<FFVIIString> DataBase::mWeaponNames;
std::vector<FFVIIString> DataBase::mArmorNames;
std::vector<FFVIIString> DataBase::mAccessoryNames;
std::vector<FFVIIString> DataBase::mMateriaNames;
std::vector<FFVIIString> DataBase::mKeyItemNames;
std::vector<FFVIIString> DataBase::mBattleText;
std::vector<FFVIIString> DataBase::mSummonNames;



DataBase* DATABASE = NULL; // global and accessable from anywhere in our program



DataBase::DataBase(void)
{
    mStringNull.push_back(0xFF);



    BinGZipFile* kernel_file = new BinGZipFile("INIT/KERNEL.BIN");

    File* file;



    // load commands
    file = kernel_file->ExtractGZip(0);
    int file_size = file->GetFileSize();
    for (int i = 0; i < file_size; i += 16)
    {
        DBCommand data;
        file->GetFileBuffer(reinterpret_cast<unsigned char*>(&data), i, 16);
        mCommands.push_back(data);
    }
    delete file;

    // load attacks
    file = kernel_file->ExtractGZip(1);
    file_size = file->GetFileSize();
    for (int i = 0; i < file_size; i += 28)
    {
        DBAttack data;
        file->GetFileBuffer(reinterpret_cast<unsigned char*>(&data), i, 28);
        mAttacks.push_back(data);
    }
    delete file;

    // load items
    file = kernel_file->ExtractGZip(4);
    file_size = file->GetFileSize();
    for (int i = 0; i < file_size; i += 27)
    {
        DBItem data;
        file->GetFileBuffer(reinterpret_cast<unsigned char*>(&data), i, 27);
        mItems.push_back(data);
    }
    delete file;

    // load weapons
    file = kernel_file->ExtractGZip(5);
    file_size = file->GetFileSize();
    for (int i = 0; i < file_size; i += 44)
    {
        DBWeapon data;
        file->GetFileBuffer(reinterpret_cast<unsigned char*>(&data), i, 44);
        mWeapons.push_back(data);
    }
    delete file;

    // load armors
    file = kernel_file->ExtractGZip(6);
    file_size = file->GetFileSize();
    for (int i = 0; i < file_size; i += 36)
    {
        DBArmor data;
        file->GetFileBuffer(reinterpret_cast<unsigned char*>(&data), i, 36);
        mArmors.push_back(data);
    }
    delete file;

    // load accessorys
    file = kernel_file->ExtractGZip(7);
    file_size = file->GetFileSize();
    for (int i = 0; i < file_size; i += 16)
    {
        DBAccessory data;
        file->GetFileBuffer(reinterpret_cast<unsigned char*>(&data), i, 16);
        mAccessorys.push_back(data);
    }
    delete file;

    // load materias
    file = kernel_file->ExtractGZip(8);
    file_size = file->GetFileSize();
    for (int i = 0; i < file_size; i += 20)
    {
        DBMateria data;
        file->GetFileBuffer(reinterpret_cast<unsigned char*>(&data), i, 20);
        mMaterias.push_back(data);
    }
    delete file;

    // load commands descriptions
    file = kernel_file->ExtractGZip(9);
    LoadKernelString(mCommandDescriptions, file);
    delete file;

    // load magic descriptions
    file = kernel_file->ExtractGZip(10);
    LoadKernelString(mMagicDescriptions, file);
    delete file;

    // load item descriptions
    file = kernel_file->ExtractGZip(11);
    LoadKernelString(mItemDescriptions, file);
    delete file;

    // load weapon descriptions
    file = kernel_file->ExtractGZip(12);
    LoadKernelString(mWeaponDescriptions, file);
    delete file;

    // load armor descriptions
    file = kernel_file->ExtractGZip(13);
    LoadKernelString(mArmorDescriptions, file);
    delete file;

    // load accessory descriptions
    file = kernel_file->ExtractGZip(14);
    LoadKernelString(mAccessoryDescriptions, file);
    delete file;

    // load materia descriptions
    file = kernel_file->ExtractGZip(15);
    LoadKernelString(mMateriaDescriptions, file);
    delete file;

    // load key item descriptions
    file = kernel_file->ExtractGZip(16);
    LoadKernelString(mKeyItemDescriptions, file);
    delete file;

    // load command names
    file = kernel_file->ExtractGZip(17);
    LoadKernelString(mCommandNames, file);
    delete file;

    // load magic names
    file = kernel_file->ExtractGZip(18);
    LoadKernelString(mMagicNames, file);
    delete file;

    // load item names
    file = kernel_file->ExtractGZip(19);
    LoadKernelString(mItemNames, file);
    delete file;

    // load weapon names
    file = kernel_file->ExtractGZip(20);
    LoadKernelString(mWeaponNames, file);
    delete file;

    // load armor names
    file = kernel_file->ExtractGZip(21);
    LoadKernelString(mArmorNames, file);
    delete file;

    // load accessory names
    file = kernel_file->ExtractGZip(22);
    LoadKernelString(mAccessoryNames, file);
    delete file;

    // load materia names
    file = kernel_file->ExtractGZip(23);
    LoadKernelString(mMateriaNames, file);
    delete file;

    // load key item names
    file = kernel_file->ExtractGZip(24);
    LoadKernelString(mKeyItemNames, file);
    delete file;

    // load battle text
    file = kernel_file->ExtractGZip(25);
    LoadKernelString(mBattleText, file);
    delete file;

    // load summon names
    file = kernel_file->ExtractGZip(26);
    LoadKernelString(mSummonNames, file);
    delete file;

    delete kernel_file;
}



DataBase::~DataBase(void)
{
}



void
DataBase::LoadKernelString(std::vector<FFVIIString> &string_vector, File* &file)
{
    unsigned int offset;
    unsigned int file_size;
    unsigned int i;

    // get command description
    file_size = file->GetFileSize();
    i = 0;
    while (1)
    {
        // get offset of string data
        offset = file->GetU16LE(i * 0x02);

        // if we reached end of file stop the process
        if (offset >= file_size - 1)
        {
            break;
        }

        // read the string and add it to database
        FFVIIString name;
        for (unsigned char temp = 0x00; temp != 0xFF; ++offset)
        {
            temp = file->GetU8(offset);

            if (temp == 0xF9)
            {
                // simple string compression, reference an earlier substring
                ++offset;
                int dist  = (file->GetU8(offset) & 0x3F) + 2;

                int count = (file->GetU8(offset) >> 6) * 2 + 4;
                for (int k = 0; (k < count) && (file->GetU8(offset - dist + k) != 0xFF); ++k)
                {
                    name.push_back(file->GetU8(offset - dist + k));
                }
            }
            else if (temp == 0xF8)
            {
                ++offset;
                ++offset;
//                LOGGER->Log("Unknown text opcode 0xF8.");
            }
            else
            {
                name.push_back(temp);
            }
        }
        string_vector.push_back(name);

        ++i;
    }
}



const DBCommand&
DataBase::GetCommand(const int id) const
{
    static DBCommand null;

    if (id < mCommands.size())
    {
        return mCommands[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted Command from DataBase with id %d.", id);
        return null;
    }
}



const DBAttack&
DataBase::GetAttack(const int id) const
{
    static DBAttack null;

    if (id < mAttacks.size())
    {
        return mAttacks[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted Attack from DataBase with id %d.", id);
        return null;
    }
}



const DBItem&
DataBase::GetItem(const int id) const
{
    static DBItem null;

    if (id < mItems.size())
    {
        return mItems[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted Item from DataBase with id %d.", id);
        return null;
    }
}



const DBWeapon&
DataBase::GetWeapon(const int id) const
{
    static DBWeapon null;

    if (id < mWeapons.size())
    {
        return mWeapons[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted Weapon from DataBase with id %d.", id);
        return null;
    }
}



const DBArmor&
DataBase::GetArmor(const int id) const
{
    static DBArmor null;

    if (id < mArmors.size())
    {
        return mArmors[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted Armor from DataBase with id %d.", id);
        return null;
    }
}



const DBAccessory&
DataBase::GetAccessory(const int id) const
{
    static DBAccessory null;

    if (id < mAccessorys.size())
    {
        return mAccessorys[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted Accessory from DataBase with id %d.", id);
        return null;
    }
}



const DBMateria&
DataBase::GetMateria(const int id) const
{
    static DBMateria null;

    if (id < mMaterias.size())
    {
        return mMaterias[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted Materia from DataBase with id %d.", id);
        return null;
    }
}



const FFVIIString&
DataBase::GetCommandDescription(const int id) const
{
    if (id < mCommandDescriptions.size())
    {
        return mCommandDescriptions[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted Command Description from DataBase with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString&
DataBase::GetMagicDescription(const int id) const
{
    if (id < mMagicDescriptions.size())
    {
        return mMagicDescriptions[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted Magic Description from DataBase with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString&
DataBase::GetItemDescription(const int id) const
{
    if (id < mItemDescriptions.size())
    {
        return mItemDescriptions[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted Item Description from DataBase with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString&
DataBase::GetWeaponDescription(const int id) const
{
    if (id < mWeaponDescriptions.size())
    {
        return mWeaponDescriptions[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted Weapon Description from DataBase with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString&
DataBase::GetArmorDescription(const int id) const
{
    if (id < mArmorDescriptions.size())
    {
        return mArmorDescriptions[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted Armor Description from DataBase with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString&
DataBase::GetAccessoryDescription(const int id) const
{
    if (id < mAccessoryDescriptions.size())
    {
        return mAccessoryDescriptions[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted Accessory Description from DataBase with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString&
DataBase::GetMateriaDescription(const int id) const
{
    if (id < mMateriaDescriptions.size())
    {
        return mMateriaDescriptions[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted Materia Description from DataBase with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString&
DataBase::GetKeyItemDescription(const int id) const
{
    if (id < mKeyItemDescriptions.size())
    {
        return mKeyItemDescriptions[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted KeyItem Description from DataBase with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString&
DataBase::GetCommandName(const int id) const
{
    if (id < mCommandNames.size())
    {
        return mCommandNames[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted Command Name from DataBase with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString&
DataBase::GetMagicName(const int id) const
{
    if (id < mMagicNames.size())
    {
        return mMagicNames[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted Magic Name from DataBase with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString&
DataBase::GetItemName(const int id) const
{
    if (id < mItemNames.size())
    {
        return mItemNames[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted Item Name from DataBase with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString&
DataBase::GetWeaponName(const int id) const
{
    if (id < mWeaponNames.size())
    {
        return mWeaponNames[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted Weapon Name from DataBase with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString&
DataBase::GetArmorName(const int id) const
{
    if (id < mArmorNames.size())
    {
        return mArmorNames[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted Armor Name from DataBase with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString&
DataBase::GetAccessoryName(const int id) const
{
    if (id < mAccessoryNames.size())
    {
        return mAccessoryNames[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted Accessory Name from DataBase with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString&
DataBase::GetMateriaName(const int id) const
{
    if (id < mMateriaNames.size())
    {
        return mMateriaNames[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted Materia Name from DataBase with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString&
DataBase::GetKeyItemName(const int id) const
{
    if (id < mKeyItemNames.size())
    {
        return mKeyItemNames[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted KeyItem Name from DataBase with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString&
DataBase::GetBattleText(const int id) const
{
    if (id < mBattleText.size())
    {
        return mBattleText[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted Battle Text from DataBase with id %d.", id);
        return mStringNull;
    }
}



const FFVIIString&
DataBase::GetSummonName(const int id) const
{
    if (id < mSummonNames.size())
    {
        return mSummonNames[id];
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "Tried to get unexisted Summon Name from DataBase with id %d.", id);
        return mStringNull;
    }
}



const int
DataBase::GetSizeOfCommands() const
{
    return mCommands.size();
}



const int
DataBase::GetSizeOfAttacks() const
{
    return mAttacks.size();
}



const int
DataBase::GetSizeOfWeapons() const
{
    return mWeapons.size();
}



const int
DataBase::GetSizeOfArmors() const
{
    return mArmors.size();
}



const int
DataBase::GetSizeOfAccessorys() const
{
    return mAccessorys.size();
}



const int
DataBase::GetSizeOfCommandDescriptions() const
{
    return mCommandDescriptions.size();
}



const int
DataBase::GetSizeOfMagicDescriptions() const
{
    return mMagicDescriptions.size();
}



const int
DataBase::GetSizeOfItemDescriptions() const
{
    return mItemDescriptions.size();
}



const int
DataBase::GetSizeOfWeaponDescriptions() const
{
    return mWeaponDescriptions.size();
}



const int
DataBase::GetSizeOfArmorDescriptions() const
{
    return mArmorDescriptions.size();
}



const int
DataBase::GetSizeOfAccessoryDescriptions() const
{
    return mAccessoryDescriptions.size();
}



const int
DataBase::GetSizeOfMateriaDescriptions() const
{
    return mMateriaDescriptions.size();
}



const int
DataBase::GetSizeOfKeyItemDescriptions() const
{
    return mKeyItemDescriptions.size();
}



const int
DataBase::GetSizeOfCommandNames() const
{
    return mCommandNames.size();
}



const int
DataBase::GetSizeOfMagicNames() const
{
    return mMagicNames.size();
}



const int
DataBase::GetSizeOfItemNames() const
{
    return mItemNames.size();
}



const int
DataBase::GetSizeOfWeaponNames() const
{
    return mWeaponNames.size();
}



const int
DataBase::GetSizeOfArmorNames() const
{
    return mArmorNames.size();
}



const int
DataBase::GetSizeOfAccessoryNames() const
{
    return mAccessoryNames.size();
}



const int
DataBase::GetSizeOfMateriaNames() const
{
    return mMateriaNames.size();
}



const int
DataBase::GetSizeOfKeyItemNames() const
{
    return mKeyItemNames.size();
}



const int
DataBase::GetSizeOfBattleTexts() const
{
    return mBattleText.size();
}



const int
DataBase::GetSizeOfSummonNames() const
{
    return mSummonNames.size();
}
