// $Id: DbCommand.h 98 2006-11-21 21:46:28Z einherjar $

#ifndef DBCOMMAND_H
#define DBCOMMAND_H

#include "common/TypeDefine.h"

struct DBCommand
{
    u8 Unknown[16];
};

#endif
