// $Id: DbArmor.h 98 2006-11-21 21:46:28Z einherjar $

#ifndef DBARMOR_H
#define DBARMOR_H

#include "common/TypeDefine.h"

struct DBArmor
{
    u8 Unknown[36];
};

#endif
