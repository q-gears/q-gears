// $Id: DbItem.h 98 2006-11-21 21:46:28Z einherjar $

#ifndef DBITEM_H
#define DBITEM_H

#include "common/TypeDefine.h"

struct DBItem
{
    u8 Unknown[27];
};

#endif
