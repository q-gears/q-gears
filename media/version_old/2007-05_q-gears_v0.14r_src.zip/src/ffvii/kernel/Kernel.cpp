// $Id: Kernel.cpp 147 2007-02-24 06:13:17Z super_gb $

#include "common/display/Display.h"
#include "common/display/surface/Surface.h"
#include "common/display/surface/SurfaceSaveBmp.h"
#include "common/input/InputFilter.h"
#include "common/utilites/Config.h"
#include "common/utilites/Logger.h"
#include "common/utilites/StdString.h"
#include "common/utilites/Utilites.h"

#include "Kernel.h"
#include "ffvii/filetypes/BinGZipFile.h"
#include "ffvii/filetypes/TimFile.h"



Kernel* KERNEL = NULL; // global and accessable from anywhere in our program



Kernel::Kernel():
    m_BattleLock(false),
    m_MovieLock(false)
{
    m_ButtonsCurrentState.assist   = false;
    m_ButtonsCurrentState.start    = false;
    m_ButtonsCurrentState.up       = false;
    m_ButtonsCurrentState.right    = false;
    m_ButtonsCurrentState.down     = false;
    m_ButtonsCurrentState.left     = false;
    m_ButtonsCurrentState.camera   = false;
    m_ButtonsCurrentState.target   = false;
    m_ButtonsCurrentState.next     = false;
    m_ButtonsCurrentState.previous = false;
    m_ButtonsCurrentState.menu     = false;
    m_ButtonsCurrentState.ok       = false;
    m_ButtonsCurrentState.cancel   = false;
    m_ButtonsCurrentState.switch_  = false;

    m_ButtonsPreviousState = m_ButtonsCurrentState;
}



Kernel::~Kernel()
{
    delete mGuiAvatar;
    delete mGuiBar;
    delete mGuiBarExp;
    delete mGuiCounter;
    delete mGuiDigit;
    delete mGuiColorOverlay;
    delete mGuiPointer;
    delete mGuiSlash;
    delete mGuiMarkTriangle;
    delete mBattleFont;
    delete mFont;
    delete mWindow;
}



void
Kernel::Init(void)
{
    LOGGER->Log(LOGGER_INFO, "KERNEL: Init game base graphics.");
    InitGraphics();
    LOGGER->Log(LOGGER_INFO, "KERNEL: Game graphics inited.");
}



void
Kernel::Update(void)
{
    m_ButtonsPreviousState = m_ButtonsCurrentState;

    m_ButtonsCurrentState.assist   = INPUTFILTER->IsButtonPressed(KEY_SPACE);
    m_ButtonsCurrentState.start    = INPUTFILTER->IsButtonPressed(KEY_ENTER);
    m_ButtonsCurrentState.up       = INPUTFILTER->IsButtonPressed(KEY_UP);
    m_ButtonsCurrentState.right    = INPUTFILTER->IsButtonPressed(KEY_RIGHT);
    m_ButtonsCurrentState.down     = INPUTFILTER->IsButtonPressed(KEY_DOWN);
    m_ButtonsCurrentState.left     = INPUTFILTER->IsButtonPressed(KEY_LEFT);
    m_ButtonsCurrentState.camera   = INPUTFILTER->IsButtonPressed(KEY_HOME);
    m_ButtonsCurrentState.target   = INPUTFILTER->IsButtonPressed(KEY_PGUP);
    m_ButtonsCurrentState.next     = INPUTFILTER->IsButtonPressed(KEY_PGDN);
    m_ButtonsCurrentState.previous = INPUTFILTER->IsButtonPressed(KEY_END);
    m_ButtonsCurrentState.menu     = INPUTFILTER->IsButtonPressed(KEY_Cs);
    m_ButtonsCurrentState.ok       = INPUTFILTER->IsButtonPressed(KEY_Cx);
    m_ButtonsCurrentState.cancel   = INPUTFILTER->IsButtonPressed(KEY_Cz);
    m_ButtonsCurrentState.switch_  = INPUTFILTER->IsButtonPressed(KEY_Ca);
}



const GameButtons&
Kernel::GetGameButtonsCurrentState(void) const
{
    return m_ButtonsCurrentState;
}



const GameButtons&
Kernel::GetGameButtonsPreviousState(void) const
{
    return m_ButtonsPreviousState;
}



const bool
Kernel::BattleLockGet(void)
{
    return m_BattleLock;
}



void
Kernel::BattleLockSet(const bool lock)
{
    m_BattleLock = lock;
}



const bool
Kernel::MovieLockGet(void)
{
    return m_MovieLock;
}



void
Kernel::MovieLockSet(const bool lock)
{
    m_MovieLock = lock;
}



void
Kernel::SetFrontScreen(void)
{
    DISPLAY->PushMatrix();
    DISPLAY->LoadIdentity();
    DISPLAY->Scale(2.0f / CONFIG->GAME_WIDTH, 2.0f / CONFIG->GAME_HEIGHT, 1.0f);
    DISPLAY->Translate(-160.0f, 112.0f, 0.0f);

    DISPLAY->CameraPushMatrix();
    DISPLAY->CameraLoadIdentity();
    DISPLAY->TexturePushMatrix();
    DISPLAY->TextureLoadIdentity();
}



void
Kernel::UnsetFrontScreen(void)
{
    DISPLAY->TexturePopMatrix();
    DISPLAY->CameraPopMatrix();
    DISPLAY->PopMatrix();
}



void
Kernel::DrawAvatar(const int x, const int y, const unsigned char avatar_id)
{
    SetFrontScreen();
    mGuiAvatar->DrawAvatar(x, y, avatar_id);
    UnsetFrontScreen();
}



void
Kernel::DrawBar(const int x, const int y, const unsigned int cur, const unsigned int max, const BarType& type)
{
    SetFrontScreen();
    mGuiBar->DrawBar(x, y, cur, max, type);
    UnsetFrontScreen();
}



void
Kernel::DrawBarExp(const int x, const int y, const unsigned int cur, const unsigned int max, const BarExpType& type)
{
    SetFrontScreen();
    mGuiBarExp->DrawBarExp(x, y, cur, max, type);
    UnsetFrontScreen();
}



void
Kernel::DrawBattleString(const RString& string, const int x, const int y, const BattleFontColor& color)
{
    SetFrontScreen();
    mBattleFont->DrawString(string, x, y, color);
    UnsetFrontScreen();
}


void
Kernel::DrawMarkTriangle(const int x, const int y, const u8 frame, const MarkTriangleColor& color)
{
    SetFrontScreen();
    mGuiMarkTriangle->Draw(x, y, frame, color);
    UnsetFrontScreen();
}



void
Kernel::DrawString(const FFVIIString& string, const int x, const int y, const FontColor& color, const int size)
{
    SetFrontScreen();
    mFont->DrawString(string, x, y, color, size);
    UnsetFrontScreen();
}



void
Kernel::DrawWindow(const int x, const int y, const int width, const int height, const bool opacity)
{
    SetFrontScreen();
    mWindow->DrawWindow(x, y, width, height, opacity);
    UnsetFrontScreen();
}



void
Kernel::DrawPointer(const int x, const int y, const PointerType& type)
{
    SetFrontScreen();
    mGuiPointer->DrawPointer(x, y, type);
    UnsetFrontScreen();
}



void
Kernel::DrawSlash(const int x, const int y)
{
    SetFrontScreen();
    mGuiSlash->DrawSlash(x, y);
    UnsetFrontScreen();
}



void
Kernel::DrawCounter(const int x, const int y, const RString& string)
{
    SetFrontScreen();
    mGuiCounter->DrawCounter(x, y, string);
    UnsetFrontScreen();
}



void
Kernel::DrawDigit(const int x, const int y, const RString& string)
{
    SetFrontScreen();
    mGuiDigit->DrawDigit(x, y, string);
    UnsetFrontScreen();
}



void
Kernel::DrawColorOverlay(const Color& color)
{
    SetFrontScreen();
    mGuiColorOverlay->Draw(color);
    UnsetFrontScreen();
}



void
Kernel::InitGraphics()
{
    BinGZipFile* file = new BinGZipFile("INIT/WINDOW.BIN");
    File* window_graf  = file->ExtractGZip(0);
    File* font_graf    = file->ExtractGZip(1);
    File* font_padding = file->ExtractGZip(2);
    delete file;

    TimFile* image = new TimFile(window_graf);
    delete window_graf;



    // Init window
    LOGGER->Log(LOGGER_INFO, "KERNEL::InitGraphics: Init window.");
    Surface* texture0 = image->GetSurface(0);
    if (texture0 != NULL)
    {
        mWindow = new DialogWindow(texture0);
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING,
			"KERNEL::InitGraphics: Can't load window texture.");
    }
    LOGGER->Log(LOGGER_INFO, "KERNEL::InitGraphics: Window inited.");



    // Init pointer
    LOGGER->Log(LOGGER_INFO, "KERNEL::InitGraphics: Init pointer.");
    Surface* texture1 = image->GetSurface(1);
    Surface* texture7 = image->GetSurface(7);
    if (texture1 != NULL && texture7 != NULL)
    {
        mGuiPointer   = new GuiPointer(texture1, texture7);
        mGuiSlash     = new GuiSlash(texture1);
        delete texture1;
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "KERNEL::InitGraphics: Can't load pointer and slash texture.");
    }
    LOGGER->Log(LOGGER_INFO, "KERNEL::InitGraphics: Pointer inited.");



    // Init battle font
    LOGGER->Log(LOGGER_INFO, "KERNEL::InitGraphics: Init battle font.");
    Surface* texture5 = image->GetSurface(5);
    if (texture0 != NULL && texture5 != NULL && texture7 != NULL)
    {
        mBattleFont = new BattleFont(texture0, texture5, texture7);
        mGuiDigit   = new GuiDigit(texture7);
        mGuiBarExp  = new GuiBarExp(texture7);
        delete texture0;
        delete texture5;
        delete texture7;
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING, "KERNEL::InitGraphics: Can't load battle font, digit and bar exp texture.");
    }
    LOGGER->Log(LOGGER_INFO, "KERNEL::InitGraphics: Battle font inited.");



    // Init triangle
    LOGGER->Log(LOGGER_INFO, "KERNEL::InitGraphics: Init mark triangle.");
    Surface* texture8 = image->GetSurface(8);
    Surface* texture9 = image->GetSurface(9);
    if (texture8 != NULL && texture9 != NULL)
    {
        mGuiMarkTriangle = new GuiMarkTriangle(texture8, texture9);
        delete texture8;
        delete texture9;
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING,
			"KERNEL::InitGraphics: Can't load mark triangle texture.");
    }
    LOGGER->Log(LOGGER_INFO, "KERNEL::InitGraphics: Mark triangle inited.");



    // Init counter
    LOGGER->Log(LOGGER_INFO, "KERNEL::InitGraphics: Init counter.");
    Surface* texture12 = image->GetSurface(12);
    if (texture12 != NULL)
    {
        mGuiCounter = new GuiCounter(texture12);
        delete texture12;
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING,
			"KERNEL::InitGraphics: Can't load counter font texture.");
    }
    LOGGER->Log(LOGGER_INFO, "KERNEL::InitGraphics: Counter inited.");



    delete image;



    // Init usual font
    LOGGER->Log(LOGGER_INFO, "KERNEL::InitGraphics: Init usual font.");
    TimFile* image2 = new TimFile(font_graf);
    delete font_graf;



    Surface* texture2_0 = image2->GetSurface(0);
    Surface* texture2_5 = image2->GetSurface(5);
    Surface* texture2_7 = image2->GetSurface(7);

    if (texture2_0 != NULL && texture2_5 != NULL && texture2_7 != NULL && font_padding != NULL)
    {
        mFont = new Font(texture2_0, texture2_5, texture2_7, font_padding);
        delete texture2_0;
        delete texture2_5;
        delete texture2_7;
        delete font_padding;
    }
    else
    {
        LOGGER->Log(LOGGER_WARNING,
			"KERNEL::InitGraphics: Can't load font texture.");
    }

    delete image2;
    LOGGER->Log(LOGGER_INFO, "KERNEL::InitGraphics: Usual font inited.");



    LOGGER->Log(LOGGER_INFO, "KERNEL::InitGraphics: Init avatar.");
    mGuiAvatar = new GuiAvatar();
    LOGGER->Log(LOGGER_INFO, "KERNEL::InitGraphics: Avatar inited.");
    LOGGER->Log(LOGGER_INFO, "KERNEL::InitGraphics: Init bar.");
    mGuiBar    = new GuiBar();
    LOGGER->Log(LOGGER_INFO, "KERNEL::InitGraphics: Bar inited.");
    LOGGER->Log(LOGGER_INFO, "KERNEL::InitGraphics: Init color overlay.");
    mGuiColorOverlay = new GuiColorOverlay();
    LOGGER->Log(LOGGER_INFO, "KERNEL::InitGraphics: Color overlay inited.");
}
