// $Id: GuiBarExp.cpp 103 2006-11-26 07:19:38Z crazy_otaku $

#include "GuiBarExp.h"
#include "common/display/3dTypes.h"
#include "common/display/Display.h"
#include "common/display/surface/Surface.h"
#include "common/utilites/Logger.h"



GuiBarExp::GuiBarExp(Surface* image)
{
    Surface* temp = CreateSubSurface(136, 8, 64, 8, image);
    mTexId = DISPLAY->CreateTexture(temp);
    delete temp;



    Vertex point;
    point.p.x = 0.0f;  point.p.y = 0.0f;  point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;  point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 0.0f;  point.t.y = 0.0f;
    mPoly.vertexes.push_back(point);
    point.p.x = 64.0f; point.p.y = 0.0f;  point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;  point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 0.0f;
    mPoly.vertexes.push_back(point);
    point.p.x = 64.0f; point.p.y = -8.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;  point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 1.0f;
    mPoly.vertexes.push_back(point);
    point.p.x = 0.0f;  point.p.y = -8.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;  point.c.b = 1.0f; point.c.a =  1.0f;
    point.t.x = 0.0f;  point.t.y = 1.0f;
    mPoly.vertexes.push_back(point);



    point.p.x = 2.0f;  point.p.y = -1.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;  point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 0.0f;  point.t.y = 0.0f;
    mPolyOverlay.vertexes.push_back(point);
    point.p.x = 60.0f; point.p.y = -1.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;  point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 0.0f;
    mPolyOverlay.vertexes.push_back(point);
    point.p.x = 60.0f; point.p.y = -3.5f; point.p.z = 0.0f;
    point.c.r = 255.0f/255.0f;  point.c.g = 255.0f/255.0f;  point.c.b = 255.0f/255.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 1.0f;
    mPolyOverlay.vertexes.push_back(point);
    point.p.x = 2.0f;  point.p.y = -3.5f; point.p.z = 0.0f;
    point.c.r = 255.0f/255.0f;  point.c.g = 255.0f/255.0f;  point.c.b = 255.0f/255.0f; point.c.a = 1.0f;
    point.t.x = 0.0f;  point.t.y = 1.0f;
    mPolyOverlay.vertexes.push_back(point);
    point.p.x = 2.0f;  point.p.y = -3.5f; point.p.z = 0.0f;
    point.c.r = 255.0f/255.0f;  point.c.g = 255.0f/255.0f;  point.c.b = 255.0f/255.0f; point.c.a = 1.0f;
    point.t.x = 0.0f;  point.t.y = 0.0f;
    mPolyOverlay.vertexes.push_back(point);
    point.p.x = 60.0f; point.p.y = -3.5f; point.p.z = 0.0f;
    point.c.r = 255.0f/255.0f;  point.c.g = 255.0f/255.0f;  point.c.b = 255.0f/255.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 0.0f;
    mPolyOverlay.vertexes.push_back(point);
    point.p.x = 60.0f; point.p.y = -6.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;  point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f;  point.t.y = 1.0f;
    mPolyOverlay.vertexes.push_back(point);
    point.p.x = 2.0f;  point.p.y = -6.0f; point.p.z = 0.0f;
    point.c.r = 1.0f;  point.c.g = 1.0f;  point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 0.0f;  point.t.y = 1.0f;
    mPolyOverlay.vertexes.push_back(point);
}



GuiBarExp::~GuiBarExp()
{
    DISPLAY->DeleteTexture(mTexId);
}



void
GuiBarExp::DrawBarExp(const int &x, const int &y, const unsigned int &cur, const unsigned int &max, const BarExpType &type)
{
    DISPLAY->PushMatrix();
    DISPLAY->Translate(x, -y, 0);
    DISPLAY->SetTexture(mTexId);
    DISPLAY->DrawQuads(mPoly);
    DISPLAY->UnsetTexture();

//    DISPLAY->SetBlendMode(BLEND_ADD);
    switch (type)
    {
        case EXP_BAR:
        {
            mPolyOverlay.vertexes[7].c.r = mPolyOverlay.vertexes[6].c.r = mPolyOverlay.vertexes[1].c.r = mPolyOverlay.vertexes[0].c.r = 128.0f/255.0f;
            mPolyOverlay.vertexes[7].c.g = mPolyOverlay.vertexes[6].c.g = mPolyOverlay.vertexes[1].c.g = mPolyOverlay.vertexes[0].c.g = 16.0f/255.0f;
            mPolyOverlay.vertexes[7].c.b = mPolyOverlay.vertexes[6].c.b = mPolyOverlay.vertexes[1].c.b = mPolyOverlay.vertexes[0].c.b = 16.0f/255.0f;

            mPolyOverlay.vertexes[5].c.r = mPolyOverlay.vertexes[4].c.r = mPolyOverlay.vertexes[3].c.r = mPolyOverlay.vertexes[2].c.r = 128.0f/255.0f;
            mPolyOverlay.vertexes[5].c.g = mPolyOverlay.vertexes[4].c.g = mPolyOverlay.vertexes[3].c.g = mPolyOverlay.vertexes[2].c.g = 92.0f/255.0f;
            mPolyOverlay.vertexes[5].c.b = mPolyOverlay.vertexes[4].c.b = mPolyOverlay.vertexes[3].c.b = mPolyOverlay.vertexes[2].c.b = 92.0f/255.0f;
            break;
        }
        case LIMIT_BAR:
        {
            mPolyOverlay.vertexes[7].c.r = mPolyOverlay.vertexes[6].c.r = mPolyOverlay.vertexes[1].c.r = mPolyOverlay.vertexes[0].c.r = 128.0f/255.0f;
            mPolyOverlay.vertexes[7].c.g = mPolyOverlay.vertexes[6].c.g = mPolyOverlay.vertexes[1].c.g = mPolyOverlay.vertexes[0].c.g = 16.0f/255.0f;
            mPolyOverlay.vertexes[7].c.b = mPolyOverlay.vertexes[6].c.b = mPolyOverlay.vertexes[1].c.b = mPolyOverlay.vertexes[0].c.b = 76.0f/255.0f;

            mPolyOverlay.vertexes[5].c.r = mPolyOverlay.vertexes[4].c.r = mPolyOverlay.vertexes[3].c.r = mPolyOverlay.vertexes[2].c.r = 128.0f/255.0f;
            mPolyOverlay.vertexes[5].c.g = mPolyOverlay.vertexes[4].c.g = mPolyOverlay.vertexes[3].c.g = mPolyOverlay.vertexes[2].c.g = 92.0f/255.0f;
            mPolyOverlay.vertexes[5].c.b = mPolyOverlay.vertexes[4].c.b = mPolyOverlay.vertexes[3].c.b = mPolyOverlay.vertexes[2].c.b = 108.0f/255.0f;
            break;
        }
        case FURY_LIMIT_BAR:
        {
            mPolyOverlay.vertexes[7].c.r = mPolyOverlay.vertexes[6].c.r = mPolyOverlay.vertexes[1].c.r = mPolyOverlay.vertexes[0].c.r = 128.0f/255.0f;
            mPolyOverlay.vertexes[7].c.g = mPolyOverlay.vertexes[6].c.g = mPolyOverlay.vertexes[1].c.g = mPolyOverlay.vertexes[0].c.g = 0.0f/255.0f;
            mPolyOverlay.vertexes[7].c.b = mPolyOverlay.vertexes[6].c.b = mPolyOverlay.vertexes[1].c.b = mPolyOverlay.vertexes[0].c.b = 0.0f/255.0f;

            mPolyOverlay.vertexes[5].c.r = mPolyOverlay.vertexes[4].c.r = mPolyOverlay.vertexes[3].c.r = mPolyOverlay.vertexes[2].c.r = 128.0f/255.0f;
            mPolyOverlay.vertexes[5].c.g = mPolyOverlay.vertexes[4].c.g = mPolyOverlay.vertexes[3].c.g = mPolyOverlay.vertexes[2].c.g = 92.0f/255.0f;
            mPolyOverlay.vertexes[5].c.b = mPolyOverlay.vertexes[4].c.b = mPolyOverlay.vertexes[3].c.b = mPolyOverlay.vertexes[2].c.b = 108.0f/255.0f;
            break;
        }
        case SADNESS_LIMIT_BAR:
        {
            mPolyOverlay.vertexes[7].c.r = mPolyOverlay.vertexes[6].c.r = mPolyOverlay.vertexes[1].c.r = mPolyOverlay.vertexes[0].c.r = 0.0f/255.0f;
            mPolyOverlay.vertexes[7].c.g = mPolyOverlay.vertexes[6].c.g = mPolyOverlay.vertexes[1].c.g = mPolyOverlay.vertexes[0].c.g = 0.0f/255.0f;
            mPolyOverlay.vertexes[7].c.b = mPolyOverlay.vertexes[6].c.b = mPolyOverlay.vertexes[1].c.b = mPolyOverlay.vertexes[0].c.b = 128.0f/255.0f;

            mPolyOverlay.vertexes[5].c.r = mPolyOverlay.vertexes[4].c.r = mPolyOverlay.vertexes[3].c.r = mPolyOverlay.vertexes[2].c.r = 108.0f/255.0f;
            mPolyOverlay.vertexes[5].c.g = mPolyOverlay.vertexes[4].c.g = mPolyOverlay.vertexes[3].c.g = mPolyOverlay.vertexes[2].c.g = 92.0f/255.0f;
            mPolyOverlay.vertexes[5].c.b = mPolyOverlay.vertexes[4].c.b = mPolyOverlay.vertexes[3].c.b = mPolyOverlay.vertexes[2].c.b = 128.0f/255.0f;
            break;
        }
    }

    float size = 2.0f + 58.0f * static_cast<float>(cur) / static_cast<float>(max);
    mPolyOverlay.vertexes[6].p.x = mPolyOverlay.vertexes[5].p.x = mPolyOverlay.vertexes[2].p.x = mPolyOverlay.vertexes[1].p.x = size;
    DISPLAY->DrawQuads(mPolyOverlay);
//    DISPLAY->SetBlendMode(BLEND_NORMAL);
    DISPLAY->PopMatrix();
}
