// $Id: GuiSlash.cpp 103 2006-11-26 07:19:38Z crazy_otaku $

#include "GuiSlash.h"

#include "common/display/3dTypes.h"
#include "common/display/Display.h"
#include "common/display/surface/Surface.h"
#include "common/utilites/Logger.h"



GuiSlash::GuiSlash(Surface* image)
{
    Surface* temp = CreateSubSurface(216, 0, 8, 8, image);
    mTexId = DISPLAY->CreateTexture(temp);
    delete temp;



    Vertex point;
    point.p.x = 0.0f; point.p.y = 0.0f;  point.p.z = 0.0f;
    point.c.r = 1.0f; point.c.g = 1.0f;  point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 0.0f; point.t.y = 0.0f;
    mPoly.vertexes.push_back(point);
    point.p.x = 8.0f; point.p.y = 0.0f;  point.p.z = 0.0f;
    point.c.r = 1.0f; point.c.g = 1.0f;  point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f; point.t.y = 0.0f;
    mPoly.vertexes.push_back(point);
    point.p.x = 8.0f; point.p.y = -8.0f; point.p.z = 0.0f;
    point.c.r = 1.0f; point.c.g = 1.0f;  point.c.b = 1.0f; point.c.a = 1.0f;
    point.t.x = 1.0f; point.t.y = 1.0f;
    mPoly.vertexes.push_back(point);
    point.p.x = 0.0f; point.p.y = -8.0f; point.p.z = 0.0f;
    point.c.r = 1.0f; point.c.g = 1.0f;  point.c.b = 1.0f; point.c.a =  1.0f;
    point.t.x = 0.0f; point.t.y = 1.0f;
    mPoly.vertexes.push_back(point);
}



GuiSlash::~GuiSlash()
{
    DISPLAY->DeleteTexture(mTexId);
}



void
GuiSlash::DrawSlash(const int &x, const int &y)
{
    DISPLAY->PushMatrix();
    DISPLAY->Translate(x, -y, 0);
    DISPLAY->SetTexture(mTexId);
    DISPLAY->DrawQuads(mPoly);
    DISPLAY->UnsetTexture();
    DISPLAY->PopMatrix();
}
