// $Id: GuiPointer.h 103 2006-11-26 07:19:38Z crazy_otaku $

#ifndef GUIPOINTER_H
#define GUIPOINTER_H



#include "common/display/3dTypes.h"
#include "common/display/surface/Surface.h"
#include "common/utilites/NoCopy.h"



enum PointerType {TO_LEFT, TO_RIGHT, TO_RIGHT_CROSS};



class GuiPointer : public NoCopy<GuiPointer>
{
public:
             GuiPointer(Surface* image, Surface* image2);

    virtual ~GuiPointer();

    void     DrawPointer(const int &x, const int &y, const PointerType &type);

private:
    int      mPointerTexId[3];
    Geometry mPointerPoly;
};



#endif
