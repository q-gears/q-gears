// $Id: WorldMapModule.h 106 2006-12-10 15:10:10Z einherjar $

#ifndef WORLD_MAP_MODULE_h
#define WORLD_MAP_MODULE_h

#include "common/display/actor/Actor.h"
#include "common/display/math/Vector.h"

class WorldMap;


class WorldMapModule : public Actor
{
public:
  WorldMapModule();
  virtual ~WorldMapModule();

public:
  virtual void Init();

  virtual void Draw() const;

  virtual void Input(const InputEvent& input);

  virtual void Update(const Uint32 deltaTime);

  // Geometry
protected:
  WorldMap *mWorldMap;

  // Camera
protected:
  Vector3 mTranslation;
  float mScale;
};

#endif //  WORLD_MAP_MODULE_h
