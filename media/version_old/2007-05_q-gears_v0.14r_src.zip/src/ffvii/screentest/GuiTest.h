// $Id: GuiTest.h 94 2006-11-12 19:44:43Z crazy_otaku $

#ifndef GUITEST_H
#define GUITEST_H

#include "common/TypeDefine.h"
#include "common/display/3dTypes.h"
#include "common/display/actor/Actor.h"
#include "ffvii/kernel/gui/BattleFont.h"
#include "ffvii/kernel/gui/FFVIIString.h"
#include "ffvii/kernel/gui/GuiPointer.h"

#include <vector>



class GuiTest : public Actor
{
public:
    GuiTest();
    virtual ~GuiTest();

    virtual void Init();

    virtual void Input(const InputEvent &input);

    virtual void Update(const Uint32 delta_time);

    virtual void Draw() const;

private:
    void         DrawStatus();

private:
    int         mTriangleFrame;

    int         mStartY;
    int         mTotalPos;
    int         mPointerPos;
    PointerType mPointerType;

    int         mTimer;
    bool        mTest1;

    int         mTest3First;
    int         mTest3Cur;
    int         mTest3Last;

    FFVIIString mFFString;
};



#endif // GUITEST_H
