// $Id: DisplayTest.cpp 105 2006-12-02 00:07:47Z einherjar $

#include "common/display/Display.h"
#include "common/display/surface/SurfaceLoad.h"
#include "common/display/surface/SurfaceSaveBmp.h"
#include "common/module/ModuleManager.h"
#include "common/utilites/Logger.h"

#include "DisplayTest.h"
#include "GuiTest.h"
#include "MovieTest.h"
#include "ffvii/filetypes/BinGZipFile.h"
#include "ffvii/filetypes/TimFile.h"
#include "ffvii/kernel/Kernel.h"
#include "ffvii/field/BcxFile.h"
#include "ffvii/field/BsxFile.h"
#include "ffvii/field/FieldModule.h"
#include "ffvii/field/TdbFile.h"
#include "ffvii/menu/PartyMenu.h"



ScreenDisplayTest::ScreenDisplayTest():
    m_ModelRot(0.0f)
{
    Init();
}



ScreenDisplayTest::~ScreenDisplayTest()
{
}



void
ScreenDisplayTest::Init()
{
    Vertex point;

    DISPLAY->SetZTestMode(ZTEST_WRITE_ON_PASS);
//    DISPLAY->SetAlphaTest(true);
    DISPLAY->SetCullMode(CULL_NONE);

    DISPLAY->LoadLookAt(50, Vector3(10.1, 5.1, 10.1), Vector3(0, 0, 0), Vector3(0, 1, 0));

    point.p.x = -5.0f; point.p.y =  0.0f; point.p.z =  0.0f;
    point.c.r =  1.0f; point.c.g =  0.0f; point.c.b =  0.0f; point.c.a = 0.5f;
    mPoints.push_back(point);
    point.p.x =  5.0f; point.p.y =  0.0f; point.p.z =  0.0f;
    point.c.r =  1.0f; point.c.g =  0.0f; point.c.b =  0.0f; point.c.a = 0.5f;
    mPoints.push_back(point);
    point.p.x =  0.0f; point.p.y = -5.0f; point.p.z =  0.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 0.5f;
    mPoints.push_back(point);
    point.p.x =  0.0f; point.p.y =  5.0f; point.p.z =  0.0f;
    point.c.r =  0.0f; point.c.g =  1.0f; point.c.b =  0.0f; point.c.a = 0.5f;
    mPoints.push_back(point);
    point.p.x =  0.0f; point.p.y =  0.0f; point.p.z = -5.0f;
    point.c.r =  0.0f; point.c.g =  0.0f; point.c.b =  1.0f; point.c.a = 0.5f;
    mPoints.push_back(point);
    point.p.x =  0.0f; point.p.y =  0.0f; point.p.z =  5.0f;
    point.c.r =  0.0f; point.c.g =  0.0f; point.c.b =  1.0f; point.c.a = 0.5f;
    mPoints.push_back(point);



    TdbFile tex("FIELD/FIELD.TDB");
    tex.WriteFile("FIELD.TDB_u");
    BcxFile model("FIELD/EARITH.BCX");
    model.GetModel(m_Model);
}



void
ScreenDisplayTest::Input(const InputEvent &input)
{
    switch (input.button)
    {
        case KEY_Cg:
        {
            GuiTest* screen = new GuiTest();
            MODULEMAN->PushModule(screen);
            break;
        }
        case KEY_Cm:
        {
            MovieTest* screen = new MovieTest();
            MODULEMAN->PushModule(screen);
            break;
        }
        case KEY_Cs:
        {
            PartyMenu* screen = new PartyMenu();
            MODULEMAN->PushModule(screen);
            break;
        }
        case KEY_Cn:
        {
            MODULEMAN->PopTopModule();
            FieldModule* screen = new FieldModule();
            MODULEMAN->PushModule(screen);
            break;
        }
    }
}



void
ScreenDisplayTest::Update(const Uint32 delta_time)
{
    ++m_ModelRot;
    m_Model.Update(delta_time);
}



void
ScreenDisplayTest::Draw(void) const
{
    DISPLAY->SetPointSize(3);
    DISPLAY->DrawPoints(mPoints);
    DISPLAY->SetLineWidth(1);
    DISPLAY->DrawLines(mPoints);

    DISPLAY->PushMatrix();
    DISPLAY->Scale(0.01f, 0.01f, 0.01f);
    DISPLAY->RotateY(m_ModelRot);
    m_Model.Draw();
    DISPLAY->PopMatrix();

    KERNEL->DrawString(RStringToFFVIIString("Press 'N' button to go to 'Field' module"), 400, 415, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press 'S' button to go to 'Party Menu'"), 400, 430, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press 'G' button to go to 'Gui Test Screen'"), 400, 445, F_WHITE);
    KERNEL->DrawString(RStringToFFVIIString("Press 'Z' button to dismiss both"), 400, 460, F_WHITE);
}
