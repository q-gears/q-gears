// $Id$

#ifndef MARK_TRIANGLE_h
#define MARK_TRIANGLE_h

#include "common/TypeDefine.h"
#include "common/display/actor/Actor.h"
#include "common/display/3dTypes.h"

#include "ffvii/kernel/Kernel.h"

class FieldModule;



class MarkTriangle : public Actor
{
public:
                   MarkTriangle(FieldModule* field_module, const Vector3& position, const MarkTriangleColor& color);
    virtual       ~MarkTriangle(void);

    virtual void   Input(const InputEvent &input);
    virtual void   Update(const Uint32 delta_time);
    virtual void   Draw(void) const;

private:
    FieldModule*      m_FieldModule;

    Vector3           m_Position;
    MarkTriangleColor m_Color;
    Uint8             m_Frame;
};



#endif // MARK_TRIANGLE_h
