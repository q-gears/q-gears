// $Id$

#ifndef OBJECT_MANAGER_h
#define OBJECT_MANAGER_h

#include <vector>

#include "common/TypeDefine.h"
#include "common/display/actor/Actor.h"
#include "common/input/InputFilter.h"
#include "common/utilites/NoCopy.h"

#include "Gateway.h"
#include "Entity.h"
#include "Line.h"
#include "MarkTriangle.h"
#include "WalkMeshTriangle.h"
#include "ffvii/kernel/Kernel.h"

class FieldModule;



enum LadderMovement
{
    MOVE_TO_START,
    MOVE_TO_END,
    NOT_MOVE
};



struct EncounterTable
{
    EncounterTable(void):
        enabled(0),
        rate(0)
    {
        for (u8 i = 0; i < 6; ++i)
        {
            standart_encounter[i].rate  = 0;
            standart_encounter[i].scene = 0;
        }

        for (u8 i = 0; i < 4; ++i)
        {
            special_encounter[i].rate  = 0;
            special_encounter[i].scene = 0;
        }
    }

    struct Encounter
    {
        u8  rate;
        u16 scene;
    };

    bool      enabled;
    u8        rate;

    Encounter standart_encounter[6];
    Encounter special_encounter[4];
};



class ObjectManager : public Actor
{
public:
    explicit       ObjectManager(FieldModule* field_module);
    virtual       ~ObjectManager(void);

    void           Clear(void);

    virtual void   Input(const InputEvent& input);
    virtual void   Update(const Uint32 delta_time);
    virtual void   Draw(void) const;

    void           DrawDebugInfo(void) const;

    void           AddEntity(Entity* entity);
    void           AddScript(Script* script);
    void           AddWalkMeshTriangle(WalkMeshTriangle* triangle);
    void           AddGateway(Gateway* gateway);
    void           AddMarkTriangle(const Vector3& position, const MarkTriangleColor& color);
    void           AddEncounterTable(const EncounterTable& encounterTable);
    void           SetMovement(const Uint32 movement);

    // script
    // 0x01 REQ // 0x02 REQSW // 0x03 REQEW
    void           RequestRunEntity(const Sint32 entity_id, const Uint8 priority, const Uint8 script_id, const Sint32 start_entity_id, const Sint32 end_entity_id);
    // 0x24 WAIT
    void           SetFramesToWait(const Sint32 entity_id, const u16& usWait);
    // 0x33 UC
    void           SetPlayerCharacrerMovability(const bool& bMovability);
    // 0x4B BTLTB
    void           SetEncounterTable(const u8& ubEncounterTable);
    // 0x6D IDLCK
    void           SetTriangleAccess(const Sint16 triangle_id, const Uint8 lock);
    // 0x71 BTLON
    void           DisableEncounter(const bool disable);
    // 0x7E TLKON
    void           SetEntityTalk(const Sint32 entity_id, const bool talk);
    // 0xA0 PC
    void           SetPlayerCharacter(const Sint32 entity_id, const Sint8 pc);
    // 0xA1 CHAR
    void           SetCharacter(const Sint32 entity_id, const s8& sbCharacterId);
    // 0xA4 VISI
    void           SetEntityVisible(const Sint32 entity_id, const bool visible);
    // 0xA5 XYZI
    void           SetPositionByXYZTriangle(const Sint32 entity_id, const Vector3& coords, const Sint16 triangle_id);
    // 0xA8 MOVE
    void           SetEntityToMove(const Sint32 entity_id, const Vector3& end_point);
    // 0xB3 DIR
    void           SetDirection(const Sint32 entity_id, const float direction);
    // 0xB9 GETAI
    const Sint16   GetEntityTriangleId(const Sint32 entity_id);
    // 0xBF CC
    void           SetPlayerCharacterToEntity(const Sint32 entity_id);
    // 0xC0 JUMP
    void           SetEntityToJump(const Sint32 entity_id, const Vector3& end_point, const Uint16 height);
    // 0xC1 AXYZI
    const Vector3& GetEntityPosition(const Sint32 entity_id);
    // 0xC2 LADER
    void           SetEntityToLadder(const Sint32 entity_id, const Vector3& end_point, const Sint16 end_triangle, const Uint8 movement_id);
    // 0xC5 TALKR // 0xD6 TLKR2
    void           SetEntityTalkRange(const Sint32 entity_id, const Uint16 range);
    // 0xC6 SLIDR // 0xD7 SLDR2
    void           SetEntitySolidRange(const Sint32 entity_id, const Uint16 range);
    // 0xC7 SOLID
    void           SetEntitySolid(const Sint32 entity_id, const bool solid);
    // 0xD0 LINE
    void           AddLine(const Sint32 entity_id, const Vector3& point1, const Vector3& point2);
    // 0xD1 LINON
    void           SetLinesCheck(const bool check);
    // 0xD2 MPJPO
    void           SetGatewaysCheck(const bool check);
    // 0xD3 SLINE
    void           SetLine(const Sint32 entity_id, const Vector3& point1, const Vector3& point2);

    void           SetPositionByXZ(const Sint32 entity_id, const Vector3& coords);
    void           SetWait(const Sint32 entity_id, const bool bWait);
    
private:
    const bool     SetNextStep(const Sint32 entity_id, const Vector4& move_vector, const bool first = true);
    void           SetNextLadderStep(const Sint32 entity_id, const LadderMovement& movement);
    void           SetNextJumpStep(const Sint32 entity_id);
    void           SetNextWalkMeshMoveStep(const Sint32 entity_id);

    void           CheckTriggers(const Sint32 entity_id);
    void           CheckEncounters(void);

    // entity utilites
    const Sint32   GetPlayerEntity(void) const;
    void           SetEntityDirectionByVector4(const Sint32 entity_id, const Vector4& vector);

    // check validity
    const bool     CheckEntity(const Sint32 entity_id) const;
    const bool     CheckTriangle(const Sint16 triangle_id) const;

private:
    // feed back to field module
    FieldModule*                   m_FieldModule;

    // script for entity
    Script*                        m_Script;

    // field objects
    std::vector<Entity*>           m_Entitys;
    std::vector<Gateway*>          m_Gateways;
    std::vector<Line>              m_Lines;
    std::vector<MarkTriangle*>     m_MarkTriangles;
    std::vector<WalkMeshTriangle*> m_WalkMesh;

    bool                           m_GatewaysCheck;
    bool                           m_LinesCheck;



    // player character related
    bool                           m_PlayerCharacterMovable;
    Uint32                         m_MovementRotation;



    // ladder movement related
    Uint8                          m_LadderMovementId;
    LadderMovement                 m_ButtonUp[4];
    LadderMovement                 m_ButtonDown[4];
    LadderMovement                 m_ButtonLeft[4];
    LadderMovement                 m_ButtonRight[4];



    // encounters
    std::vector<EncounterTable>    m_Encounters;
    bool                           m_EncounterDisabled;
    Uint32                         m_DangerCounter;



    // debug
    bool                           m_DrawCollisions;
    bool                           m_DrawWalkmesh;
    bool                           m_DrawTriggers;
};



#endif // OBJECT_MANAGER_h
