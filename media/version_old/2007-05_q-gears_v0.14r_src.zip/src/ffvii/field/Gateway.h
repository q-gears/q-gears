// $Id: Gateway.h 96 2006-11-13 03:34:17Z crazy_otaku $

#ifndef GATEWAY_h
#define GATEWAY_h

#include "common/TypeDefine.h"

#include "Trigger.h"



class Gateway : public Trigger
{
public:
             Gateway(FieldModule* pFieldModule, const Vector3& point1, const Vector3& point2, const Vector3& position, const Sint16 map_id);
    virtual ~Gateway(void);

    void     OnEnter(void);
    void     OnMove(void);
    void     OnInside(void);
    void     OnLeave(void);

private:
    Vector3      mPosition;
    Sint16       m_MapId;
};



#endif // GATEWAY_h
