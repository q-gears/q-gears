// $Id: Gateway.cpp 96 2006-11-13 03:34:17Z crazy_otaku $

#include "common/utilites/Logger.h"

#include "FieldModule.h"
#include "Gateway.h"
#include "ffvii/kernel/GameState.h"



Gateway::Gateway(FieldModule* pFieldModule, const Vector3& point1, const Vector3& point2, const Vector3& position, const Sint16 map_id):
    Trigger(pFieldModule, point1, point2),
    mPosition(position),
    m_MapId(map_id)
{
}



Gateway::~Gateway(void)
{
}



void
Gateway::OnEnter(void)
{
    if (m_MapId != -1)
    {
        LOGGER->Log(LOGGER_INFO, "Gateway activates. Load next Map %d", m_MapId);

        GAMESTATE->SetPlayerLoad(true);
        GAMESTATE->SetPlayerPosition(mPosition);
        GAMESTATE->SetPlayerDirection(0.0f);

        m_pFieldModule->RequestLoadMap(m_MapId);
    }
    else
    {
        LOGGER->Log(LOGGER_INFO, "Gateway inactive.");
    }
}



void
Gateway::OnMove(void)
{
}



void
Gateway::OnInside(void)
{
}



void
Gateway::OnLeave(void)
{
}
