// $Id: DatXmlFile.cpp 103 2006-11-26 07:19:38Z crazy_otaku $

#include "common/utilites/Config.h"
#include "common/utilites/Logger.h"

#include "DatXmlFile.h"
#include "Gateway.h"
#include "WalkMeshTriangle.h"



DatXmlFile::DatXmlFile(const RString& file):
    XmlFile(file)
{
    if (mFile != NULL)
    {
        mRootNode = xmlDocGetRootElement(mFile);

        if (!mRootNode || !xmlStrEqual(mRootNode->name, BAD_CAST "field"))
        {
            mNormalFile = false;
            LOGGER->Log(LOGGER_WARNING, "Field XML Manager: %s is not a valid field file! No <field> in root.", file.c_str());
        }
        else
        {
            mNormalFile = true;
        }
    }
    else
    {
        mNormalFile = false;
    }
}



DatXmlFile::~DatXmlFile(void)
{
}



bool
DatXmlFile::GetDialogs(WindowManager& windowManager)
{
    if (mNormalFile != true)
    {
        return false;
    }

    if (GetInt(mRootNode, "dialogs") != 0)
    {
        for (xmlNodePtr node = mRootNode->xmlChildrenNode; node != NULL; node = node->next)
        {
            // load dialogs from xml
            if (xmlStrEqual(node->name, BAD_CAST "dialogs"))
            {
                for (xmlNodePtr node_2 = node->xmlChildrenNode; node_2 != NULL; node_2 = node_2->next)
                {
                    if (!xmlStrEqual(node_2->name, BAD_CAST "dialog"))
                    {
                        continue;
                    }

                    // add dialog to mpWindowManager
                    RString dialog((const char*)node_2->xmlChildrenNode->content, strlen((const char*)node_2->xmlChildrenNode->content));
                    windowManager.AddDialog(RStringToFFVIIString(dialog));
                }
            }
        }

        return true;
    }

    return false;
}



bool
DatXmlFile::GetScripts(ObjectManager& object_manager)
{
    if (mNormalFile != true)
    {
        return false;
    }

    if (GetInt(mRootNode, "entitys") != 0)
    {
        for (xmlNodePtr node = mRootNode->xmlChildrenNode; node != NULL; node = node->next)
        {
            // load entity and scripts from xml
            if (xmlStrEqual(node->name, BAD_CAST "entitys"))
            {
                // whole script buffer
                u8* script_buffer = NULL;
                u32 script_size = 0;
                script_buffer = (u8*)malloc(script_size);
                for (xmlNodePtr node_2 = node->xmlChildrenNode; node_2 != NULL; node_2 = node_2->next)
                {
                    if (!xmlStrEqual(node_2->name, BAD_CAST "entity"))
                    {
                        continue;
                    }

                    Entity* entity = new Entity();

                    RString name = GetString(node_2, "name");
                    entity->SetName(name);

                    for (xmlNodePtr node_3 = node_2->xmlChildrenNode; node_3 != NULL; node_3 = node_3->next)
                    {
                        if (!xmlStrEqual(node_3->name, BAD_CAST "script"))
                        {
                            continue;
                        }

                        u32 script_temp_size = 0;
                        u8* script_temp_buffer = OpcodesToRawScript((u8*)node_3->xmlChildrenNode->content, strlen((const char*)node_3->xmlChildrenNode->content), script_temp_size);

                        if (script_temp_size != 0)
                        {
                            entity->AddEntryPoint(script_size);

                            script_buffer = (u8*)realloc(script_buffer, script_size + script_temp_size);
                            memcpy(script_buffer + script_size, script_temp_buffer, script_temp_size);
                            script_size += script_temp_size;
                        }

                        free(script_temp_buffer);
                    }

                    object_manager.AddEntity(entity);
                }

                Script* script = new Script(script_buffer, script_size);
                object_manager.AddScript(script);
            }
        }

        return true;
    }

    return false;
}



bool
DatXmlFile::GetWalkMesh(ObjectManager& object_manager)
{
    if (mNormalFile != true)
    {
        return false;
    }

    if (GetInt(mRootNode, "walkmesh") != 0)
    {
        for (xmlNodePtr node = mRootNode->xmlChildrenNode; node != NULL; node = node->next)
        {
            // load walkmesh from xml
            if (xmlStrEqual(node->name, BAD_CAST "walkmesh"))
            {
                WalkMeshTriangle* triangle;
                Vector3 A, B, C;

                for (xmlNodePtr node_2 = node->xmlChildrenNode; node_2 != NULL; node_2 = node_2->next)
                {
                    if (!xmlStrEqual(node_2->name, BAD_CAST "triangle"))
                    {
                        continue;
                    }

                    A = GetVector3(node_2, "a");
                    B = GetVector3(node_2, "b");
                    C = GetVector3(node_2, "c");

                    triangle = new WalkMeshTriangle(A, B, C);

                    triangle->SetAccessSide(0, GetInt(node_2, "access1"));
                    triangle->SetAccessSide(1, GetInt(node_2, "access2"));
                    triangle->SetAccessSide(2, GetInt(node_2, "access3"));

                    object_manager.AddWalkMeshTriangle(triangle);
                }
            }
        }

        return true;
    }

    return false;
}



bool
DatXmlFile::GetGateway(ObjectManager& object_manager, FieldModule* field_module)
{
    if (mNormalFile != true)
    {
        return false;
    }

    if (GetInt(mRootNode, "gateways") != 0)
    {
        for (xmlNodePtr node = mRootNode->xmlChildrenNode; node != NULL; node = node->next)
        {
            // load gateways from xml
            if (xmlStrEqual(node->name, BAD_CAST "gateways"))
            {
                Gateway* gateway;

                for (xmlNodePtr node_2 = node->xmlChildrenNode; node_2 != NULL; node_2 = node_2->next)
                {
                    if (!xmlStrEqual(node_2->name, BAD_CAST "gateway"))
                    {
                        continue;
                    }

                    // add gateway to UnitManager
                    Vector3 point1   = GetVector3(node_2, "point1");
                    Vector3 point2   = GetVector3(node_2, "point2");
                    Vector3 position = GetVector3(node_2, "position");

                    Sint16 map_id    = GetInt(node_2, "map_id");

                    gateway = new Gateway(field_module, point1, point2, position, map_id);

                    object_manager.AddGateway(gateway);

                    if (CONFIG->mDumpSpecificGameData == true)
                    {
                        LOGGER->Log(LOGGER_INFO, "Set gateway to map %d", map_id);
                    }



                    RString mark_triangle = GetString(node_2, "mark_triangle");
                    StdString::StdStringEqualsNoCase rstring_compage;
                    if (rstring_compage(mark_triangle, "true") == true)
                    {
                        Vector3 mark_pos((point2.x + point1.x) / 2, (point2.y + point1.y) / 2, (point2.z + point1.z) / 2);

                        object_manager.AddMarkTriangle(mark_pos, RED);

                        if (CONFIG->mDumpSpecificGameData == true)
                        {
                            LOGGER->Log(LOGGER_INFO, "Set mark triangle for gateway %f %f %f", mark_pos.x, mark_pos.y, mark_pos.z);
                        }
                    }
                }
            }
        }

        return true;
    }

    return false;
}



bool
DatXmlFile::GetMarkTriangles(ObjectManager& objectManager)
{
    if (mNormalFile != true)
    {
        return false;
    }

    if (GetInt(mRootNode, "mark_triangles") != 0)
    {
        for (xmlNodePtr node = mRootNode->xmlChildrenNode; node != NULL; node = node->next)
        {
            // load mark triangle from xml
            if (xmlStrEqual(node->name, BAD_CAST "mark_triangles"))
            {
                for (xmlNodePtr node_2 = node->xmlChildrenNode; node_2 != NULL; node_2 = node_2->next)
                {
                    if (!xmlStrEqual(node_2->name, BAD_CAST "triangle"))
                    {
                        continue;
                    }

                    // add gateway to UnitManager
                    Vector3 position = GetVector3(node_2, "pos");

                    RString col = GetString(node_2, "color");
                    MarkTriangleColor color = INVISIBLE;
                    StdString::StdStringEqualsNoCase rstring_compage;
                    if (rstring_compage(col, "green") == true)
                    {
                        color = GREEN;
                    }
                    if (rstring_compage(col, "red") == true)
                    {
                        color = RED;
                    }

                    objectManager.AddMarkTriangle(position, color);
                }
            }
        }

        return true;
    }

    return false;
}




bool
DatXmlFile::GetMovementRotation(ObjectManager& object_manager)
{
    if (mNormalFile != true)
    {
        return false;
    }

    if (GetInt(mRootNode, "movement") != 0)
    {
        for (xmlNodePtr node = mRootNode->xmlChildrenNode; node != NULL; node = node->next)
        {
            // load movement from xml
            if (xmlStrEqual(node->name, BAD_CAST "movement"))
            {
                object_manager.SetMovement(GetInt(node, "rotation"));
            }
        }

        return true;
    }

    return false;
}



bool
DatXmlFile::GetEncounter(ObjectManager& objectManager)
{
    if (mNormalFile != true)
    {
        return false;
    }

    if (GetInt(mRootNode, "encounters") != 0)
    {
        for (xmlNodePtr node = mRootNode->xmlChildrenNode; node != NULL; node = node->next)
        {
            // load encounters from xml
            if (xmlStrEqual(node->name, BAD_CAST "encounters"))
            {
                for (xmlNodePtr node_2 = node->xmlChildrenNode; node_2 != NULL; node_2 = node_2->next)
                {
                    if (!xmlStrEqual(node_2->name, BAD_CAST "table"))
                    {
                        continue;
                    }

                    EncounterTable table;

                    table.enabled = GetInt(node_2, "enabled");
                    table.rate    = GetInt(node_2, "rate");

                    for (xmlNodePtr node_3 = node_2->xmlChildrenNode; node_3 != NULL; node_3 = node_3->next)
                    {
                        if (xmlStrEqual(node_3->name, BAD_CAST "standart"))
                        {
                            u8 i = 0;
                            for (xmlNodePtr node_4 = node_3->xmlChildrenNode; (node_4 != NULL) && (i < 6); node_4 = node_4->next)
                            {
                                if (!xmlStrEqual(node_4->name, BAD_CAST "encounter"))
                                {
                                    continue;
                                }

                                table.standart_encounter[i].rate  = GetInt(node_4, "rate");
                                table.standart_encounter[i].scene = GetInt(node_4, "scene");
                                ++i;
                            }
                        }

                        if (xmlStrEqual(node_3->name, BAD_CAST "special"))
                        {
                            u8 i = 0;
                            for (xmlNodePtr node_4 = node_3->xmlChildrenNode; (node_4 != NULL) && (i < 4); node_4 = node_4->next)
                            {
                                if (!xmlStrEqual(node_4->name, BAD_CAST "encounter"))
                                {
                                    continue;
                                }

                                table.special_encounter[i].rate  = GetInt(node_4, "rate");
                                table.special_encounter[i].scene = GetInt(node_4, "scene");
                                ++i;
                            }
                        }
                    }

                    objectManager.AddEncounterTable(table);
                }
            }
        }

        return true;
    }

    return false;
}
