// $Id: Entity.h 94 2006-11-12 19:44:43Z crazy_otaku $

#ifndef ENTITY_h
#define ENTITY_h

#include <vector>

#include "common/TypeDefine.h"
#include "common/display/3dTypes.h"
#include "common/display/actor/Actor.h"
#include "common/utilites/StdString.h"

#include "Model.h"
#include "Script.h"

class FieldModule;
class ObjectManager;



enum EntityState
{
    STATE_UNDEFINED,
    STATE_WALKMESH,
    STATE_WALKMESH_MOVE,
    STATE_JUMP,
    STATE_LADDER
};



struct ScriptQueueItem
{
    ScriptQueueItem(void):
        id(-1),
        position(0),
        start_entity_id(-1),
        end_entity_id(-1)
    {
    }

    Sint8  id;
    Uint32 position;
    Sint32 end_entity_id;
    Sint32 start_entity_id;
};



class Entity : public Actor
{
public:
                       Entity(void);
    virtual           ~Entity(void);

    virtual void       Input(const InputEvent& input);
    virtual void       Update(const Uint32 delta_time);
    virtual void       Draw(void) const;

    void               DrawCollision(void) const;

    const bool         CheckCollision(Entity* entity);
    const bool         CheckCollisionTalk(Entity* entity);

    // name related
    void               SetName(const RString& name);
    const RString&     GetName(void) const;

    // script related
    void               AddEntryPoint(const Uint32 entry_point);
    void               Run(FieldModule* field_module, Script* script, const Sint32 entity_id);
    void               Init(FieldModule* field_module, Script* script, const Sint32 entity_id);
    void               RequestRun(const Uint8 priority, const Uint32 script_id, const Sint32 start_entity_id, const Sint32 end_entity_id);
    void               SetWait(const bool wait);
    void               SetFramesToWait(const Uint32 wait);

    // state related
    void               SetState(const EntityState state);
    const EntityState  GetState(void) const;

    // position related
    void               SetPosition(const Vector3& position);
    const Vector3&     GetPosition(void) const;
    void               SetDirection(const float direction);
    const float        GetDirection(void) const;

    // walkmesh related
    void               SetTriangle(const Sint16 triangle);
    const Sint16       GetTriangle(void) const;

    // ladder related
    void               SetLadder(const Vector3& ladder_end, const Sint16 end_triangle);
    const Vector3&     GetLadderStart(void) const;
    const Sint16       GetLadderTriangleStart(void) const;
    const Vector3&     GetLadderEnd(void) const;
    const Sint16       GetLadderTriangleEnd(void) const;

    // jump related
    void               SetJump(const Vector3& jump_to);
    const Vector3&     GetJumpStart(void) const;
    const Vector3&     GetJumpEnd(void) const;

    // move related
    void               SetWalkMeshMove(const Vector3& move_to);
    const Vector3&     GetWalkMeshMovePosition(void) const;

    // solid related
    void               SetSolidRange(const Uint16 range);
    const Uint16       GetSolidRange(void) const;
    void               SetSolid(const bool solid);
    const bool         IsSolid(void) const;

    // talk related
    void               SetTalkRange(const Uint16 range);
    const Uint16       GetTalkRange(void) const;
    void               SetTalk(const bool talk);
    const bool         IsTalk(void) const;

    // model related
    void               SetModelId(const Sint8 model_id);
    const Sint8        GetModelId(void) const;
    void               SetVisible(const bool visible);
    const bool         IsVisible(void) const;



    // player character related
    void               SetPlayerCharacter(const Sint8 player_character);
    const Sint8        GetPlayerCharacter(void) const;

private:
    // name of entity
    RString             m_Name;



    // script related
    std::vector<Uint32> m_EntryPoints;
    ScriptQueueItem     m_ScriptQueue[8];
    bool                m_Inited;
    bool                m_Wait;
    Uint32              m_FramesToWait;



    EntityState         m_State;

    // entity position related
    Vector3             m_Position;
    float               m_Direction;

    // walkmesh related
    Sint16              m_Triangle;

    // ladder related
    Vector3             m_LadderStart;
    Sint16              m_LadderTriangleStart;
    Vector3             m_LadderEnd;
    Sint16              m_LadderTriangleEnd;

    // jump related
    Vector3             m_JumpStart;
    Vector3             m_JumpEnd;

    // move related
    Vector3             m_WalkMeshMovePosition;



    // solid related
    Uint16              m_SolidRange;
    bool                m_Solid;

    // talk related
    Uint16              m_TalkRange;
    bool                m_Talk;






    // model related
    Model               m_Model;
    Sint8               m_ModelId;
    bool                m_Visible;











    Geometry            m_Collision;



    // player character related
    Sint8               m_PlayerCharacter;
};



#endif // ENTITY_h
