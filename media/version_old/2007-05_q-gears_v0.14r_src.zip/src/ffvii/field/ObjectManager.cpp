// $Id$

#include "common/display/3dTypes.h"
#include "common/utilites/Config.h"
#include "common/utilites/Logger.h"

#include "FieldModule.h"
#include "ObjectManager.h"
#include "Math.h"
#include "ffvii/kernel/GameState.h"



class line_find
{
public:
    line_find(const Sint8 a):
        m_EntityId(a)
    {
    }

    bool
    operator()(const Line& a) const
    {
        return a.GetEntity() == m_EntityId;
    }

private:
    Sint8 m_EntityId;
};



ObjectManager::ObjectManager(FieldModule* field_module):
    m_FieldModule(field_module),

    m_Script(NULL),

    m_PlayerCharacterMovable(true),
    m_MovementRotation(0x8000),
    m_LadderMovementId(0),

    m_GatewaysCheck(true),
    m_LinesCheck(true),


    m_EncounterDisabled(false),
    m_DangerCounter(0),

    m_DrawCollisions(false),
    m_DrawWalkmesh(false),
    m_DrawTriggers(false)
{
    // ladder moving button routine
    m_ButtonUp   [0] = MOVE_TO_START;
    m_ButtonUp   [1] = MOVE_TO_END;
    m_ButtonUp   [2] = NOT_MOVE;
    m_ButtonUp   [3] = NOT_MOVE;

    m_ButtonDown [0] = MOVE_TO_END;
    m_ButtonDown [1] = MOVE_TO_START;
    m_ButtonDown [2] = NOT_MOVE;
    m_ButtonDown [3] = NOT_MOVE;

    m_ButtonLeft [0] = NOT_MOVE;
    m_ButtonLeft [1] = NOT_MOVE;
    m_ButtonLeft [2] = MOVE_TO_START;
    m_ButtonLeft [3] = MOVE_TO_END;

    m_ButtonRight[0] = NOT_MOVE;
    m_ButtonRight[1] = NOT_MOVE;
    m_ButtonRight[2] = MOVE_TO_END;
    m_ButtonRight[3] = MOVE_TO_START;
}



ObjectManager::~ObjectManager(void)
{
    Clear();
}



void
ObjectManager::Clear(void)
{
    if (m_Script != NULL)
    {
        delete m_Script;
        m_Script = NULL;
    }



    Uint32 i;

    // clear entitys
    for (i = 0; i < m_Entitys.size(); ++i)
    {
        delete m_Entitys[i];
    }
    m_Entitys.clear();

    // clear gateways
    for (i = 0; i < m_Gateways.size(); ++i)
    {
        delete m_Gateways[i];
    }
    m_Gateways.clear();

    // clear mark triangles
    for (i = 0; i < m_MarkTriangles.size(); ++i)
    {
        delete m_MarkTriangles[i];
    }
    m_MarkTriangles.clear();

    // clear walk mesh
    for (i = 0; i < m_WalkMesh.size(); ++i)
    {
        delete m_WalkMesh[i];
    }
    m_WalkMesh.clear();



    m_PlayerCharacterMovable = true;

    m_GatewaysCheck = true;

    m_Lines.clear();
    m_LinesCheck = true;



    m_Encounters.clear();
    m_EncounterDisabled = false;
}



void
ObjectManager::Draw(void) const
{
    Uint32 i;

    if (m_DrawWalkmesh == true)
    {
        for (i = 0; i < m_WalkMesh.size(); ++i)
        {
            m_WalkMesh[i]->Draw();
        }
    }



    // draw character
    for (i = 0; i < m_Entitys.size(); ++i)
    {
        m_Entitys[i]->Draw();

        if (m_DrawCollisions == true)
        {
            m_Entitys[i]->DrawCollision();
        }
    }



    if (m_DrawTriggers == true)
    {
        // draw triggers
        for (i = 0; i < m_Gateways.size(); ++i)
        {
            m_Gateways[i]->Draw();
        }



        // draw lines
        for (i = 0; i < m_Lines.size(); ++i)
        {
            m_Lines[i].Draw();
        }
    }



    // draw mark triangles
    for (i = 0; i < m_MarkTriangles.size(); ++i)
    {
        m_MarkTriangles[i]->Draw();
    }
}



void
ObjectManager::DrawDebugInfo(void) const
{
    RString temp;

    Sint32 pc = GetPlayerEntity();
    if (pc != -1)
    {
        Vector3 pos = m_Entitys[pc]->GetPosition();
        u16     tri = m_Entitys[pc]->GetTriangle();
        u8      dir = m_Entitys[pc]->GetDirection();

        temp.Format("x(%f) y(%f) z(%f)", pos.x, pos.y, pos.z);
        KERNEL->DrawString(RStringToFFVIIString(temp), 10, 10, F_WHITE);
        temp.Format("triangle = %d", tri);
        KERNEL->DrawString(RStringToFFVIIString(temp), 10, 25, F_WHITE);
        temp.Format("direction = %d", dir);
        KERNEL->DrawString(RStringToFFVIIString(temp), 10, 40, F_WHITE);
    }

    temp.Format("danger counter = %d", m_DangerCounter);
    KERNEL->DrawString(RStringToFFVIIString(temp), 10, 65, F_WHITE);
}



void
ObjectManager::Input(const InputEvent& input)
{
    if (input.type == IET_FIRST_PRESS)
    {
        switch (input.button)
        {
            case KEY_C3: m_DrawWalkmesh   = (m_DrawWalkmesh)   ? false : true; break;
            case KEY_C4: m_DrawCollisions = (m_DrawCollisions) ? false : true; break;
            case KEY_C5: m_DrawTriggers   = (m_DrawTriggers)   ? false : true; break;
        }
    }



    Uint32 i;

    // give input to entity
    for (i = 0; i < m_Entitys.size(); ++i)
    {
        m_Entitys[i]->Input(input);
    }



    // give input to mark triangles
    for (i = 0; i < m_MarkTriangles.size(); ++i)
    {
        m_MarkTriangles[i]->Input(input);
    }



    // give input to walk mesh
    for (i = 0; i < m_WalkMesh.size(); ++i)
    {
        m_WalkMesh[i]->Input(input);
    }
}



void
ObjectManager::Update(const Uint32 delta_time)
{
    Uint32 i;
    Sint32 pc                   = GetPlayerEntity();
    GameButtons pressed_buttons = KERNEL->GetGameButtonsCurrentState();



    // handle moving in update
    if (m_PlayerCharacterMovable == true)
    {
        if (pc != -1)
        {
            static float step = 5.0f;
            Vector4 next_step(0.0f, 0.0f, 0.0f, 1.0f);

            if (m_Entitys[pc]->GetState() == STATE_WALKMESH)
            {
                if (pressed_buttons.up == true)
                {
                    next_step.z =  step;
                }
                else if (pressed_buttons.down == true)
                {
                    next_step.z = -step;
                }

                if (pressed_buttons.right == true)
                {
                    next_step.x =  step;
                }
                else if (pressed_buttons.left == true)
                {
                    next_step.x = -step;
                }

                // if we make move rotate vector according to field
                Matrix m;
                MatrixRotationY(m, 180.0f * ((float)m_MovementRotation - 32768.0f) / 32768.0f);
                Vector4Transform(next_step, next_step, m);

                if (SetNextStep(pc, next_step) == true)
                {
                    CheckEncounters();
                }
            }

            else if (m_Entitys[pc]->GetState() == STATE_LADDER)
            {
                LadderMovement movement = NOT_MOVE;

                if (pressed_buttons.up == true)
                {
                    movement = m_ButtonUp   [m_LadderMovementId];
                }
                else if (pressed_buttons.down == true)
                {
                    movement = m_ButtonDown [m_LadderMovementId];
                }
                else if (pressed_buttons.right == true)
                {
                    movement = m_ButtonRight[m_LadderMovementId];
                }
                else if (pressed_buttons.left == true)
                {
                    movement = m_ButtonLeft [m_LadderMovementId];
                }

                SetNextLadderStep(pc, movement);
            }
        }
    }



    // check talk
    if (pressed_buttons.ok == true)
    {
        for (i = 0; i < m_Entitys.size(); ++i)
        {
            if (i != pc &&
                // if entity talkable
                m_Entitys[i]->IsTalk() == true &&
                // if we both stay still on walkmesh
                m_Entitys[i]->GetState()  == STATE_WALKMESH && m_Entitys[pc]->GetState() == STATE_WALKMESH &&
                // if we entered talk collision
                m_Entitys[i]->CheckCollisionTalk(m_Entitys[pc]) == true)
            {
                m_Entitys[i]->RequestRun(0, 1, -1, -1);
            }
        }
    }



    for (i = 0; i < m_Entitys.size(); ++i)
    {
        m_Entitys[i]->Run(m_FieldModule, m_Script, i);
    }



    if (pc != -1)
    {
        m_FieldModule->m_ScreenManager.SetPlayerCharacterPosition(m_Entitys[pc]->GetPosition());
    }



    // give update to entitys
    for (i = 0; i < m_Entitys.size(); ++i)
    {
        m_Entitys[i]->Update(delta_time);

        switch (m_Entitys[i]->GetState())
        {
            // auto move on ladder
            case STATE_LADDER:
            {
                if (i != pc)
                {
                    SetNextLadderStep(i, MOVE_TO_END);
                }
            }
            break;

            // auto move on jump
            case STATE_JUMP:
            {
                SetNextJumpStep(i);
            }
            break;

            // auto move on jump
            case STATE_WALKMESH_MOVE:
            {
                SetNextWalkMeshMoveStep(i);
            }
            break;
        }
    }



    // update mark triangles
    for (i = 0; i < m_MarkTriangles.size(); ++i)
    {
        m_MarkTriangles[i]->Update(delta_time);
    }



    // update walk mesh
    for (i = 0; i < m_WalkMesh.size(); ++i)
    {
        m_WalkMesh[i]->Update(delta_time);
    }



    // after all updates check triggers
    if (pc != -1 && m_Entitys[pc]->GetState() == STATE_WALKMESH)
    {
        CheckTriggers(pc);
    }
}



void
ObjectManager::AddEntity(Entity* entity)
{
    m_Entitys.push_back(entity);
}



void
ObjectManager::AddScript(Script* script)
{
    m_Script = script;
}



void
ObjectManager::AddWalkMeshTriangle(WalkMeshTriangle* triangle)
{
    m_WalkMesh.push_back(triangle);
}



void
ObjectManager::AddGateway(Gateway* gateway)
{
    m_Gateways.push_back(gateway);
}



void
ObjectManager::AddMarkTriangle(const Vector3& position, const MarkTriangleColor& color)
{
    MarkTriangle* triangle = new MarkTriangle(m_FieldModule, position, color);

    m_MarkTriangles.push_back(triangle);
}



void
ObjectManager::AddEncounterTable(const EncounterTable& encounterTable)
{
    // if this table is enabled - disable all others
    if (encounterTable.enabled == true)
    {
        for (Uint32 i = 0; i < m_Encounters.size(); ++i)
        {
            m_Encounters[i].enabled = false;
        }
    }

    m_Encounters.push_back(encounterTable);
}



void
ObjectManager::SetMovement(const Uint32 movement)
{
    m_MovementRotation = movement;
}



void
ObjectManager::RequestRunEntity(const Sint32 entity_id, const Uint8 priority, const Uint8 script_id, const Sint32 start_entity_id, const Sint32 end_entity_id)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::RequestRunEntity: Request to run invalid entity.");
        return;
    }

    m_Entitys[entity_id]->RequestRun(priority, script_id, start_entity_id, end_entity_id);
}



void
ObjectManager::SetFramesToWait(const Sint32 entity_id, const u16& usWait)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetFramesToWait: Request to wait invalid entity.");
        return;
    }

    m_Entitys[entity_id]->SetFramesToWait(usWait);
}



void
ObjectManager::SetPlayerCharacrerMovability(const bool& bMovability)
{
    m_PlayerCharacterMovable = !bMovability;
}



void
ObjectManager::SetEncounterTable(const u8& ubEncounterTable)
{
    if (ubEncounterTable >= m_Encounters.size())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetEncounterTable: Tried set mActiveEncounter greater than current mEncounters number.");
        return;
    }

    // enable this table, disable others
    for (u8 i = 0; i < m_Encounters.size(); ++i)
    {
        if (i == ubEncounterTable)
        {
            m_Encounters[i].enabled = true;
        }
        else
        {
            m_Encounters[i].enabled = false;
        }
    }
}



void
ObjectManager::SetTriangleAccess(const Sint16 triangle_id, const Uint8 lock)
{
    if (CheckTriangle(triangle_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetTriangleAccess: Tried set access to invalid triangle.");
        return;
    }

    m_WalkMesh[triangle_id]->SetAccessible((lock == 1) ? false : true);
}



void
ObjectManager::DisableEncounter(const bool disable)
{
    m_EncounterDisabled = disable;
}



void
ObjectManager::SetEntityTalk(const Sint32 entity_id, const bool talk)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetEntityTalk: Tried set talkability to invalid entity.");
        return;
    }

    m_Entitys[entity_id]->SetTalk(talk);
}



void
ObjectManager::SetPlayerCharacter(const Sint32 entity_id, const Sint8 pc)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetPlayerCharacter: Tried set player character to invalid entity.");
        return;
    }

    m_Entitys[entity_id]->SetPlayerCharacter(pc);



    // we always play as 0 PC for now
    if (pc == 0 && GAMESTATE->GetPlayerLoad() == true)
    {
        SetPositionByXZ(entity_id, GAMESTATE->GetPlayerPosition());

        m_Entitys[entity_id]->SetDirection(GAMESTATE->GetPlayerDirection());
    }
}



void
ObjectManager::SetCharacter(const Sint32 entity_id, const s8& sbCharacterId)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetCharacter: Tried set character to invalid entity.");
        return;
    }

    m_Entitys[entity_id]->SetModelId(sbCharacterId);
}



void
ObjectManager::SetEntityVisible(const Sint32 entity_id, const bool visible)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetEntityVisible: Tried set visibility to invalid entity.");
        return;
    }

    m_Entitys[entity_id]->SetVisible(visible);
}



void
ObjectManager::SetPositionByXYZTriangle(const Sint32 entity_id, const Vector3& coords, const Sint16 triangle_id)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetPositionByXYZTriangle: Tried set position to invalid entity.");
        return;
    }

    if (m_Entitys[entity_id]->GetState() == STATE_WALKMESH)
    {
        return;
    }

    m_Entitys[entity_id]->SetPosition(coords);
    m_Entitys[entity_id]->SetTriangle(triangle_id);
    m_Entitys[entity_id]->SetState(STATE_WALKMESH);
}



void
ObjectManager::SetEntityToMove(const Sint32 entity_id, const Vector3& end_point)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetEntityToMove: Tried set change mode to move to invalid entity.");
        return;
    }

    m_Entitys[entity_id]->SetWalkMeshMove(end_point);
}



void
ObjectManager::SetDirection(const Sint32 entity_id, const float direction)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetDirection: Tried set direction to invalid entity.");
        return;
    }

    m_Entitys[entity_id]->SetDirection(direction);
}



const Sint16
ObjectManager::GetEntityTriangleId(const Sint32 entity_id)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::GetEntityTriangleId: Tried get triangle id from invalid entity.");
        return 0;
    }

    return m_Entitys[entity_id]->GetTriangle();
}



void
ObjectManager::SetPlayerCharacterToEntity(const Sint32 entity_id)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetPlayerCharacterToEntity: Tried set player character to invalid entity.");
        return;
    }

    if (m_Entitys[entity_id]->GetState() == STATE_WALKMESH)
    {
        for (Uint32 i = 0; i < m_Entitys.size(); ++i)
        {
            if (m_Entitys[i]->GetPlayerCharacter() == 0)
            {
                m_Entitys[i]->SetPlayerCharacter(-1);
            }

            if (i == entity_id)
            {
                m_Entitys[i]->SetPlayerCharacter(0);
            }
        }
    }
}



void
ObjectManager::SetEntityToJump(const Sint32 entity_id, const Vector3& end_point, const Uint16 height)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetEntityToJump: Tried set change mode to jump to invalid entity.");
        return;
    }

    m_Entitys[entity_id]->SetJump(end_point);
}



const Vector3&
ObjectManager::GetEntityPosition(const Sint32 entity_id)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::GetEntityPosition: Tried get triangle id from invalid entity.");
        return 0;
    }

    return m_Entitys[entity_id]->GetPosition();
}



void
ObjectManager::SetEntityToLadder(const Sint32 entity_id, const Vector3& end_point, const Sint16 end_triangle, const Uint8 movement_id)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetEntityToLadder: Tried set change mode to ladder to invalid entity.");
        return;
    }

    m_Entitys[entity_id]->SetLadder(end_point, end_triangle);

    // movement id 0-3
    m_LadderMovementId = (movement_id >= 4) ? 3 : movement_id;
}



void
ObjectManager::SetEntityTalkRange(const Sint32 entity_id, const Uint16 range)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetEntityTalkRange: Tried set change talk range to invalid entity.");
        return;
    }

    m_Entitys[entity_id]->SetTalkRange(range);
}



void
ObjectManager::SetEntitySolidRange(const Sint32 entity_id, const Uint16 range)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetEntitySolidRange: Tried set change solid range to invalid entity.");
        return;
    }

    m_Entitys[entity_id]->SetSolidRange(range);
}



void
ObjectManager::SetEntitySolid(const Sint32 entity_id, const bool solid)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetEntitySolid: Tried set solid invalid entity.");
        return;
    }

    m_Entitys[entity_id]->SetSolid(solid);
}



void
ObjectManager::AddLine(const Sint32 entity_id, const Vector3& point1, const Vector3& point2)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::AddLine: Tried add line to invalid entity.");
        return;
    }

    m_Lines.push_back(Line(m_FieldModule, point1, point2, entity_id));
}



void
ObjectManager::SetLinesCheck(const bool check)
{
    m_LinesCheck = check;
}



void
ObjectManager::SetGatewaysCheck(const bool check)
{
    m_GatewaysCheck = check;
}



void
ObjectManager::SetLine(const Sint32 entity_id, const Vector3& point1, const Vector3& point2)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetLine: Tried set line to invalid entity.");
        return;
    }

    std::vector<Line>::iterator it = std::find_if(m_Lines.begin(), m_Lines.end(), line_find(entity_id));

    if (it == m_Lines.end())
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetLine: line has not been previously enabled.");
    }
    else
    {
        (*it).SetPoint1(point1);
        (*it).SetPoint2(point2);
    }
}



void
ObjectManager::SetPositionByXZ(const Sint32 entity_id, const Vector3& coords)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetPositionByXZ: Tried set position to invalid entity.");
        return;
    }

    if (m_Entitys[entity_id]->GetState() == STATE_WALKMESH)
    {
        return;
    }

    // we search for the highest triangle
    // here we store highest Y value;
    Vector3 highest_point(0.0f, -10000.0f, 0.0f);
    u32     highest_triangle_id = 0;
    bool    highest_find = false;

    Vector3 point1 = coords;

    Vector3 point2;
    point2.x = point1.x + 10000.0f;
    point2.y = point1.y;
    point2.z = point1.z;

    for (u32 i = 0; i < m_WalkMesh.size() ; ++i)
    {
        point1.y = point_elevation(point1, m_WalkMesh[i]->GetA(), m_WalkMesh[i]->GetB(), m_WalkMesh[i]->GetC());
        point2.y = point_elevation(point2, m_WalkMesh[i]->GetA(), m_WalkMesh[i]->GetB(), m_WalkMesh[i]->GetC());

        u8 check = 0;
        // if we cross line 1
        if (line_crossing(point1, point2, m_WalkMesh[i]->GetA(), m_WalkMesh[i]->GetB()) == true)
        {
            ++check;
        }
        // if we cross line 2
        if (line_crossing(point1, point2, m_WalkMesh[i]->GetB(), m_WalkMesh[i]->GetC()) == true)
        {
            ++check;
        }
        // if we cross line 3
        if (line_crossing(point1, point2, m_WalkMesh[i]->GetA(), m_WalkMesh[i]->GetC()) == true)
        {
            ++check;
        }



        // we are in triangle only if we cross one side
        if (check == 1)
        {
            if (highest_point.y < point1.y)
            {
                // store highest Y
                highest_point       = point1;
                highest_triangle_id = i;
                highest_find        = true;
            }
        }
    }



    if (highest_find == true)
    {
        m_Entitys[entity_id]->SetPosition(highest_point);
        m_Entitys[entity_id]->SetTriangle(highest_triangle_id);
        m_Entitys[entity_id]->SetState(STATE_WALKMESH);
    }
    else
    {
        m_Entitys[entity_id]->SetPosition(Vector3(0.0f, 0.0f, 0.0f));
        m_Entitys[entity_id]->SetTriangle(-1);
        m_Entitys[entity_id]->SetState(STATE_UNDEFINED);
    }
}



void
ObjectManager::SetWait(const Sint32 entity_id, const bool bWait)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetWait: Tried set wait to invalid entity.");
        return;
    }

    m_Entitys[entity_id]->SetWait(bWait);
}



const bool
ObjectManager::SetNextStep(const Sint32 entity_id, const Vector4& move_vector, const bool first)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetNextStep: Tried to move invalid entity.");
        return false;
    }



    {
        EntityState state = m_Entitys[entity_id]->GetState();
        if (state != STATE_WALKMESH && state != STATE_WALKMESH_MOVE)
        {
            LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetNextStep: Tried set move entity that are not on walkmesh.");
            return false;
        }
    }



    // if we are not moving anywhere
    if (move_vector.x == 0.0f && move_vector.z == 0.0f)
    {
        return false;
    }

    // do not change direction if we are sliding
    if (first == true)
    {
        SetEntityDirectionByVector4(entity_id, move_vector);
    }

    u16 triangle = m_Entitys[entity_id]->GetTriangle();
    u16 prev_triangle = 0xFFFE; // number of triangles never must be such great

    Vector3 start_point = m_Entitys[entity_id]->GetPosition();
    Vector3 end_point(start_point.x + move_vector.x,
                      start_point.y + move_vector.y,
                      start_point.z + move_vector.z);

    for (;;)
    {
        Vector3 A = m_WalkMesh[triangle]->GetA();
        Vector3 B = m_WalkMesh[triangle]->GetB();
        Vector3 C = m_WalkMesh[triangle]->GetC();



        // check if we cross board of current triangle
        u8 cross = 0x00;
        // if we cross line 1
        if      (line_crossing(start_point, end_point, A, B) == true && m_WalkMesh[triangle]->GetAccessSide(0) != prev_triangle)
        {
            cross = 0x01;
        }
        // if we cross line 2
        else if (line_crossing(start_point, end_point, B, C) == true && m_WalkMesh[triangle]->GetAccessSide(1) != prev_triangle)
        {
            cross = 0x02;
        }
        // if we cross line 3
        else if (line_crossing(start_point, end_point, A, C) == true && m_WalkMesh[triangle]->GetAccessSide(2) != prev_triangle)
        {
            cross = 0x03;
        }

        // if we do not cross border
        if (cross == 0x00)
        {
            end_point.y = point_elevation(end_point, A, B, C);

            // check collision
            Vector3 prev_pos = m_Entitys[entity_id]->GetPosition();
            m_Entitys[entity_id]->SetPosition(end_point);

            int numc = 0;

            for (s8 i = 0; i < m_Entitys.size(); ++i)
            {
                if (i == entity_id || m_Entitys[i]->IsSolid() == false)
                {
                    continue;
                }

                EntityState state = m_Entitys[i]->GetState();
                if ((state == STATE_WALKMESH || state == STATE_WALKMESH_MOVE) && m_Entitys[entity_id]->CheckCollision(m_Entitys[i]) == true)
                {
                    ++numc;
                    break;
                }
            }

            if (numc == 0)
            {
                m_Entitys[entity_id]->SetTriangle(triangle);
                m_Entitys[entity_id]->SetPosition(end_point);
                return true;
            }

            m_Entitys[entity_id]->SetPosition(prev_pos);
            return false;
        }
        else
        {
            // if board can be crossed
            if (m_WalkMesh[triangle]->IsAccessible() == true &&
                m_WalkMesh[triangle]->GetAccessSide(cross - 1) != -1 &&
                m_WalkMesh[m_WalkMesh[triangle]->GetAccessSide(cross - 1)]->IsAccessible() == true)
            {
                // if line crosses corner of the triangle move final point a bit and recheck all things
                if (point_on_line(A, start_point, end_point) == true ||
                    point_on_line(B, start_point, end_point) == true ||
                    point_on_line(C, start_point, end_point) == true)
                {
                    end_point.z += 0.01f;
                    end_point.x += 0.01f;
                    LOGGER->Log(LOGGER_INFO, "We tried to stay on the top of triangle.");
                    continue;
                }

                prev_triangle = triangle;
                triangle      = m_WalkMesh[triangle]->GetAccessSide(cross - 1);
            }
            else
            {
                if (first == true)
                {
                    Vector3 sp1 = (cross == 1 || cross == 3) ? A : B;
                    Vector3 sp2 = (cross == 1) ? B : C;

                    Vector4 new_move = get_projection_on_line(move_vector, sp1, sp2);

                    return SetNextStep(entity_id, new_move, false);
                }
                else
                {
                    return false;
                }
            }
        }
    }
}



void
ObjectManager::SetNextLadderStep(const Sint32 entity_id, const LadderMovement& movement)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetNextStep: Tried to move invalid entity.");
        return;
    }

    if (m_Entitys[entity_id]->GetState() != STATE_LADDER)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetNextStep: Tried set move entity that are not in ladder state.");
        return;
    }

    if (movement == NOT_MOVE)
    {
        return;
    }


    Vector3 start_point   = m_Entitys[entity_id]->GetLadderStart();
    Vector3 current_point = m_Entitys[entity_id]->GetPosition();
    Vector3 end_point     = m_Entitys[entity_id]->GetLadderEnd();

    u8 finish_end   = 0;
    u8 finish_start = 0;

    float step;

    // x moving
    step = (end_point.x - start_point.x) / 100;
    if (start_point.x == current_point.x && movement == MOVE_TO_START)
    {
        ++finish_start;
    }
    if (end_point.x == current_point.x && movement == MOVE_TO_END)
    {
        ++finish_end;
    }
    if (movement == MOVE_TO_END)
    {
        current_point.x += step;
        current_point.x = ((current_point.x > end_point.x && step > 0) || (current_point.x < end_point.x && step < 0)) ? end_point.x : current_point.x;
    }
    else if (movement == MOVE_TO_START)
    {
        current_point.x -= step;
        current_point.x = ((current_point.x < start_point.x && step > 0) || (current_point.x > start_point.x && step < 0)) ? start_point.x : current_point.x;
    }



    // y moving
    step = (end_point.y - start_point.y) / 100;
    if (start_point.y == current_point.y && movement == MOVE_TO_START)
    {
        ++finish_start;
    }
    if (end_point.y == current_point.y && movement == MOVE_TO_END)
    {
        ++finish_end;
    }
    if (movement == MOVE_TO_END)
    {
        current_point.y += step;
        current_point.y = ((current_point.y > end_point.y && step > 0) || (current_point.y < end_point.y && step < 0)) ? end_point.y : current_point.y;
    }
    else if (movement == MOVE_TO_START)
    {
        current_point.y -= step;
        current_point.y = ((current_point.y < start_point.y && step > 0) || (current_point.y > start_point.y && step < 0)) ? start_point.y : current_point.y;
    }



    // z moving
    step = (end_point.z - start_point.z) / 100;
    if (start_point.z == current_point.z && movement == MOVE_TO_START)
    {
        ++finish_start;
    }
    if (end_point.z == current_point.z && movement == MOVE_TO_END)
    {
        ++finish_end;
    }
    if (movement == MOVE_TO_END)
    {
        current_point.z += step;
        current_point.z = ((current_point.z > end_point.z && step > 0) || (current_point.z < end_point.z && step < 0)) ? end_point.z : current_point.z;
    }
    else if (movement == MOVE_TO_START)
    {
        current_point.z -= step;
        current_point.z = ((current_point.z < start_point.z && step > 0) || (current_point.z > start_point.z && step < 0)) ? start_point.z : current_point.z;
    }



    if (finish_start == 3)
    {
        m_Entitys[entity_id]->SetPosition(start_point);
        m_Entitys[entity_id]->SetTriangle(m_Entitys[entity_id]->GetLadderTriangleStart());
        m_Entitys[entity_id]->SetState(STATE_WALKMESH);
        m_Entitys[entity_id]->SetWait(false);
    }
    else if (finish_end == 3)
    {
        m_Entitys[entity_id]->SetPosition(end_point);
        m_Entitys[entity_id]->SetTriangle(m_Entitys[entity_id]->GetLadderTriangleEnd());
        m_Entitys[entity_id]->SetState(STATE_WALKMESH);
        m_Entitys[entity_id]->SetWait(false);
    }
    else
    {
        m_Entitys[entity_id]->SetPosition(current_point);
    }
}



void
ObjectManager::SetNextJumpStep(const Sint32 entity_id)
{
    SetPositionByXZ(entity_id, m_Entitys[entity_id]->GetJumpEnd());
    m_Entitys[entity_id]->SetWait(false);
}



void
ObjectManager::SetNextWalkMeshMoveStep(const Sint32 entity_id)
{
    Vector3 path = m_Entitys[entity_id]->GetWalkMeshMovePosition() - m_Entitys[entity_id]->GetPosition();
    float length = sqrtf(path.x * path.x + path.y * path.y + path.z * path.z);

    Vector3 move_vector;

    if (length > 1.0f)
    {
        Vector3Normalize(move_vector, path);
    }
    else
    {
        move_vector = path;
    }

    SetNextStep(entity_id, Vector4(move_vector.x, move_vector.y, move_vector.z, 1.0f));

    if (length < 1.0f)
    {
        m_Entitys[entity_id]->SetState(STATE_WALKMESH);
        m_Entitys[entity_id]->SetWait(false);
    }
}



void
ObjectManager::CheckTriggers(const Sint32 entity_id)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::CheckTriggers: Tried check triggers with invalid entity.");
        return;
    }

    if (m_GatewaysCheck == true)
    {
        for (u8 i = 0; i < m_Gateways.size(); ++i)
        {
            m_Gateways[i]->CheckCollision(m_Entitys[entity_id]);
        }
    }

    // check entity lines
    if (m_LinesCheck == true)
    {
        for (u8 i = 0; i < m_Lines.size(); ++i)
        {
            m_Lines[i].CheckCollision(m_Entitys[entity_id]);
        }
    }
}



void
ObjectManager::CheckEncounters(void)
{
    // if battle locked
    if (KERNEL->BattleLockGet() == true || m_EncounterDisabled == true)
    {
        return;
    }



    for (u8 j = 0; j < m_Encounters.size(); ++j)
    {
        // if field encounter not active
        if (m_Encounters[j].enabled != true || m_Encounters[j].rate == 0xFF)
        {
            continue;
        }

        m_DangerCounter += 1024 / (m_Encounters[j].rate + 1);

        // check encounter
        if (rand() % 255 < m_DangerCounter / 256)
        {
            u16 battle = 0;

            // check special encounter
            for (u8 i = 0; i < 4; ++i)
            {
                if (rand() % 64 < m_Encounters[j].special_encounter[i].rate)
                {
                    battle = m_Encounters[j].special_encounter[i].scene;
                    break;
                }
            }



            // check standard encounter
            if (battle == 0)
            {
                u8 chance = rand() % 64;
                u8 chance_sum = 0;

                for (u8 i = 0; i < 6; ++i)
                {
                    if (m_Encounters[j].standart_encounter[i].rate + chance_sum > chance)
                    {
                        battle = m_Encounters[j].standart_encounter[i].scene;
                        break;
                    }

                    chance_sum += m_Encounters[j].standart_encounter[i].rate;
                }
            }



            LOGGER->Log(LOGGER_INFO, "Encount battle %d from table %d", battle, j);
            m_FieldModule->LoadBattle(battle);
            return;
        }
    }
}



const Sint32
ObjectManager::GetPlayerEntity(void) const
{
    for (Uint32 i = 0; i < m_Entitys.size(); ++i)
    {
        // we only play as character 0
        if (m_Entitys[i]->GetPlayerCharacter() == 0)
        {
            return i;
        }
    }

    return -1;
}



void
ObjectManager::SetEntityDirectionByVector4(const Sint32 entity_id, const Vector4& vector)
{
    if (CheckEntity(entity_id) == false)
    {
        LOGGER->Log(LOGGER_WARNING, "ObjectManager::SetEntityDirectionByVector: Tried set direction to invalid entity.");
        return;
    }

    float direction = RadianToDegree(AngleVector4Vector4(vector, Vector4(0.0f, 0.0f, 1.0f, 1.0f)));

    direction = (vector.x < 0) ? direction : 360.0f - direction;

    m_Entitys[entity_id]->SetDirection(direction);
}



const bool
ObjectManager::CheckEntity(const Sint32 entity_id) const
{
    return !(entity_id >= m_Entitys.size() || entity_id < 0);
}



const bool
ObjectManager::CheckTriangle(const Sint16 triangle_id) const
{
    return !(triangle_id >= m_WalkMesh.size() || triangle_id < 0);
}
