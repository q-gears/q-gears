// $Id: DatFile.h 103 2006-11-26 07:19:38Z crazy_otaku $

#ifndef DATFILE_H
#define DATFILE_H

#include <vector>

#include "common/display/3dTypes.h"
#include "common/display/math/Matrix.h"
#include "common/utilites/StdString.h"

#include "BackgroundManager.h"
#include "ObjectManager.h"
#include "ScreenManager.h"
#include "WindowManager.h"
#include "ffvii/filetypes/LzsFile.h"
#include "ffvii/filesystem/File.h"



class DatFile : public LzsFile
{
public:
    explicit DatFile(const RString &file);
    explicit DatFile(File* file);
    DatFile(File* file, const u32 &offset, const u32 &length);
    DatFile(u8* buffer, const u32 &offset, const u32 &length);
    virtual ~DatFile();

    void GetScripts(ObjectManager& object_manager);
    void GetDialogs(WindowManager& windowManager);
    void GetBackground(BackgroundManager& backgroundManager);
    void GetWalkMesh(ObjectManager& object_manager);
    void GetCameraMatrix(ScreenManager& cam);
    void GetGateway(ObjectManager& object_manager, FieldModule* field_module);
    void GetMarkTriangles(ObjectManager& object_manager);
    void GetScreenRange(ScreenManager& screen);
    void GetMovementRotation(ObjectManager& object_manager);
    void GetEncounter(ObjectManager& objectManager);
};



#endif // DATFILE_H
