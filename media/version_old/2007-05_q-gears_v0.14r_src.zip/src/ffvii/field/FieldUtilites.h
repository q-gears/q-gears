// $Id: FieldUtilites.h 93 2006-11-12 13:49:02Z einherjar $

#ifndef FIELD_UTILITES_h
#define FIELD_UTILITES_h

#include "common/TypeDefine.h"
#include "common/utilites/StdString.h"



// converter map_id to file name
RString MapIdToRString(const u16& mapId);



#endif // FIELD_UTILITES_h
