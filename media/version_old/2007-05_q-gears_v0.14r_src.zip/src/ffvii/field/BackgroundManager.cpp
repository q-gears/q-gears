// $Id$

#include "common/display/Display.h"
#include "common/utilites/Config.h"
#include "common/utilites/Logger.h"

#include "BackgroundAnimation.h"
#include "BackgroundLayer.h"
#include "BackgroundManager.h"
#include "BackgroundTile.h"
#include "ffvii/filetypes/LzsFile.h"
#include "common/display/surface/SurfaceSaveBmp.h"



bool
layer_depth_sort(BackgroundLayer* a, BackgroundLayer* b)
{
    return a->GetDepth() > b->GetDepth();
}



class surface_find
{
public:
    surface_find(const SurfaceTexData& a):
        m_Surface(a)
    {
    }

    bool
    operator()(const SurfaceTexData& a) const
    {
        return (a.page_x == m_Surface.page_x) &&
               (a.page_y == m_Surface.page_y) &&
               (a.clut_y == m_Surface.clut_y) &&
               (a.clut_x == m_Surface.clut_x) &&
               (a.bpp    == m_Surface.bpp);
    }

private:
    SurfaceTexData m_Surface;
};



BackgroundManager::BackgroundManager(FieldModule* field_module):
    m_FieldModule(field_module),

    m_File(NULL),

    m_3rdBackground(NULL),
    m_4thBackground(NULL),

    m_Show1stBackground(true),
    m_Show2ndBackground(true),
    m_Show3rdBackground(true),
    m_Show4thBackground(true)
{
}



BackgroundManager::~BackgroundManager(void)
{
    Clear();
}



void
BackgroundManager::Clear(void)
{
    // we must do it right after loading. but if we forgot do it we can do it here.
    UnloadBackground();



    Uint32 i;

    for (i = 0; i < m_1stBackground.size(); ++i)
    {
        delete m_1stBackground[i];
    }
    m_1stBackground.clear();



    for (i = 0; i < m_2ndBackground.size(); ++i)
    {
        delete m_2ndBackground[i];
    }
    m_2ndBackground.clear();



    if (m_3rdBackground != NULL)
    {
        delete m_3rdBackground;
        m_3rdBackground = NULL;
    }



    if (m_4thBackground != NULL)
    {
        delete m_4thBackground;
        m_4thBackground = NULL;
    }



    m_BackgroundAnimation.clear();
}



void
BackgroundManager::DrawInPosition(const Vector3& move) const
{
    DISPLAY->PushMatrix();
    DISPLAY->Scale(2.0f / CONFIG->GAME_WIDTH, 2.0f / CONFIG->GAME_HEIGHT, 1.0f);
    DISPLAY->Translate(move.x, -move.y, 0.0f);
    DISPLAY->CameraPushMatrix();
    DISPLAY->CameraLoadIdentity();



    if (m_Show1stBackground == true)
    {
        for (Uint32 i = 0; i < m_1stBackground.size(); ++i)
        {
            m_1stBackground[i]->Draw();
        }
    }



    if (m_Show2ndBackground == true)
    {
        bool b3_rendered = false;
        bool b4_rendered = false;

        for (Uint32 i = 0; i < m_2ndBackground.size(); ++i)
        {
            if (b3_rendered == false && m_3rdBackground != NULL && (m_3rdBackground->GetDepth() > m_2ndBackground[i]->GetDepth()))
            {
                m_3rdBackground->Draw();
                b3_rendered = true;
            }

            if (b4_rendered == false && m_4thBackground != NULL && (m_4thBackground->GetDepth() > m_2ndBackground[i]->GetDepth()))
            {
                m_4thBackground->Draw();
                b4_rendered = true;
            }

            m_2ndBackground[i]->Draw();
        }

        if (b3_rendered == false && m_3rdBackground != NULL)
        {
            m_3rdBackground->Draw();
        }

        if (b4_rendered == false && m_4thBackground != NULL)
        {
            m_4thBackground->Draw();
        }
    }



    DISPLAY->CameraPopMatrix();
    DISPLAY->PopMatrix();
}



bool
BackgroundManager::Input(const InputEvent &input)
{
    if (input.type == IET_FIRST_PRESS)
    {
        switch (input.button)
        {
            case KEY_C1: m_Show1stBackground = (m_Show1stBackground) ? false : true; break;
            case KEY_C2: m_Show2ndBackground = (m_Show2ndBackground) ? false : true; break;
            case KEY_C3: m_Show3rdBackground = (m_Show3rdBackground) ? false : true; break;
            case KEY_C4: m_Show4thBackground = (m_Show4thBackground) ? false : true; break;
        }
    }

    return false;
}



void
BackgroundManager::Update(const Uint32 delta_time)
{
}



void
BackgroundManager::LoadBackground(const RString& name)
{
    LzsFile lzs_file(name);
    //lzs_file.WriteFile("DEL3.MIM_u");
    m_File = new MimFile(&lzs_file);
}



void
BackgroundManager::AddTile(const Uint8 background, const Sint16 dest_x, const Sint16 dest_y, const Uint8 src_x, const Uint8 src_y, const Uint16 clut_x, const Uint16 clut_y, const Uint8 bpp, const Uint8 page_x, const Uint8 page_y, const Uint16 depth, const Uint8 blending, const Uint8 animation, const Uint8 animation_index)
{
    SurfaceTexData surface;
    surface.page_x = page_x;
    surface.page_y = page_y;
    surface.clut_x = clut_x;
    surface.clut_y = clut_y;
    surface.bpp    = bpp;

    std::vector<SurfaceTexData>::iterator it = std::find_if(m_Surfaces.begin(), m_Surfaces.end(), surface_find(surface));

    if (it == m_Surfaces.end())
    {
        surface.surface = m_File->GetSurface(surface.page_x, surface.page_y, surface.clut_x, surface.clut_y, surface.bpp);
        m_Surfaces.push_back(surface);
//        SurfaceUtils::SaveBMP("xxx.bmp", surface.surface);
    }
    else
    {
        surface = *it;
    }



    // set size depending on background
    Uint8 size = (background > 1) ? 32 : 16;

    Surface* sub_image = CreateSubSurface(src_x, src_y, size, size, surface.surface);

    Uint32 texture_id = DISPLAY->CreateTexture(sub_image);

    BackgroundTile* tile = new BackgroundTile(size, texture_id, (blending == 0) ? BLEND_PSX_0 : BLEND_PSX_1, dest_x, dest_y);



    // if we want to add animation
    if (animation > 0)
    {
        // get pointer to existed group or create new one
        BackgroundAnimation* animation_set;
        bool found = false;
        for (Uint32 i = 0; i < m_BackgroundAnimation.size(); ++i)
        {
            if (m_BackgroundAnimation[i].second == animation)
            {
                animation_set = m_BackgroundAnimation[i].first;
                found = true;
            }
        }
        if (found == false)
        {
            animation_set = new BackgroundAnimation();
            m_BackgroundAnimation.push_back(Animation(animation_set, animation));
        }
        animation_set->AddTile(tile, animation_index);
    }



    // if this is 1st background
    if (background == 0)
    {
        m_1stBackground.push_back(tile);
    }



    // if this is 2nd background
    else if (background == 1)
    {
        // get pointer to existed layer or create new one
        BackgroundLayer* tile_layer;
        bool found = false;
        for (Uint32 i = 0; i < m_2ndBackground.size(); ++i)
        {
            if (m_2ndBackground[i]->GetDepth() == depth)
            {
                tile_layer = m_2ndBackground[i];
                found = true;
            }
        }
        if (found == false)
        {
            tile_layer = new BackgroundLayer();
            tile_layer->SetDepth(depth);
            m_2ndBackground.push_back(tile_layer);
            // it may be a bad idea to sort vector every time
            std::sort(m_2ndBackground.begin(), m_2ndBackground.end(), layer_depth_sort);
        }
        tile_layer->AddTile(tile);
    }



    // if this is 3rd background
    else if (background == 2)
    {
        if (m_3rdBackground == NULL)
        {
            m_3rdBackground = new BackgroundLayer();
        }

        m_3rdBackground->AddTile(tile);
    }



    // if this is 4th background
    else if (background == 3)
    {
        if (m_4thBackground == NULL)
        {
            m_4thBackground = new BackgroundLayer();
        }

        m_4thBackground->AddTile(tile);
    }



    delete sub_image;
}



void
BackgroundManager::UnloadBackground(void)
{
    if (m_File != NULL)
    {
        delete m_File;
        m_File = NULL;
    }

    for (u8 i = 0; i < m_Surfaces.size(); ++i)
    {
        delete m_Surfaces[i].surface;
    }
    m_Surfaces.clear();
}



void
BackgroundManager::BackgroundClear(const Uint8 group)
{
    for (Uint32 i = 0; i < m_BackgroundAnimation.size(); ++i)
    {
        if (m_BackgroundAnimation[i].second == group)
        {
            m_BackgroundAnimation[i].first->UnsetAllDraw();
        }
    }
}



void
BackgroundManager::BackgroundOn(const Uint8 group, const Uint8 index)
{
    for (Uint32 i = 0; i < m_BackgroundAnimation.size(); ++i)
    {
        if (m_BackgroundAnimation[i].second == group)
        {
            m_BackgroundAnimation[i].first->SetTileDraw(1 << index, true);
        }
    }
}



void
BackgroundManager::BackgroundOff(const Uint8 group, const Uint8 index)
{
    for (Uint32 i = 0; i < m_BackgroundAnimation.size(); ++i)
    {
        if (m_BackgroundAnimation[i].second == group)
        {
            m_BackgroundAnimation[i].first->SetTileDraw(1 << index, false);
        }
    }
}



void
BackgroundManager::BackgroundDepth(const Uint8 background_id, const Uint16 depth)
{
    if (background_id != 2 && background_id != 3)
    {
        LOGGER->Log(LOGGER_WARNING, "BackgroundManager::BackgroundDepth: tried change depth of background with id != 2 or 3");
        return;
    }

    if (background_id == 2 && m_3rdBackground != NULL)
    {
        m_3rdBackground->SetDepth(depth);
    }
    else if (background_id == 3 && m_4thBackground != NULL)
    {
        m_4thBackground->SetDepth(depth);
    }
}
