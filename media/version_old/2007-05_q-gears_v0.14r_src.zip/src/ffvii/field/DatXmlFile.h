// $Id: DatXmlFile.h 96 2006-11-13 03:34:17Z crazy_otaku $

#ifndef DAT_XML_FILE_h
#define DAT_XML_FILE_h

#include "common/filesystem/XmlFile.h"

#include "ObjectManager.h"
#include "WindowManager.h"



class DatXmlFile : public XmlFile
{
public:
    explicit DatXmlFile(const RString& file);
    virtual ~DatXmlFile(void);

    bool GetDialogs(WindowManager& windowManager);
    bool GetScripts(ObjectManager& object_manager);
    bool GetWalkMesh(ObjectManager& object_manager);
    bool GetGateway(ObjectManager& object_manager, FieldModule* field_module);
    bool GetMarkTriangles(ObjectManager& objectManager);
    bool GetMovementRotation(ObjectManager& object_manager);
    bool GetEncounter(ObjectManager& objectManager);

private:
    bool       mNormalFile;

    xmlNodePtr mRootNode;
};



#endif // DAT_XML_FILE_h
