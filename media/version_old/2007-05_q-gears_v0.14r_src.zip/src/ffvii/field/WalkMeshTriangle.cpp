// $Id$

#include "common/display/Display.h"
#include "common/utilites/Logger.h"

#include "WalkMeshTriangle.h"



WalkMeshTriangle::WalkMeshTriangle(const Vector3& a, const Vector3& b, const Vector3& c):
    m_A(a),
    m_B(b),
    m_C(c),

    m_Accessible(true),

    m_ColorGrant(0.85f, 0.85f, 0.85f, 1.0f),
    m_ColorDeny (0.75f, 0.00f, 0.00f, 1.0f),
    m_ColorPoint(0.00f, 0.00f, 0.85f, 1.0f)
{
    m_Access[0] = -1;
    m_Access[1] = -1;
    m_Access[2] = -1;
}



WalkMeshTriangle::~WalkMeshTriangle(void)
{
}



void
WalkMeshTriangle::Input(const InputEvent &input)
{
}



void
WalkMeshTriangle::Update(const Uint32 delta_time)
{
}



void
WalkMeshTriangle::Draw(void) const
{
    DISPLAY->SetPolygonMode(POLYGON_LINE);
    DISPLAY->SetLineWidth(1);
    DISPLAY->SetPointSize(3);

    std::vector<Vertex> line;
    line.resize(6);

    line[0].p = line[4].p = m_A;
    line[1].p = line[2].p = m_B;
    line[3].p = line[5].p = m_C;

    line[0].c = line[1].c = (m_Accessible == true && m_Access[0] != -1) ? m_ColorGrant : m_ColorDeny;
    line[2].c = line[3].c = (m_Accessible == true && m_Access[1] != -1) ? m_ColorGrant : m_ColorDeny;
    line[4].c = line[5].c = (m_Accessible == true && m_Access[2] != -1) ? m_ColorGrant : m_ColorDeny;

    DISPLAY->DrawLines(line);

    line[0].c = line[1].c = m_ColorPoint;
    line[2].c = line[3].c = m_ColorPoint;
    line[4].c = line[5].c = m_ColorPoint;

    DISPLAY->DrawPoints(line);

    DISPLAY->SetPolygonMode(POLYGON_FILL);
}



const Vector3&
WalkMeshTriangle::GetA(void) const
{
    return m_A;
}



const Vector3&
WalkMeshTriangle::GetB(void) const
{
    return m_B;
}



const Vector3&
WalkMeshTriangle::GetC(void) const
{
    return m_C;
}



void
WalkMeshTriangle::SetAccessSide(const Uint8 side, const Sint16 triangle_id)
{
    if (side > 2)
    {
        LOGGER->Log(LOGGER_WARNING, "WalkMeshTriangle::SetAccessSide: Try to set access side for side %d", side);
        return;
    }

    m_Access[side] = triangle_id;
}



Sint16
WalkMeshTriangle::GetAccessSide(const Uint8 side) const
{
    if (side > 2)
    {
        LOGGER->Log(LOGGER_WARNING, "WalkMeshTriangle::GetAccessSide: Try to get access side for side %d", side);
        return -1;
    }

    return m_Access[side];
}



void
WalkMeshTriangle::SetAccessible(const bool access)
{
    m_Accessible = access;
}



bool
WalkMeshTriangle::IsAccessible(void) const
{
    return m_Accessible;
}
