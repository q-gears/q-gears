// $Id$

#include "common/utilites/Logger.h"

#include "BsxFile.h"



BsxFile::BsxFile(const RString& file):
    LzsFile(file)
{
}



BsxFile::BsxFile(File* pFile):
    LzsFile(pFile)
{
}



BsxFile::BsxFile(File* pFile, const u32& offset, const u32& length):
    LzsFile(pFile, offset, length)
{
}



BsxFile::BsxFile(u8* pBuffer, const u32& offset, const u32& length):
    LzsFile(pBuffer, offset, length)
{
}



BsxFile::~BsxFile(void)
{
}
