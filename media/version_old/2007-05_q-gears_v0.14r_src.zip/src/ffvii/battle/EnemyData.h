// $Id$

#ifndef ENEMY_DATA_h
#define ENEMY_DATA_h

#include "../../../common/TypeDefine.h"



struct EnemyRawData
{
    Uint8  name[32];         // In FFVII text format
    Uint8  level;            // Lv
    Uint8  dexterity;        // Dex
    Uint8  luck;             // Lck
    Uint8  defense_persent;  // Df%
    Uint8  attack;           // Att
    Uint8  defense;          // Def
    Uint8  magic_attack;     // MAt
    Uint8  magic_defense;    // MDf
    Uint8  element[8];
    Uint8  element_rate[8];

    Uint8  unknown[16];

    Uint16 attack_id[8];

    Uint8  unknown2[48];

    Uint8  item_rate[4];
    Uint16 item_id[4];

    Uint16 manipulate_attack_id[4]; // ???

    Uint16 mp;
    Uint16 ap;
    Uint16 morph_item_id;

    Uint8  unknown4[2];

    Uint32 hp;
    Uint32 exp;
    Uint32 gil;

    Uint8  unknown5[8];
};



#endif // ENEMY_DATA_h
