// $Id: BattleModule.h 96 2006-11-13 03:34:17Z crazy_otaku $

#ifndef BATTLE_MODULE_h
#define BATTLE_MODULE_h

#include "common/display/actor/Actor.h"



class BattleModule : public Actor
{
public:
    BattleModule(void);

    virtual ~BattleModule(void);

    virtual void Init(void);

    virtual void Draw(void) const;

    virtual void Input(const InputEvent& input);

    virtual void Update(const Uint32 deltaTime);

    // we cant give id by reference because we may delete caller when clear map resources.
    void LoadBattle(const u16 id);

private:
    u16 mBattleId;
};



#endif // BATTLE_MODULE_h
