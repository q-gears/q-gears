// $Id: GameDefine.h 103 2006-11-26 07:19:38Z crazy_otaku $

#ifndef GAME_DEFINE_H
#define GAME_DEFINE_H



#define APPLICATION_NAME "FFVII v0.11"


#define MAX_ITEM_SLOT     200
#define MAX_ITEM_PER_SLOT 100
#define MAX_MATERIA_SLOT  200
#define MAX_MONEY         1000



#endif // GAME_DEFINE_H
