#ifndef MATRIXMATH_H
#define MATRIXMATH_H



#include "matrix.h"



#define PI (3.141592653589793f)
#define DegreeToRadian(degree) ((degree) * (PI / 180.0f))
#define RadianToDegree(radian) ((radian) * (180.0f / PI))



void MatrixIdentity   (Matrix *Out);
void MatrixTranslation(Matrix *Out, float x, float y, float z);
void MatrixScaling    (Matrix *Out, float x, float y, float z);
void MatrixRotationX  (Matrix *Out, float theta);
void MatrixRotationY  (Matrix *Out, float theta);
void MatrixRotationZ  (Matrix *Out, float theta);
void MatrixRotationXYZ(Matrix *Out, float rX, float rY, float rZ);

void MatrixMultiply   (Matrix *Out, const Matrix *A, const Matrix *B);

Matrix LookAt(float eyex, float eyey, float eyez, float centerx, float centery, float centerz, float upx, float upy, float upz);



#endif
