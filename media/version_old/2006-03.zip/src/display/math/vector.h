#ifndef VECTOR_H
#define VECTOR_H



struct Vector2
{
    public:
        Vector2() {}
        Vector2(const float *f)                         {x = f[0]; y = f[1];}
        Vector2(float x1, float y1): x(x1), y(y1)       {}

        // casting
        operator float* ()                              {return &x;};
        operator const float* () const                  {return &x;};

        // assignment operators
        Vector2& operator += (const Vector2& other)     {x += other.x; y += other.y; return *this;}
        Vector2& operator -= (const Vector2& other)     {x -= other.x; y -= other.y; return *this;}
        Vector2& operator *= (float f)                  {x *= f; y *= f; return *this;}
        Vector2& operator /= (float f)                  {x /= f; y /= f; return *this;}

        // binary operators
        Vector2 operator + (const Vector2& other) const {return Vector2(x + other.x, y + other.y);}
        Vector2 operator - (const Vector2& other) const {return Vector2(x - other.x, y - other.y);}
        Vector2 operator * (float f) const              {return Vector2(x * f, y * f);}
        Vector2 operator / (float f) const              {return Vector2(x / f, y / f);}

        friend Vector2 operator * (float f, const Vector2& other) {return other * f;}

        float x, y;
};



struct Vector3
{
    public:
        Vector3() {}
        Vector3(const float *f)                        {x = f[0]; y = f[1]; z = f[2];}
        Vector3(float x1, float y1, float z1)          {x = x1; y = y1; z = z1;}

        // casting
        operator float* ()                              {return &x;};
        operator const float* () const                  {return &x;};

        // assignment operators
        Vector3& operator += (const Vector3& other)     {x += other.x; y += other.y; z += other.z; return *this;}
        Vector3& operator -= (const Vector3& other)     {x -= other.x; y -= other.y; z -= other.z; return *this;}
        Vector3& operator *= (float f)                  {x *= f; y *= f; z *= f; return *this;}
        Vector3& operator /= (float f)                  {x /= f; y /= f; z /= f; return *this;}

        // binary operators
        Vector3 operator + (const Vector3& other) const {return Vector3(x + other.x, y + other.y, z + other.z);}
        Vector3 operator - (const Vector3& other) const {return Vector3(x - other.x, y - other.y, z - other.z);}
        Vector3 operator * (float f) const              {return Vector3(x * f, y * f, z * f);}
        Vector3 operator / (float f) const              {return Vector3(x / f, y / f, z / f);}

        friend Vector3 operator * (float f, const Vector3& other) {return other * f;}

        float x, y, z;
};



struct Vector4
{
    public:
        Vector4() {}
        Vector4(const float *f)                         {x = f[0]; y = f[1]; z = f[2]; w = f[3];}
        Vector4(float x1, float y1, float z1, float w1) {x = x1; y = y1; z = z1; w = w1;}

        // casting
        operator float* ()                              {return &x;};
        operator const float* () const                  {return &x;};

        // assignment operators
        Vector4& operator += (const Vector4& other)     {x += other.x; y += other.y; z += other.z; w += other.w; return *this;}
        Vector4& operator -= (const Vector4& other)     {x -= other.x; y -= other.y; z -= other.z; w -= other.w; return *this;}
        Vector4& operator *= (float f)                  {x *= f; y *= f; z *= f; w *= f; return *this;}
        Vector4& operator /= (float f)                  {x /= f; y /= f; z /= f; w /= f; return *this;}

        // binary operators
        Vector4 operator + (const Vector4& other) const {return Vector4(x + other.x, y + other.y, z + other.z, w + other.w);}
        Vector4 operator - (const Vector4& other) const {return Vector4(x - other.x, y - other.y, z - other.z, w - other.w);}
        Vector4 operator * (float f) const              {return Vector4(x * f, y * f, z * f, w * f);}
        Vector4 operator / (float f) const              {return Vector4(x / f, y / f, z / f, w / f);}

        friend Vector4 operator * (float f, const Vector4& other) {return other * f;}

        float x, y, z, w;
};



#endif // VECTOR_H
