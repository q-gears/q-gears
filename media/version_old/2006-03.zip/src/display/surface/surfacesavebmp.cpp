#include <stdio.h>
#include <string.h>
#include "surface.h"
#include "surfacesavebmp.h"
#include "../../resource/filesystem/realfilesystem.h"
#include "../../log.h"



bool
SurfaceUtils::SaveBMP(const std::string &file, Surface *&surface)
{
    struct BitmapFileHeader
    {
        unsigned short Type;
        unsigned long  Size;
        unsigned short Reserved1;
        unsigned short Reserved2;
        unsigned long  OffBits;
    } bfh;

    struct BitmapInfoHeader
    {
        unsigned long  Size;
        signed long    Width;
        signed long    Height;
        unsigned short Planes;
        unsigned short BitCount;
        unsigned long  Compression;
        unsigned long  SizeImage;
        signed long    XPelsPerMeter;
        signed long    YPelsPerMeter;
        unsigned long  ClrUsed;
        unsigned long  ClrImportant;
    } bih;

    memset (&bfh, 0, sizeof(bfh));
    bfh.Type        = 0x4D42; // BM
    bfh.OffBits     = sizeof(bfh) + sizeof(bih) + 1024;
    bfh.Size        = bfh.OffBits + 3 * surface->width * surface->height + surface->height * (surface->width % 4);

    memset (&bih, 0, sizeof(bih));
    bih.Size        = sizeof(bih);
    bih.BitCount    = 24;
    bih.Compression = 0; // COMP_BI_RGB;
    bih.Height      = surface->height;
    bih.Width       = surface->width;
    bih.Planes      = 1;

    unsigned char palette[1024];
    memset(palette, 0, 1024);

    int pos = 0;
    REALFILESYSTEM->WriteNewFile(file, &bfh,    pos, sizeof(bfh)); pos += sizeof(bfh);
    REALFILESYSTEM->WriteFile(file, &bih,    pos, sizeof(bih));    pos += sizeof(bih);
    REALFILESYSTEM->WriteFile(file, palette, pos, 1024);           pos += 1024;

    int data_size = surface->width * surface->height * 3 + surface->height * (surface->width % 4);
    unsigned char *temp = new unsigned char[data_size];
    int temp_pos = 0;

    for (int y = surface->height - 1; y >= 0; y--)
    {
        for (int x = 0; x < surface->width; x++)
        {
            temp[temp_pos++] = surface->pixels[x * 4 + surface->width * 4 * y + 2];
            temp[temp_pos++] = surface->pixels[x * 4 + surface->width * 4 * y + 1];
            temp[temp_pos++] = surface->pixels[x * 4 + surface->width * 4 * y + 0];
        }

        for (int i = 0; i < surface->width % 4; i++)
        {
            temp[temp_pos++] = 0;
        }
    }

    bool ret = REALFILESYSTEM->WriteFile(file, temp, pos, data_size); pos += data_size;
    delete [] temp;

    return ret;
}
