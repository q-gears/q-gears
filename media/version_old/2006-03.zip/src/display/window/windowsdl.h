#ifndef WINDOWSDL_H
#define WINDOWSDL_H

#include "window.h"



class WindowSDL : public Window
{
    public:
             WindowSDL();

            ~WindowSDL();

        void SwapBuffers();

        void Update();
};



#endif // WINDOWSDL_H
