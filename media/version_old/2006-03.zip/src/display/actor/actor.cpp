#include "actor.h"
#include "../display.h"
#include "../3dtypes.h"
#include "../math/vector.h"



Actor::Actor()
{
    InitDefaults();
}



Actor::Actor(const Actor &cpy)
{
#define CPY(x) x = cpy.x
    CPY(mName);

    CPY(mBlendMode);
    CPY(mZTestMode);
    CPY(mCullMode);
    CPY(mPolygonMode);
#undef CPY
}



Actor::~Actor()
{
}



const std::string &
Actor::GetName() const
{
    return mName;
}



void
Actor::SetName(const std::string &name)
{
    mName = name;
}



void
Actor::InitDefaults()
{
    mBlendMode   = BLEND_NORMAL;
    mZTestMode   = ZTEST_OFF;
    mCullMode    = CULL_NONE;
    mPolygonMode = POLYGON_FILL;
}



void
Actor::Draw()
{
    // call the most-derived versions
    this->BeginDraw();
    this->DrawPrimitives();
    this->EndDraw();
}



void
Actor::BeginDraw() // set the world matrix and calculate actor properties
{
    DISPLAY->PushMatrix(); // we're actually going to do some drawing in this function
}



void
Actor::SetGlobalRenderStates()
{
    // set Actor-defined render states
    DISPLAY->SetBlendMode(mBlendMode);
    DISPLAY->SetZTestMode(mZTestMode);
    DISPLAY->SetCullMode(mCullMode);
    DISPLAY->SetPolygonMode(mPolygonMode);
}



void
Actor::EndDraw()
{
    DISPLAY->PopMatrix();
}



void
Actor::SetBlendMode(BlendMode mode)
{
    mBlendMode = mode;
}



void
Actor::SetZTestMode(ZTestMode mode)
{
    mZTestMode = mode;
}



void
Actor::SetCullMode(CullMode mode)
{
    mCullMode = mode;
}



void
Actor::SetPolygonMode(PolygonMode mode)
{
    mPolygonMode = mode;
}
