// DisplayOGL - OpenGL renderer.

#ifndef DISPLAYOGL_H
#define DISPLAYOGL_H



#include "display.h"
#include "window/window.h"

#include <vector>



class DisplayOGL : public Display
{
    public:
                      DisplayOGL();

        virtual      ~DisplayOGL();

        void          Init();

        bool          BeginFrame();
        void          EndFrame();

        unsigned int  CreateTexture(Surface *image);
        void          UpdateTexture(unsigned int tex_handle, Surface *image, int xoffset, int yoffset, int width, int height);
        void          DeleteTexture(unsigned int tex_handle);
        void          SetTexture(unsigned int tex_handle);
        void          UnsetTexture();

        void          SetAlphaTest(bool b);
        void          SetZTestMode(ZTestMode mode);
        void          SetBlendMode(BlendMode mode);
        void          SetCullMode(CullMode mode);
        void          SetPolygonMode(PolygonMode pm);
        void          SetLineWidth(float width);
        void          SetPointSize(float size);


    protected:
        void          DrawPointsInternal(const std::vector<Vertex> &v);
        void          DrawLinesInternal(const std::vector<Vertex> &v);
        void          DrawTrianglesInternal(const std::vector<Vertex> &v);
        void          DrawQuadsInternal(const std::vector<Vertex> &v);

        void          SetupVertices(const std::vector<Vertex> &v);
        void          SendCurrentMatrices();

    private:
        Window *mWindow;
};



#endif
