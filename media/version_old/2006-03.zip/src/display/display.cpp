#include "display.h"

#include <math.h>
#include <vector>



Display *DISPLAY = NULL;



void
Display::EndFrame()
{
}



void
Display::DrawPoints(const std::vector<Vertex> &v)
{
    if (v.size() == 0)
    {
        return;
    }

    this->DrawPointsInternal(v);
}



void
Display::DrawLines(const std::vector<Vertex> &v)
{
    if (v.size() == 0)
    {
        return;
    }

    this->DrawLinesInternal(v);
}



void
Display::DrawTriangles(const std::vector<Vertex> &v)
{
    if (v.size() == 0)
    {
        return;
    }

    this->DrawTrianglesInternal(v);
}



void
Display::DrawQuads(const std::vector<Vertex> &v)
{
    if (v.size() == 0)
    {
        return;
    }

    this->DrawQuadsInternal(v);
}



void
Display::DrawGeometry(const Geometry &g)
{
    if (g.TexEnabled)
    {
        this->SetTexture(g.TexIndex);
    }

    this->DrawTriangles(g.Triangles);
    this->DrawQuads(g.Quads);

    if (g.TexEnabled)
    {
        this->UnsetTexture();
    }
}



void
Display::DrawTotalGeometry(const TotalGeometry &g)
{
    for (int i = 0; i < g.geometry.size(); i++)
    {
        this->DrawGeometry(g.geometry[i]);
    }
}



const Matrix *
Display::GetProjectionTop()
{
    return ProjectionStack.GetTop();
}



const Matrix *
Display::GetViewTop()
{
    return ViewStack.GetTop();
}



const Matrix *
Display::GetWorldTop()
{
    return WorldStack.GetTop();
}



const Matrix *
Display::GetTextureTop()
{
    return TextureStack.GetTop();
}



void
Display::PushMatrix()
{
    WorldStack.Push();
}



void
Display::PopMatrix()
{
    WorldStack.Pop();
}



void
Display::Translate(float x, float y, float z)
{
    WorldStack.TranslateLocal(x, y, z);
}



void
Display::TranslateWorld(float x, float y, float z)
{
    WorldStack.Translate(x, y, z);
}



void
Display::Scale(float x, float y, float z)
{
    WorldStack.ScaleLocal(x, y, z);
}



void
Display::RotateX(float deg)
{
    WorldStack.RotateXLocal(deg);
}



void
Display::RotateY(float deg)
{
    WorldStack.RotateYLocal(deg);
}



void
Display::RotateZ(float deg)
{
    WorldStack.RotateZLocal(deg);
}



void
Display::PostMultMatrix(const Matrix &m)
{
    WorldStack.MultMatrix(m);
}



void
Display::PreMultMatrix(const Matrix &m)
{
    WorldStack.MultMatrixLocal(m);
}



void
Display::LoadIdentity()
{
    WorldStack.LoadIdentity();
}


void
Display::TexturePushMatrix()
{
    TextureStack.Push();
}



void
Display::TexturePopMatrix()
{
    TextureStack.Pop();
}



void
Display::TextureTranslate(float x, float y)
{
    TextureStack.TranslateLocal(x, y, 0);
}



void
Display::TextureScale(float x, float y, float z)
{
    TextureStack.ScaleLocal(x, y, z);
}



void
Display::CameraPushMatrix()
{
    ProjectionStack.Push();
    ViewStack.Push();
}



void
Display::CameraPopMatrix()
{
    ProjectionStack.Pop();
    ViewStack.Pop();
}



// gluLookAt. The result is pre-multiplied to the matrix (M = L * M) instead of post-multiplied.
void
Display::LoadLookAt(float angley, const Vector3 &eye, const Vector3 &at, const Vector3 &up)
{
    float aspect = (float)640/(float)480;
    ProjectionStack.LoadMatrix(GetPerspectiveMatrix(angley, aspect, 1, 1000));

    ViewStack.LoadMatrix(LookAt(eye.x, eye.y, eye.z, at.x, at.y, at.z, up.x, up.y, up.z));
}



Matrix
Display::GetPerspectiveMatrix(float angley, float aspect, float znear, float zfar)
{
    float ymax = znear * tanf(angley * PI / 360.0f);
    float ymin = -ymax;
    float xmin = ymin * aspect;
    float xmax = ymax * aspect;

    return GetFrustumMatrix(xmin, xmax, ymin, ymax, znear, zfar);
}



Matrix
Display::GetOrthoMatrix(float l, float r, float b, float t, float zn, float zf)
{
    Matrix m(
         2 / (r - l),        0,                  0,                     0,
         0,                  2 / (t - b),        0,                     0,
         0,                  0,                 -2 / (zf - zn),         0,
        -(r + l) / (r - l), -(t + b) / (t - b), -(zf + zn) / (zf - zn), 1);
    return m;
}



Matrix
Display::GetFrustumMatrix(float l, float r, float b, float t, float zn, float zf)
{
    Matrix m(
        2 * zn / (r - l),  0,                  0,                              0,
        0,                 2 * zn / (t - b),   0,                              0,
        (r + l) / (r - l), (t + b) / (t - b), -1 * (zf + zn) / (zf - zn),     -1,
        0,                 0,                 -1 * (2 * zf * zn) / (zf - zn),  0);
    return m;
}
