#ifndef INPUTHANDLERSDL_H
#define INPUTHANDLERSDL_H



#include "inputhandler.h"



class InputHandlerSDL: public InputHandler
{
    public:
              InputHandlerSDL();
             ~InputHandlerSDL();

        void  Update();

};



#endif // INPUTHANDLERSDL_H
