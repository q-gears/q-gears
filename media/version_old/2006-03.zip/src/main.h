#ifndef MAIN_H
#define MAIN_H



enum
{
    EXIT,
    GAME
};

extern unsigned char state;



#endif // MAIN_H