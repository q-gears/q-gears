#include "file.h"
#include "filesystem/realfilesystem.h"
#include "../log.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

File::File(const std::string &file):
    mBuffer(NULL),
    mBufferSize(0),
    mFileName(file)
{
    LoadFile();
}



File::File(File *file, u32 offset, u32 length):
    mBuffer(NULL),
    mBufferSize(length),
    mFileName(file->GetFileName())
{
    mBuffer = (u8 *)malloc(sizeof(u8) * mBufferSize);
    file->GetFileBuffer(mBuffer, offset, mBufferSize);
}



File::File(File *file):
    mBufferSize(file->GetFileSize()),
    mFileName(file->GetFileName())
{
    mBuffer = (u8 *)malloc(sizeof(u8) * mBufferSize);
    file->GetFileBuffer(mBuffer, 0, mBufferSize);
}


File::~File()
{
    free(mBuffer);
}



const bool
File::LoadFile()
{
    if (REALFILESYSTEM->DoesFileExist(mFileName))
    {
        mBufferSize = (!mBufferSize) ? REALFILESYSTEM->GetFileSizeInBytes(mFileName) : mBufferSize;

        mBuffer = (u8 *)malloc(sizeof(u8) * mBufferSize);

        REALFILESYSTEM->ReadFile(mFileName, mBuffer, 0, mBufferSize);
    }
    else
    {
        LOGGER->Log("Warning: %s not found!", mFileName.c_str());
        return false;
    }

    return true;
}



const std::string
File::GetFileName() const
{
    return mFileName;
}



const File::u32
File::GetFileSize() const
{
    return mBufferSize;
}



void
File::GetFileBuffer(u8 *buffer, u32 start, u32 length)
{
    memcpy(buffer, mBuffer + start, length);
}



const File::u8
File::get_u8(const u32 offset) const
{
    return (u8)(*(mBuffer + offset));
}



const File::u16
File::get_u16le(const u32 offset) const
{
    return ((u8 *)mBuffer + offset)[0] | (((u8 *)mBuffer + offset)[1] << 8);
}



const File::u32
File::get_u32le(const u32 offset) const
{
    return ((u8 *)mBuffer + offset)[0] | (((u8 *)mBuffer + offset)[1] << 8) | (((u8 *)mBuffer + offset)[2] << 16) | (((u8 *)mBuffer + offset)[3] << 24);
}



void
File::WriteFile(const std::string &file)
{
    REALFILESYSTEM->WriteNewFile(file, mBuffer, 0, mBufferSize);
}
