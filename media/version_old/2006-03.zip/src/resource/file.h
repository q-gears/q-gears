#ifndef FILE_H
#define FILE_H

#include <string>



class File
{
    public:
        typedef unsigned char      u8;
        typedef unsigned short int u16;
        typedef unsigned long  int u32;

        typedef signed   char      s8;
        typedef signed   short int s16;
        typedef signed   long  int s32;

                                  File(const std::string &file);

                                  File(File *file, u32 offset, u32 length);

                                  File(File *file);

        virtual                  ~File();

        virtual void              WriteFile(const std::string &file);

        // return "mFileName"
        virtual const std::string GetFileName() const;

        // return "mBufferSize"
        virtual const u32         GetFileSize() const;

        // fill given buffer with part of mBuffer
        virtual void              GetFileBuffer(u8 *buffer, u32 start, u32 length);



    protected:
        // load file "fileName" and fill "fileSize" with size of readed data
        const bool                LoadFile();

        // utility functions returns value with given offset
        const u8                  get_u8(const u32 offset) const;
        const u16                 get_u16le(const u32 offset) const;
        const u32                 get_u32le(const u32 offset) const;



    protected:
        // filename
        const std::string mFileName;
        // loaded file buffer
        u8               *mBuffer;
        // size of buffer
        u32               mBufferSize;
};



#endif // FILE_H
