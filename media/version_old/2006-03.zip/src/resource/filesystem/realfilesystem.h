#ifndef REALFILESYSTEM_H
#define REALFILESYSTEM_H



#include "filesystem.h"

#include <string>
#include <vector>



class RealFileSystem : public FileSystem
{
    public:
                             RealFileSystem();

        virtual             ~RealFileSystem();

        virtual void         MountFileSystem();

        virtual void         GetDirListing(const std::string &path, std::vector<std::string> &listing, const bool &dirs);

        virtual FileType     GetFileType(const std::string &path);

        virtual bool         IsAFile(const std::string &path);

        virtual bool         IsADirectory(const std::string &path);

        virtual bool         DoesFileExist(const std::string &path);

        virtual unsigned int GetFileSizeInBytes(const std::string &path);

        virtual bool         ReadFile(const std::string &path, void *buffer, unsigned int start, unsigned int length);
        virtual bool         WriteFile(const std::string &path, void *buffer, int start, unsigned int length);
                bool         WriteNewFile(const std::string &path, void *buffer, int start, unsigned int length);
        virtual bool         RemoveFile(const std::string &path);
};



extern RealFileSystem *REALFILESYSTEM;



#endif // REALFILESYSTEM_H
