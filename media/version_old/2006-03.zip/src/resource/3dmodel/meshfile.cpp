#include "meshfile.h"
#include "../file.h"
#include "../../display/3dtypes.h"
#include "../../log.h"

#include <string>
#include <vector>



MeshFile::MeshFile(const std::string &file):
    File(file)
{
}



MeshFile::MeshFile(File *file):
    File(file)
{
}



MeshFile::~MeshFile()
{
}



void
MeshFile::GetGeometry(TotalGeometry &result_geometry)
{
    u32 offset_to_walkmesh = 0x1C + get_u32le(0x04) - get_u32le(0x00);

    Geometry geometry;
    geometry.TexEnabled = false;

    u32 number_of_poly = get_u32le(offset_to_walkmesh);
    int start = offset_to_walkmesh + 0x04;

    for (u32 i = 0; i < number_of_poly; ++i)
    {
        Vertex v[3];

        v[0].p.x = -(s16)get_u16le(start + 0x00);
        v[0].p.z =  (s16)get_u16le(start + 0x02);
        v[0].p.y =  (s16)get_u16le(start + 0x04);

        v[1].p.x = -(s16)get_u16le(start + 0x08);
        v[1].p.z =  (s16)get_u16le(start + 0x0A);
        v[1].p.y =  (s16)get_u16le(start + 0x0C);

        v[2].p.x = -(s16)get_u16le(start + 0x10);
        v[2].p.z =  (s16)get_u16le(start + 0x12);
        v[2].p.y =  (s16)get_u16le(start + 0x14);

        geometry.AddTriangle(v);

        // go to the next triangle
        start += 0x18;

    }

    result_geometry.geometry.push_back(geometry);
}
