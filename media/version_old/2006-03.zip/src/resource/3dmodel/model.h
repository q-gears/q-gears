#ifndef MODEL_H
#define MODEL_H



#include "../file.h"
#include "../../display/3dtypes.h"
#include "../../display/actor/actor.h"



class Model : public Actor
{
    public:
                     Model();
        virtual     ~Model();

        virtual void Load(const File *file);
        virtual void DrawPrimitives();



    private:
                void LoadMeshes(const File *file);




    protected:
                void ClearPrevious();

        TotalGeometry mMeshes;
};



#endif
