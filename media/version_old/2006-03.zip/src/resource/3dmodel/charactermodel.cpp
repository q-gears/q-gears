#include "charactermodel.h"
#include "../../display/3dtypes.h"
#include "../../log.h"



CharacterModel::CharacterModel()
{
    Geometry geometry;
    geometry.TexEnabled = false;

    int x = 100;

    Vertex v[4];
    v[0].p.x = 0; v[0].p.y = 0; v[0].p.z = 0; v[0].c.r = 1; v[0].c.g = 0; v[0].c.b = 0; v[0].c.a = 1;
    v[1].p.x = 0; v[1].p.y = 0; v[1].p.z = x; v[1].c.r = 1; v[1].c.g = 0; v[1].c.b = 0; v[1].c.a = 1;
    v[2].p.x = x; v[2].p.y = 0; v[2].p.z = x; v[2].c.r = 1; v[2].c.g = 0; v[2].c.b = 0; v[2].c.a = 1;
    v[3].p.x = x; v[3].p.y = 0; v[3].p.z = 0; v[3].c.r = 1; v[3].c.g = 0; v[3].c.b = 0; v[3].c.a = 1;
    geometry.AddQuad(v);

    mMeshes.geometry.push_back(geometry);
}



CharacterModel::~CharacterModel()
{
    ClearPrevious();
}



void
CharacterModel::DrawPrimitives()
{
    Model::DrawPrimitives();
}
