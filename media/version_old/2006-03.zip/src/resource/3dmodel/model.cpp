#include "model.h"
#include "meshfile.h"
#include "../file.h"
#include "../filesystem/realfilesystem.h"
#include "../../display/3dtypes.h"
#include "../../display/display.h"
#include "../../log.h"



Model::Model()
{
}



Model::~Model()
{
    ClearPrevious();
}




void Model::Load(const File *file)
{
    ClearPrevious();

    LoadMeshes(file);
}



void
Model::LoadMeshes(const File *file)
{
    MeshFile *mesh = new MeshFile((File *)file);
    mesh->GetGeometry(mMeshes);
    delete mesh;
}



void
Model::ClearPrevious()
{
    mMeshes.geometry.clear();
}



void
Model::DrawPrimitives()
{
    Actor::SetGlobalRenderStates(); // set Actor-specified render states
    DISPLAY->DrawTotalGeometry(mMeshes);
}
