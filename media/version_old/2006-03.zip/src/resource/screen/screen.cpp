#include "screen.h"

#include <string>



Screen::Screen(std::string name)
{
    SetName(name);
}



Screen::~Screen()
{
}



void
Screen::Init()
{
}



void
Screen::Input(const InputEvent &input)
{
}



void
Screen::Draw()
{
}
