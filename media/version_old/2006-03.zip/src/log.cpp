#include "log.h"
#include "resource/filesystem/realfilesystem.h"

#include <stdarg.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string>



Logger *LOGGER = NULL;



Logger::Logger(const std::string &logFile):
    mLogFile(logFile)
{
    REALFILESYSTEM->WriteNewFile(mLogFile, NULL, 0, 0);
}



Logger::~Logger()
{
}



void
Logger::Log(const char *log_text, ...)
{
    char *buf = new char[1024];
    va_list ap;
    time_t t;

    // Use a temporary buffer to fill in the variables
    va_start(ap, log_text);
    vsprintf(buf, log_text, ap);
    va_end(ap);

    // Get the current system time
    time(&t);

    // Print the log entry
    std::string string("");

    char buffer [12];
    itoa((int)(((t / 60) / 60) % 24), buffer, 10);
    std::string hours = ((((t / 60) / 60) % 24 < 10) ? "0" : "") + std::string(buffer);
    itoa((int)((t / 60) % 60), buffer, 10);
    std::string minutes = (((t / 60) % 60 < 10) ? "0" : "") + std::string(buffer);
    itoa((int)(t % 60), buffer, 10);
    std::string seconds = ((t % 60 < 10) ? "0" : "") + std::string(buffer);
    std::string text = std::string(buf);

    string = "[" + hours + ":" + minutes + ":" + seconds + "] " + text + "\n";

    REALFILESYSTEM->WriteFile(mLogFile, (void *)(string.c_str()), REALFILESYSTEM->GetFileSizeInBytes(mLogFile), string.size());

    // Delete temporary buffer
    delete[] buf;
}
