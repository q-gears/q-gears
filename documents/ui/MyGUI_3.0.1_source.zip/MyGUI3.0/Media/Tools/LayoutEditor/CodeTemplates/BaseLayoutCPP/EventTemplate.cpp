void #{Panel_Name}::#{Widget_Name}_#{Event_Name}(#{Event_Signature})
{
	// empty
}
