//%LE LayoutEditor generated file. Do not remove %LE comments.
#ifndef __#{Uppercase_Panel_Name}_H__
#define __#{Uppercase_Panel_Name}_H__

#include <MyGUI.h>
#include "BaseLayout.h"

class #{Panel_Name} : public wraps::BaseLayout
{
public:
	#{Panel_Name}();
	virtual ~#{Panel_Name}(){};

	virtual void initialise(MyGUI::WidgetPtr _parent);

private:
//	%LE Event_Declaration list start
//	%LE Event_Declaration list end
private:
//	%LE Widget_Declaration list start
//	%LE Widget_Declaration list end
};

#endif // __#{Uppercase_Panel_Name}_H__
