//%LE LayoutEditor generated file. Do not remove %LE comments.
#include "#{Panel_Name}.h"

#{Panel_Name}::#{Panel_Name}() :
	BaseLayout("#{Panel_Name}.layout")
{
}

void #{Panel_Name}::initialise(MyGUI::WidgetPtr _parent)
{
	loadLayout(_parent);

//	%LE Widget_Assign list start
//	%LE Widget_Assign list end

//	%LE Event_Assign list start
//	%LE Event_Assign list end
}

//%LE Event_Definition list start
//%LE Event_Definition list end